/**
 * Scheduler: damage sink, frame-end tick, paint dispatch, pump, frame hooks (docs/ARCHITECTURE.md ADR-C).
 * Module: schedule (src/schedule/**).
 */

import { BUS, EXT } from '../contracts/events.js';
import { clampFrameCap, createCapGate, effectiveFps, parseFrameCap } from './frame-cap.js';
import { createFramePhase } from './frame-phase.js';
import { createPaintGate } from './paint-gate.js';
import { shadowIncludingOrder } from '../util/tree-order.js';

/** @typedef {import('../contracts/types.js').CanvasRecord} CanvasRecord */
/** @typedef {import('../contracts/types.js').ChangeSet} ChangeSet */
/** @typedef {import('../contracts/types.js').DamageCause} DamageCause */
/** @typedef {import('../contracts/types.js').FrameHook} FrameHook */
/** @typedef {import('../contracts/types.js').HicEnv} HicEnv */
/** @typedef {import('../contracts/types.js').PumpResult} PumpResult */
/** @typedef {import('../contracts/types.js').Rect} Rect */
/** @typedef {import('../contracts/types.js').Scheduler} Scheduler */
/** @typedef {import('../contracts/types.js').SchedulerHooks} SchedulerHooks */
/** @typedef {import('../contracts/types.js').SnapshotStore} SnapshotStore */

/**
 * @typedef {Object} Entry  everything the scheduler keeps per canvas
 * @property {CanvasRecord} record
 * @property {boolean} registered
 * @property {Set<FrameHook>} hooks
 * @property {boolean} dirty  damage or in-flight work may exist: tick until the store reports settled
 * @property {boolean} interaction  user-driven damage is pending (interactionFloorFps applies)
 * @property {boolean} hookKeep  a frame hook asked for the next frame
 * @property {boolean} wake  a hook was asked to run once without damage
 * @property {boolean} dispatching  inside firePaint
 * @property {boolean} due  the cap allowed a frame in the current tick
 * @property {boolean} committed  commitLanded ran for this canvas in the current tick
 * @property {Set<Element>} changed  committed since the last paint event
 * @property {Set<Element>} marked  listed by markChanged since the last paint event: they join the next paint event's changedElements but never fire one
 * @property {Set<Element>} removed
 * @property {number} batches  commits merged into `changed` (more than one: the order is no longer the store's)
 * @property {boolean} afterNested  a canvas nested in its drawables fired a paint (its handler may have drawn into the bitmap the snapshot shows): the next paint waits for a fresh snapshot
 * @property {boolean} resized  resize / DPR damage is pending: this tick builds inside the rendering update (see runTick)
 * @property {number} firedFrame  the tick (frame) in whose interval this canvas last fired a paint: at most one per frame
 * @property {number|null} firstSince  when the canvas, never painted yet, last got a drawable (firstDue: the window in which its first snapshot is built inside the frame)
 */

/** Damage that comes from the user's hands: it may use options.interactionFloorFps. */
const INTERACTION_CAUSES = new Set(['input', 'selection', 'focus', 'hover', 'active', 'scroll']);
/**
 * Discrete user actions whose tile is built at once, in a microtask of the input task itself: after discrete input Chrome runs the rendering update before
 * any ordinary or user-blocking task, so only work done inside the input task can land before that frame. Damage published with `urgent` (a value change of a non-text control) too.
 */
const URGENT_CAUSES = new Set(['focus', 'active']);
/** ms without scroll damage after which the next one starts a new scroll stream */
const SCROLL_STREAM_GAP_MS = 200;
/** ms after a window resize event during which every build stays inside the rendering update */
const RESIZE_IN_FRAME_MS = 100;
/** A tick whose rAF timestamp is this many frame periods after the previous consecutive tick is late. */
const LATE_FRAME_FACTOR = 1.5;
/** PumpBudget.mainThreadMs: no new build starts after this many ms of synchronous time in one pump (checked between builds; one build can run longer) */
const PUMP_MAIN_THREAD_MS = 4;
const PUMP_MAIN_THREAD_SHARE = 0.35;
const PUMP_MAX_IN_FLIGHT = 2;
/**
 * The loop sleeps (no rAF, one timer) only when the pump has nothing to start for at least this long (PumpResult.quietUntil), and the timer arms the tick
 * QUIET_WAKE_FRAMES frame periods before that time, so the build starts in the same frame as when the loop polled.
 */
const QUIET_MIN_MS = 50;
const QUIET_WAKE_FRAMES = 2;
/**
 * Window property (symbol) through which the scheduler of a parent document runs the tick of a same-origin child document that has its own install, so the canvases
 * of an iframe inside a drawable paint before the canvases that contain the iframe (reverse shadow-including tree order across frames, WPT onpaint-iframe-post-tree-order).
 */
const FRAME_TICK = Symbol.for('hic.frame-tick');

/** @param {CanvasRecord} record @returns {Entry} */
function createEntry(record) {
  return {
    record, registered: false, hooks: new Set(), dirty: false, interaction: false, hookKeep: false, wake: false,
    dispatching: false, due: false, committed: false, changed: new Set(), marked: new Set(), removed: new Set(), batches: 0, afterNested: false, resized: false, firedFrame: -1, firstSince: null,
  };
}

/**
 * Implements Scheduler (docs/ARCHITECTURE.md ADR-C). TWO phases per frame through frame-phase.js: the rAF ARM callback (arms the sentinel observer) and the frame-end RUN in a fresh ResizeObserver callback
 * (after app rAF callbacks, style/layout and earlier ResizeObservers). RUN, per canvas in reverse tree order: cap gate, paint gate (paint-gate.js), commitLanded, paint dispatch; then the frame hooks. ONE store pump for all canvases runs in a task posted after the rendering update (queuePump).
 * paintNow(record) is the same dispatch from a microtask (canvas width/height setters), at most one per frame. Zero rAF and zero ResizeObserver when idle; the only timers are the caret blink while a text control is focused (observers/; no idle poll)
 * and the end of a quiet wait (afterPump: the only work left is a build deferred to a known time).
 *
 * Cap semantics: the cap bounds paint events AND frame hooks (one cap gate per canvas, advanced only on ticks that have work). requestPaint() honours the cap too; paintNow() does not (the app just cleared the bitmap: skipping a frame would show it blank).
 * `interactionFloorFps` (default 0 = strict) raises a finite cap for user-driven damage only; it never lifts options.maxSnapshotFps, which the store applies to build starts.
 * @param {HicEnv} env
 * @param {SnapshotStore} store
 * @param {SchedulerHooks} hooks
 * @returns {Scheduler}
 */
export function createScheduler(env, store, hooks) {
  /** @type {Map<CanvasRecord, Entry>} */
  const entries = new Map();
  const capGate = createCapGate();
  const gate = createPaintGate(env, store);
  const counters = { frames: 0, paintsFired: 0, lateFrames: 0, gateTimeouts: 0 };
  const phase = createFramePhase(env, runTick);
  let registeredCount = 0;
  let armed = false;
  let disposed = false;
  /** @type {Set<Element>|null} elements the store reported through BUS.COMMIT during the current commitLanded call */
  let commitSeen = null;
  let lastTickAt = -1;
  let framePeriod = Infinity;
  let chained = false;
  let auditQueued = false;
  // Builds run in a task AFTER the rendering update: a build costs clone + CSS + serialise and forced style/layout, which inside the frame-end tick
  // delayed the frame itself (every long task of a wheel stream or a large-DOM update was BeginMainFrame). The commit and the paint dispatch stay in the tick.
  let pumpQueued = false;
  let pumpInteraction = false;
  let urgentQueued = false;
  let lastScrollAt = -Infinity;
  /** ticks started so far: the id of the current frame interval (a tick and the tasks that follow it until the next tick) */
  let frameId = 0;
  /** @type {Set<Entry>} canvases with a tile that landed at once (BUS.LANDED), served by the microtask queued after the landings */
  const early = new Set();
  let earlyQueued = false;
  /** @type {MessageChannel|null} created on first use (an install without canvases never opens a port) */
  let pumpChannel = null;
  /** the timer that ends a quiet wait (afterPump), 0 = none */
  let quietTimer = 0;

  const offCommit = env.bus.on(BUS.COMMIT, onCommit);
  const offLanded = env.bus.on(BUS.LANDED, (/** @type {{record: CanvasRecord}} */ e) => {
    const entry = entries.get(e.record);
    if (!entry?.registered) return;
    early.add(entry);
    if (earlyQueued) return;
    earlyQueued = true;
    queueMicrotask(serveEarly);
  });
  const offState = env.bus.on(BUS.CANVAS_STATE, (/** @type {{record: CanvasRecord, state: string}} */ e) => {
    const entry = entries.get(e.record);
    if (entry?.registered && e.state === 'active') resume(entry, 'content-attr');
  });
  // A drawable added to / removed from a mounted canvas: the store tracks it (forced damage) but only the scheduler can arm a tick to build, commit and paint it.
  // ... and so is a drawable that the surface budget held back once memory is freed (an ElementImage closed), or one without a CSS box once it has one: neither
  // ticks while it waits for that.
  const onStoreWork = (/** @type {{record: CanvasRecord}} */ e) => {
    const entry = entries.get(e.record);
    if (!entry?.registered) return;
    entry.dirty = true;
    armTick();
  };
  const offDrawables = env.bus.on(BUS.DRAWABLES_CHANGED, onStoreWork);
  const offFreed = env.bus.on(BUS.MEMORY_FREED, onStoreWork);
  const offBoxed = env.bus.on(BUS.DRAWABLE_BOXED, onStoreWork);
  /**
   * Called by the scheduler of the parent document, inside its own tick (the parent's rendering update runs before this document's): run this document's tick now when one
   * is armed. Returns true while a paint of this document is still owed (held), so the parent holds the canvas that contains the iframe too.
   * @param {number} now
   * @returns {boolean}
   */
  const tickForParent = (now) => {
    if (disposed) return false;
    if (armed) {
      try { runTick(now); } catch (err) { env.reporter.caught(err, 'schedule.frame-tick'); }
    }
    for (const entry of entries.values()) if (entry.registered && isServable(entry) && (entry.record.paint.force || entry.changed.size > 0 || entry.removed.size > 0)) return true;
    return false;
  };
  try {
    Object.defineProperty(env.window, FRAME_TICK, { value: tickForParent, configurable: true, writable: true, enumerable: false });
  } catch { /* a frozen or proxied window: frames are then ordered by their own ticks only */ }
  const onVisibility = () => {
    if (env.document.hidden) return;
    for (const entry of entries.values()) if (entry.registered) resume(entry);
  };
  env.document.addEventListener('visibilitychange', onVisibility);
  // while the window is being resized every frame is long, so a post-frame build lands a frame late; the damage of a resize step is not only the canvas's own 'resize'
  // (layout inside it, re-rasters of the geometry check): every build stays inside the rendering update until the resizing has paused (measured: convergence max 25 -> 17 ms)
  let resizingUntil = -Infinity;
  const onWindowResize = () => { resizingUntil = env.now() + RESIZE_IN_FRAME_MS; };
  env.window.addEventListener?.('resize', onWindowResize, { passive: true });

  /** @param {CanvasRecord} record */
  function ensure(record) {
    let entry = entries.get(record);
    if (!entry) entries.set(record, (entry = createEntry(record)));
    return entry;
  }

  function armTick() {
    if (disposed || registeredCount === 0) return;
    endQuiet();
    armed = true;
    phase.arm();
  }

  /**
   * Full damage and a forced paint: first mount, hidden tab shown again, canvas active again. The gate clocks and the cap phase must not carry the time spent invisible.
   * A mount or a canvas active again comes from the page (its content attribute, an insertion, a move): its damage is `content-attr`, damage from outside the
   * pipeline, so that a page that toggles a canvas many times a second is not taken for a feedback loop by the runaway guard (it was `forced`, which the guard
   * counts as the pipeline's own: 90 such remounts in 3 s uninstalled the polyfill). Rendering treats both alike (damage.js STRUCTURAL, store.js RETRY_CAUSES).
   * @param {Entry} entry @param {'content-attr'|'forced'} [cause]
   */
  function resume(entry, cause = 'forced') {
    const paint = entry.record.paint;
    paint.waitingSince = null;
    paint.gateReason = null;
    entry.firstSince = null;
    // A canvas without a drawable has nothing to snapshot: native fires no paint for it (WPT moved-webgl-canvas would see an exception thrown by its handler); the first drawable added damages it.
    paint.force = (entry.record.layer?.drawableElements().length ?? 0) > 0;
    capGate.reset(entry.record.id);
    api.damage(entry.record, cause, null, null);
  }

  /** @param {{record: CanvasRecord, changed: Element[], removed: Element[]}} change */
  function onCommit(change) {
    const entry = entries.get(change.record);
    if (!entry?.registered) return;
    for (const el of change.changed) {
      entry.changed.add(el);
      commitSeen?.add(el);
    }
    for (const el of change.removed) {
      entry.removed.add(el);
      commitSeen?.add(el);
    }
    entry.batches++;
  }

  /**
   * Elements of the returned change set that no BUS.COMMIT announced (a store that only returns the set): attribute them through the registry.
   * @param {ChangeSet|undefined} cs
   * @param {Set<Element>} seen
   */
  function attributeLeftovers(cs, seen) {
    if (!cs) return;
    for (const [list, key] of /** @type {Array<[Element[], 'changed'|'removed']>} */ ([[cs.changed, 'changed'], [cs.removed, 'removed']])) {
      for (const el of list) {
        if (seen.has(el)) continue;
        const owner = env.registry.ownerOfDrawable(el);
        const entry = owner && entries.get(owner);
        if (entry?.registered) {
          entry[key].add(el);
          entry.batches++;
        }
      }
    }
  }

  /** @param {Entry} entry */
  function commit(entry) {
    const seen = (commitSeen = new Set());
    /** @type {ChangeSet|undefined} */
    let cs;
    try {
      // a forced paint (requestPaint(), first mount, shown again) reports the DOM as it is now: no superseded tile may stand in for it
      cs = store.commitLanded(entry.record, { current: entry.record.paint.force });
    } finally {
      commitSeen = null;
    }
    entry.committed = true;
    attributeLeftovers(cs, seen);
  }

  /**
   * changedElements: the committed drawables in tree order, plus the drawable ancestor of every removed NESTED drawable (a removed top-level drawable lists nothing).
   * A drawable committed while the paint was held and no longer a drawable of the canvas when it fires is left out: it is not rendered in the canvas any more
   * (WPT onpaint-remove-drawable-element reported a removed element whose tile had been committed during a coherence hold).
   * @param {Entry} entry
   * @returns {Element[]}
   */
  function changedElements(entry) {
    const layer = entry.record.layer;
    const listed = entry.marked.size ? new Set([...entry.changed, ...entry.marked]) : entry.changed;
    const current = listed.size && layer ? new Set(layer.drawableElements()) : null;
    const out = new Set(current ? [...listed].filter((el) => current.has(el)) : listed);
    let added = false;
    for (const el of entry.removed) {
      const parent = el.parentNode;
      const ancestor = parent && layer ? layer.nearestDrawable(parent) : null;
      if (ancestor && !out.has(ancestor)) {
        out.add(ancestor);
        added = true;
      }
    }
    const list = [...out];
    if ((added || entry.batches > 1 || entry.marked.size) && list.length > 1) list.sort(shadowIncludingOrder);
    return list;
  }

  /** @param {Entry} entry */
  function fire(entry) {
    const { record } = entry;
    const paint = record.paint;
    const list = changedElements(entry);
    entry.changed.clear();
    entry.marked.clear();
    entry.removed.clear();
    entry.batches = 0;
    paint.force = false;
    paint.serial++;
    paint.lastFireAt = env.now();
    paint.everFired = true;
    entry.firedFrame = frameId;
    counters.paintsFired++;
    entry.dispatching = true;
    try {
      hooks.firePaint(record, list);
    } catch (err) {
      env.reporter.caught(err, 'schedule.firePaint');
    } finally {
      entry.dispatching = false;
    }
  }

  /**
   * Gate, commit and dispatch of one canvas. Returns false while the gate holds the paint.
   * @param {Entry} entry
   * @param {number} now
   * @param {boolean} landed  the store has landed results
   */
  function servePaint(entry, now, landed) {
    const { record } = entry;
    const paint = record.paint;
    const before = paint.gateReason;
    const verdict = gate.evaluate(record, now);
    if (!verdict.open) return false;
    if (verdict.reason === 'timeout') {
      counters.gateTimeouts++;
      env.reporter.deviation('paint-timing', `paint fired after the ${before ?? 'first-commit'} gate wait cap elapsed; a draw of a drawable that still has no snapshot throws InvalidStateError (raise options.paintGateMaxWaitMs, or split a very large drawable)`);
    }
    const waitingSince = paint.waitingSince;
    if (paint.force || landed) commit(entry);
    // The commit can drop a stale tile (damage of a newer epoch arrived while it decoded): a draw in the handler would then throw for lack of a snapshot. Ask the gate again.
    if (verdict.reason !== 'timeout' && !gate.evaluate(record, now).open) {
      if (waitingSince !== null) paint.waitingSince = waitingSince;
      return false;
    }
    if (holdsForFreshness(entry, now)) return false;
    if (paint.force || entry.changed.size || entry.removed.size) fire(entry);
    return true;
  }

  /** @type {WeakMap<Element, HTMLCollectionOf<HTMLIFrameElement>>} live iframe collections of the layers (cheap to read while the DOM does not change) */
  const layerFrames = new WeakMap();

  /**
   * Same-origin iframes inside the drawables of `entry` whose document runs its own install: their ticks run first, so their canvases paint before this one.
   * Returns true while one of them still owes a paint; this canvas is then held like one that contains a held nested canvas (bounded by options.paintGateMaxWaitMs).
   * @param {Entry} entry
   * @param {number} now
   * @returns {boolean}
   */
  function holdsForFrames(entry, now) {
    const layerEl = entry.record.layer?.element;
    if (!layerEl?.getElementsByTagName) return false;
    let frames = layerFrames.get(layerEl);
    if (!frames) layerFrames.set(layerEl, (frames = layerEl.getElementsByTagName('iframe')));
    if (!frames.length) return false;
    let owed = false;
    for (const frame of frames) {
      try {
        const tick = /** @type {any} */ (frame.contentWindow)?.[FRAME_TICK];
        if (typeof tick === 'function' && tick(now) === true) owed = true;
      } catch { /* cross-origin: no access, no ordering */ }
    }
    if (!owed) return false;
    const paint = entry.record.paint;
    paint.holdSince ??= now;
    if (now - paint.holdSince >= env.options.paintGateMaxWaitMs) { paint.holdSince = null; return false; }
    return true;
  }

  /**
   * A canvas inside the drawables of another one paints first (reverse tree order), and the outer snapshot shows its bitmap: while the nested canvas is still held back (no first snapshot, or its own wait),
   * the outer paint stays back as well, so `captureElementImage` of a nested drawable works in the outer handler and the nested handler has drawn before the outer one runs (WPT nested-content-drawable-canvas).
   * Bounded by options.paintGateMaxWaitMs like every other hold.
   * A nested canvas that DID fire this tick makes the outer one wait for the next tick (the microtask that damages the outer drawable after the nested handler drew has not run yet) and then for a fresh snapshot.
   * @param {Entry} entry
   * @param {Entry[]} held
   * @param {Entry[]} fired
   * @param {number} now
   * @returns {boolean}
   */
  function holdsForNested(entry, held, fired, now) {
    const paint = entry.record.paint;
    const layerEl = entry.record.layer?.element;
    const inside = (/** @type {Entry} */ h) => !!layerEl && layerEl.contains(h.record.canvas);
    if (fired.some(inside)) {
      entry.afterNested = true;
      return true;
    }
    const blocked = held.some(inside);
    if (!blocked) return false;
    paint.holdSince ??= now;
    if (now - paint.holdSince >= env.options.paintGateMaxWaitMs) { paint.holdSince = null; return false; }
    return true;
  }

  /**
   * requestPaint() asks for a paint of the DOM as it is NOW (native snapshots every drawable in the rendering update that fires the event), so a style or content change made right before the call
   * must be in the snapshot the handler draws (WPT `child.style.width = '150px'; await waitForCanvasPaint(canvas); captureElementImage(child)`). The pump builds after the paint step of a tick, so a forced paint with
   * damage still waiting would present the OLD snapshot. It is held until the builds land (their commit makes the paint fire anyway) for at most options.paintGateMaxWaitMs. A paint with changes to report is never held,
   * so a requestPaint() loop over animating content is paced by the commits, exactly like a paint that no one requested.
   * @param {Entry} entry
   * @param {number} now
   * @returns {boolean} true while the paint stays back
   */
  function holdsForFreshness(entry, now) {
    const { record } = entry;
    const paint = record.paint;
    const unseen = paint.force && entry.changed.size === 0 && entry.removed.size === 0;
    const stale = env.options.coherentPaint && (unseen || entry.afterNested) && !store.isFresh(record);
    if (!stale) {
      entry.afterNested = false;
      paint.holdSince = null;
      return false;
    }
    paint.holdSince ??= now;
    if (now - paint.holdSince >= env.options.paintGateMaxWaitMs) {
      paint.holdSince = null;
      return false;
    }
    return true;
  }

  /**
   * The first snapshot of the canvas is still due: it never painted, has a drawable, and has waited less than options.paintGateMaxWaitMs since it got one. A canvas that
   * never paints (no drawable at all, or one added after the mount that has no box or never commits: no forced paint is owed then) kept asking, and every tick it took
   * part in pumped inside the frame, where the side builds of every other canvas (scroll plans and pages) wait; their leftover work made it tick again (iOS Simulator,
   * the scroll-and-resize example beside an empty canvas: 0 composed scroll steps instead of 211, the scheduler ticking at 61 Hz while idle).
   * @param {Entry} entry @param {number} now
   */
  function firstDue(entry, now) {
    if (entry.record.paint.everFired || !(entry.record.layer?.drawableElements().length ?? 0)) { entry.firstSince = null; return false; }
    entry.firstSince ??= now;
    return now - entry.firstSince < env.options.paintGateMaxWaitMs;
  }

  /** @param {Entry} entry */
  function hasWork(entry) {
    return entry.dirty || entry.record.paint.force || entry.wake || entry.hookKeep || entry.changed.size > 0 || entry.removed.size > 0;
  }

  /** @param {Entry} entry */
  function isServable(entry) {
    const state = entry.record.state;
    return state === 'active' || state === 'mounting';
  }

  /** @returns {Entry[]} registered entries, last canvas in tree order first */
  function orderedEntries() {
    /** @type {Entry[]} */
    const out = [];
    const all = env.registry.all();
    for (let i = all.length - 1; i >= 0; i--) {
      const entry = entries.get(all[i]);
      if (entry?.registered) out.push(entry);
    }
    if (out.length < registeredCount) {
      const listed = new Set(out);
      for (const entry of entries.values()) if (entry.registered && !listed.has(entry)) out.push(entry);
    }
    return out;
  }

  /** @param {number} now */
  function noteLateness(now) {
    if (chained && lastTickAt >= 0) {
      const gap = now - lastTickAt;
      if (gap > 1 && gap < framePeriod) framePeriod = gap;
      if (gap > framePeriod * LATE_FRAME_FACTOR) counters.lateFrames++;
    }
    lastTickAt = now;
  }

  /**
   * The store paces builds (snapshot-rate gate, cost bucket) in FRAME time: the timestamp of the last rendering update plus whole frame periods, not the time the
   * post-frame task happened to run. That delay varies by milliseconds with the frame's work and the machine load, and the gate compared it with thresholds that
   * fall on whole 120 Hz frames: whether a change was built one or two frames later flipped run to run (WPT onpaint).
   * @param {number} now
   * @param {boolean} interaction
   * @param {boolean} [urgent]
   * @returns {PumpResult|null}
   */
  function pump(now, interaction, urgent = false) {
    if (lastTickAt >= 0 && framePeriod < Infinity && now >= lastTickAt) now = lastTickAt + Math.floor((now - lastTickAt) / framePeriod) * framePeriod;
    try {
      return store.pump(now, { mainThreadMs: PUMP_MAIN_THREAD_MS, mainThreadShare: PUMP_MAIN_THREAD_SHARE, maxInFlight: PUMP_MAX_IN_FLIGHT, interaction, urgent });
    } catch (err) {
      env.reporter.caught(err, 'schedule.pump');
      return null;
    }
  }

  /** @param {boolean} interaction */
  function queuePump(interaction) {
    pumpInteraction ||= interaction;
    if (pumpQueued) return;
    pumpQueued = true;
    // A user-blocking task (Prioritized Task Scheduling) runs right after the rendering update, before the ordinary tasks queued before or during it (an app's setTimeout from
    // its rAF, the IntersectionObserver delivery): a tile that lands at once is then painted after the frame computed its observations and before the app's next task, as close to
    // the native paint step as a task can be. Without the API, a MessageChannel task (queue order).
    const postTask = /** @type {any} */ (env.window).scheduler?.postTask;
    if (typeof postTask === 'function') {
      try {
        postTask.call(/** @type {any} */ (env.window).scheduler, runPumpTask, { priority: 'user-blocking' }).catch(() => {});
        return;
      } catch { /* fall through to the channel */ }
    }
    if (!pumpChannel) {
      const MC = /** @type {typeof MessageChannel} */ ((/** @type {any} */ (env.window)).MessageChannel ?? globalThis.MessageChannel);
      pumpChannel = new MC();
      pumpChannel.port1.onmessage = () => runPumpTask();
    }
    pumpChannel.port2.postMessage(0);
  }

  /** The urgent build (URGENT_CAUSES): one pump in a microtask of the current input task, so the decode can land before the next rendering update. */
  function urgentPump() {
    if (urgentQueued) return;
    urgentQueued = true;
    queueMicrotask(() => {
      urgentQueued = false;
      if (disposed) return;
      afterPump(pump(env.now(), true, true), true);
    });
  }

  /** The post-frame build task: start what is due, then keep the canvases that still have work ticking (decodes land in a later frame's commit). */
  function runPumpTask() {
    pumpQueued = false;
    if (disposed) return;
    const interaction = pumpInteraction;
    pumpInteraction = false;
    afterPump(pump(env.now(), interaction), interaction);
  }

  /** @param {PumpResult|null} pumped @param {boolean} interaction */
  function afterPump(pumped, interaction) {
    let again = false;
    for (const entry of entries.values()) {
      if (!entry.registered || !isServable(entry)) continue;
      if (pumped?.moreWork || !isSettled(entry)) {
        entry.dirty = true;
        if (interaction) entry.interaction = true;
        again = true;
      }
    }
    if (!again) return;
    if (pumped?.quietUntil != null && mayRest(pumped.quietUntil)) rest(pumped.quietUntil);
    else armTick();
  }

  /**
   * May the loop stop until `until`? Only when the store's sole work is damage the pump deferred to then (PumpResult.quietUntil: nothing building, decoding or
   * landed) and the scheduler owes nothing itself: no paint owed, held or waiting for the frame cap, no hook that asked for frames, no pump or early paint queued,
   * no resize or first snapshot in progress. Anything that arrives later (damage, input, a landed tile, requestPaint, a wake) arms the tick and ends the wait.
   * @param {number} until
   */
  function mayRest(until) {
    const now = env.now();
    if (until - now < QUIET_MIN_MS || pumpQueued || urgentQueued || earlyQueued || now < resizingUntil || store.hasLanded()) return false;
    for (const entry of entries.values()) {
      if (!entry.registered || !isServable(entry) || !hasWork(entry)) continue;
      const paint = entry.record.paint;
      if (paint.force || paint.waitingSince !== null || entry.hookKeep || entry.wake || entry.resized || !entry.due || entry.changed.size || entry.removed.size) return false;
      if (!paint.everFired && (entry.record.layer?.drawableElements().length ?? 0) > 0) return false;
    }
    return true;
  }

  /** Stop the frame loop until shortly before `until` (one timer; armTick ends it earlier). @param {number} until */
  function rest(until) {
    endQuiet();
    phase.cancel(true);
    armed = chained = false;
    quietTimer = env.window.setTimeout(() => { quietTimer = 0; armTick(); }, Math.max(0, until - env.now() - QUIET_WAKE_FRAMES * Math.min(framePeriod, 1000 / 60)));
  }

  function endQuiet() {
    if (quietTimer) env.window.clearTimeout(quietTimer);
    quietTimer = 0;
  }

  /** @param {Entry} entry @param {number} now */
  function runHooks(entry, now) {
    let keep = false;
    for (const hook of [...entry.hooks]) {
      try {
        if (hook(now, { frameCap: entry.record.frameCap, due: entry.due }) === true) keep = true;
      } catch (err) {
        env.reporter.caught(err, 'schedule.frame-hook');
      }
    }
    entry.hookKeep = keep;
  }

  /** @param {Entry} entry */
  function isSettled(entry) {
    for (const el of entry.record.layer?.drawableElements() ?? []) if (store.has(el) && !store.isSettled(el)) return false;
    return true;
  }

  /**
   * Does the canvas need another frame? A hook asked, a paint is owed or held, the cap deferred it, the store still builds/decodes/has landed results.
   * (Work the post-frame pump defers re-arms the tick from the pump task.)
   * @param {Entry} entry
   */
  function needsTick(entry) {
    const paint = entry.record.paint;
    if (paint.force || entry.hookKeep || entry.changed.size > 0 || entry.removed.size > 0) return true;
    if (paint.waitingSince !== null || !entry.due) return true;
    if (!entry.committed && store.hasLanded(entry.record)) return true;
    return !isSettled(entry);
  }

  /**
   * The stacking audit needs the hit-test rules of the draws of this very tick, which the geometry layer flushes in a microtask; so it runs in one that is queued after them.
   * The layer rate-limits it (and skips it while nothing is drawn), so a busy canvas pays for it twice a second.
   */
  function queueStackingAudit() {
    if (auditQueued) return;
    auditQueued = true;
    queueMicrotask(() => {
      auditQueued = false;
      if (disposed) return;
      for (const entry of entries.values()) {
        if (!entry.registered || !isServable(entry)) continue;
        try {
          entry.record.layer?.stackingAudit();
        } catch (err) {
          env.reporter.caught(err, 'schedule.stacking-audit');
        }
      }
    });
  }

  /**
   * May this canvas paint outside the tick, right where its tile landed? Only when nothing could tell the difference from a tick: no paint fired in this frame interval yet
   * (at most one per frame), no frame cap (the cap gate paces ticks), no paint being dispatched, and no canvas nested in its drawables or around it (their order and
   * holds are decided across canvases by runTick).
   * @param {Entry} entry
   */
  function canServeEarly(entry) {
    if (!isServable(entry) || entry.dispatching || entry.firedFrame === frameId) return false;
    if (effectiveFps(entry.record.frameCap, env.options, 'paint', entry.interaction) > 0) return false;
    const layerEl = entry.record.layer?.element;
    for (const other of entries.values()) {
      if (other === entry || !other.registered) continue;
      if (layerEl?.contains(other.record.canvas) || other.record.layer?.element.contains(entry.record.canvas)) return false;
    }
    return true;
  }

  /**
   * A tile decoded at once (store/decode.js decodedAtOnce) landed in the task that built it. Its paint does not wait for the next tick: inside the rendering update (the first
   * snapshot and resize builds run in the tick) it fires in the same frame, like the native paint event; after the frame (the post-frame build task) it fires in that task,
   * before the tasks the rendering update queued (IntersectionObserver delivery) and a frame earlier than the next tick. The canvas pixels drawn there are presented by the
   * next frame either way. Same gates as a tick (servePaint); canvases that do not qualify (canServeEarly) wait for the tick as before.
   */
  function serveEarly() {
    earlyQueued = false;
    if (disposed || !early.size) { early.clear(); return; }
    const now = env.now();
    let committed = false;
    for (const entry of orderedEntries()) {
      if (!early.has(entry) || !canServeEarly(entry) || !store.hasLanded(entry.record)) continue;
      try {
        const serial = entry.record.paint.serial;
        entry.committed = false;
        servePaint(entry, now, true);
        committed ||= entry.committed;
        if (entry.record.paint.serial !== serial && entry.hooks.size) entry.wake = true;
      } catch (err) {
        env.reporter.caught(err, 'schedule.paint');
      }
      entry.dirty = true;
    }
    early.clear();
    if (committed) {
      queueStackingAudit();
      // the geometry check the store owes after a commit runs in the pump: in the task right after this one, not in a pump that the next tick would leave queued
      queuePump(false);
    }
    armTick();
  }

  /** @param {number} now */
  function runTick(now) {
    armed = false;
    frameId++;
    noteLateness(now);
    /** @type {Entry[]} */
    const work = [];
    for (const entry of orderedEntries()) {
      if (!isServable(entry) || !hasWork(entry)) continue;
      entry.committed = false;
      entry.wake = false;
      entry.due = capGate.allow(entry.record.id, now, effectiveFps(entry.record.frameCap, env.options, 'paint', entry.interaction));
      work.push(entry);
    }
    let interaction = false;
    /** @type {Entry[]} canvases whose paint stayed back this tick: the canvases that contain them wait too */
    const held = [];
    /** @type {Entry[]} canvases that fired a paint this tick: the canvases that contain them must show what their handlers drew, so they paint later */
    const fired = [];
    for (const entry of work) {
      interaction ||= entry.interaction;
      if (!entry.due) continue;
      try {
        if (holdsForFrames(entry, now) || holdsForNested(entry, held, fired, now)) { held.push(entry); continue; }
        const serial = entry.record.paint.serial;
        if (!servePaint(entry, now, store.hasLanded(entry.record))) held.push(entry);
        else if (entry.record.paint.serial !== serial) fired.push(entry);
      } catch (err) {
        env.reporter.caught(err, 'schedule.paint');
      }
    }
    // a resize frame is long (the page relayouts) and the browser runs the NEXT rendering update before a task posted from it, so a post-frame build would land a frame later
    // (measured: resize convergence p95 17 -> 25 ms); resize / DPR damage is built inside the tick. Everything else builds after the frame.
    // ... and so is the FIRST snapshot of a canvas (so its first paint is not a frame late: WPT onpaint-zindex expects the initial paint within the first frame).
    const resized = now < resizingUntil || work.some((entry) => entry.resized || firstDue(entry, now));
    const pumped = resized ? pump(now, interaction, true) : null;
    if (resized) for (const entry of work) entry.resized = false;
    // no pump without something to build: a pump task left queued behind a quiet frame would take the next DOM change BEFORE the rendering update that should observe it
    // (its tile then lands, and paints, ahead of that frame's IntersectionObserver steps)
    else if (work.length && (store.needsPump?.() ?? true)) queuePump(interaction);
    for (const entry of work) runHooks(entry, now);
    counters.frames++;
    if (work.some((entry) => entry.committed)) queueStackingAudit();
    let again = false;
    for (const entry of work) {
      entry.dirty = needsTick(entry) || !!pumped?.moreWork;
      if (!entry.dirty) entry.interaction = false;
      again ||= entry.dirty;
    }
    chained = again;
    if (again) armTick();
  }

  /**
   * @param {CanvasRecord} record
   * @param {DamageCause} cause
   * @param {Element|null} drawable
   * @param {Rect|null} rect
   */
  function markStore(record, cause, drawable, rect) {
    try {
      if (drawable) {
        store.markDamage(drawable, rect, cause);
        return;
      }
      for (const el of record.layer?.drawableElements() ?? []) if (store.has(el)) store.markDamage(el, null, cause);
    } catch (err) {
      env.reporter.caught(err, 'schedule.damage');
    }
  }

  /** @type {Scheduler} */
  const api = {
    register(record) {
      const entry = ensure(record);
      if (entry.registered) return;
      entry.registered = true;
      registeredCount++;
      record.frameCap = parseFrameCap(record.canvas.getAttribute(EXT.FRAME_CAP_ATTR), env.options.defaultFrameCap);
      record.dpr = env.window.devicePixelRatio || 1;
      resume(entry, 'content-attr');
    },

    unregister(record) {
      const entry = entries.get(record);
      if (!entry) return;
      if (entry.registered) registeredCount--;
      entries.delete(record);
      capGate.reset(record.id);
      if (registeredCount === 0) {
        phase.cancel();
        endQuiet();
        armed = false;
      }
    },

    requestPaint(record) {
      const entry = entries.get(record);
      if (!entry?.registered) return;
      record.paint.force = true;
      entry.dirty = true;
      armTick();
    },

    markChanged(record, elements) {
      const entry = entries.get(record);
      if (!entry?.registered) return;
      // listed by the next paint event of this canvas, whatever fires it; never a reason to fire one (native: an invalidation alone schedules no frame, and the
      // polyfill's own follow-up ticks have no native counterpart)
      for (const el of elements) entry.marked.add(el);
    },

    paintNow(record) {
      const entry = entries.get(record);
      if (!entry?.registered || !isServable(entry)) return false;
      const paint = record.paint;
      const serial = counters.frames + 1;
      if (entry.dispatching || paint.microtaskFrame === serial) {
        api.requestPaint(record);
        return false;
      }
      paint.force = true;
      entry.dirty = true;
      const fired = servePaint(entry, env.now(), store.hasLanded());
      if (fired) paint.microtaskFrame = serial;
      armTick();
      return fired;
    },

    setFrameCap(record, fps) {
      const next = clampFrameCap(fps);
      if (record.frameCap === next) return;
      record.frameCap = next;
      capGate.reset(record.id);
      if (entries.get(record)?.dirty) armTick();
    },

    addFrameHook(record, hook) {
      const entry = ensure(record);
      entry.hooks.add(hook);
      return () => {
        entry.hooks.delete(hook);
        if (!entry.hooks.size) entry.hookKeep = false;
      };
    },

    wake(record) {
      const entry = entries.get(record);
      if (!entry?.registered) return;
      entry.wake = true;
      armTick();
    },

    damage(record, cause, drawable = null, rect = null, urgent = false) {
      const entry = entries.get(record);
      if (!entry?.registered) return;
      markStore(record, cause, drawable, rect);
      env.bus.emit(BUS.DAMAGE, { record, drawable, rect, cause, t: env.now() });
      entry.dirty = true;
      if (INTERACTION_CAUSES.has(cause)) entry.interaction = true;
      // and the FIRST scroll step of a stream: during a wheel scroll animation the browser runs rendering updates back to back and starves posted tasks, so a post-frame
      // build of that step was drawn 70-80 ms late (later steps are composed from cached pages; their fallback builds stay after the frame, where they cost no frame time)
      const streamStart = cause === 'scroll' && env.now() - lastScrollAt > SCROLL_STREAM_GAP_MS;
      if (cause === 'scroll') lastScrollAt = env.now();
      if (cause === 'resize' || cause === 'dpr' || streamStart) entry.resized = true;
      armTick();
      if (urgent || URGENT_CAUSES.has(cause)) urgentPump();
    },

    stats() {
      return { ...counters, phaseFallbacks: phase.stats().fallbacks };
    },

    dispose() {
      if (disposed) return;
      disposed = true;
      offCommit();
      offLanded();
      offState();
      offDrawables();
      offFreed();
      offBoxed();
      env.document.removeEventListener('visibilitychange', onVisibility);
      env.window.removeEventListener?.('resize', onWindowResize);
      try {
        if (/** @type {any} */ (env.window)[FRAME_TICK] === tickForParent) delete (/** @type {any} */ (env.window))[FRAME_TICK];
      } catch { /* see install */ }
      phase.cancel();
      endQuiet();
      if (pumpChannel) {
        pumpChannel.port1.onmessage = null;
        pumpChannel.port1.close();
        pumpChannel = null;
      }
      entries.clear();
      early.clear();
      registeredCount = 0;
      armed = false;
    },
  };

  return api;
}
