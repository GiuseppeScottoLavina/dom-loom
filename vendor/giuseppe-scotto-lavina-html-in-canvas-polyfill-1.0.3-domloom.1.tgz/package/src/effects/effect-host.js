/**
 * EffectHost implementation (docs/ARCHITECTURE.md ADR-G).
 * Module: gpu-effects (src/effects/**).
 */

import { HicUnsupportedError, invalidState, typeError } from '../contracts/errors.js';
import { BUS, EVENTS } from '../contracts/events.js';
import { createPluginSet } from './effect-plugins.js';
import { nativeFrameSource, schedulerFrameSource } from './frame-source.js';
import { createPresenter } from './gpu-presenter.js';
import { createMapperChain } from './input-mapper.js';
import { createInterposer } from './interposer.js';
import { contentBoxOf, createNativeGeometry } from './native-geometry.js';
import { createNativeInterposer } from './native-interposer.js';
import { isNoTarget } from './no-target.js';
import { captureMapper } from './plugin-abi.js';
import { createNativeSourceProvider, createStoreSourceProvider } from './source-provider.js';
import { watchVisibility } from '../util/visibility.js';

/** @typedef {import('../contracts/types.js').EffectHost} EffectHost */
/** @typedef {import('../contracts/types.js').EffectHostOptions} EffectHostOptions */
/** @typedef {import('../contracts/types.js').EffectPresentationFrame} EffectPresentationFrame */
/** @typedef {import('../contracts/types.js').EffectViewport} EffectViewport */
/** @typedef {import('../contracts/types.js').GeometryApi} GeometryApi */
/** @typedef {import('../contracts/types.js').HicEnv} HicEnv */
/** @typedef {import('../contracts/types.js').InputMapper} InputMapper */
/** @typedef {import('../contracts/types.js').InteractionTracker} InteractionTracker */
/** @typedef {import('../contracts/types.js').Scheduler} Scheduler */
/** @typedef {import('../contracts/types.js').SnapshotStore} SnapshotStore */
/** @typedef {import('./effect-plugins.js').Slot} Slot */
/** @typedef {import('./gpu-presenter.js').Presenter} Presenter */

/** More device losses than this inside the window stop the host from recreating the device again. */
const MAX_LOSSES = 3;
const LOSS_WINDOW_MS = 10000;
const FPS_WINDOW = 32;
/** While the canvas cannot be seen, an action that somebody awaits still advances: one frame every SETTLE_MS (10 per second). */
const SETTLE_MS = 100;

/**
 * Runs as a Scheduler FrameHook; uploads only when the source version advanced; renders when due; effecterror on plugin failure (plugin disabled, last frame kept). Keeps source geometry in sync via GeometryApi.
 * OFF-SCREEN PAUSE (ADR-G): while the canvas cannot be seen (util/visibility.js: outside the viewport by more than VISIBILITY_MARGIN, or the document hidden) nothing is rendered,
 * continuous plugins included; the frame clock keeps running (`frame.now` is the time of the frame), so on resume a time-based effect shows the state it has at that
 * time, with nothing replayed. Coming back into the margin renders at once. While paused, an unsettled trigger()/settled() still advances at 1000 / SETTLE_MS frames
 * per second, so its promise resolves; a hidden document runs no frames at all, so there it resolves on the first frame after the document is shown again.
 * DEVICE LOSS: `device.lost` is handled (ADR-G): keep presenting the last frame, recreate device, source/destination textures and every plugin pipeline (plugin.create is re-run with the same options), report once; covered by the host unit tests (test/unit/gpu-effects/host.browser.test.mjs), the gate G-fault-injection is planned (TEST-PLAN 2.7).
 * NATIVE MODE (no record: the browser implements HTML-in-Canvas and the polyfill stepped aside): the source comes from the standard
 * GPUQueue.drawElementImageToTexture (source-provider.js), frames from a rAF loop plus the canvas's paint event (frame-source.js), the
 * stretch and the pointer remap from the standard updateElementGeometry (native-geometry.js, native-interposer.js).
 * THE UNDER PAGE (EffectHostOptions.under, experimental): a second drawable of the canvas with a provider and a texture of its own (frame.under),
 * uploaded when its own version advanced; a frame renders when either version advanced. Both elements get the fill geometry, the source last, so
 * that the source stays above the under page in the hit-test order of the live layer. Without `under` none of this exists.
 * ACCESSIBILITY: the under element is `inert` (out of the tab order and of the accessibility tree) while the newest presented frame shows none of it,
 * which a plugin reports with `instance.revealsUnder` (read after each presented frame; absent = nothing shown). Before it becomes inert, a focused
 * element inside it is blurred, as a page does when it hides a dialog. An `inert` the author set is left alone.
 * @param {HicEnv} env
 * @param {{store: SnapshotStore, scheduler: Scheduler, geometry: GeometryApi, tracker: InteractionTracker}} deps
 * @param {HTMLCanvasElement} canvas
 * @param {Element} source
 * @param {EffectHostOptions} [options]
 * @returns {Promise<EffectHost>}
 * @throws InvalidStateError (source not eligible / canvas context conflict), HicUnsupportedError (no WebGPU)
 */
export async function createEffectHost(env, deps, canvas, source, options = {}) {
  const record = env.registry.get(canvas) ?? null;
  assertEligible(canvas, source, record);
  if (options.under != null) {
    try { assertUnder(env, canvas, source, options.under, record); } catch (error) {
      const e = /** @type {any} */ (error);
      if (e && e.feature) env.reporter.unsupported({ feature: e.feature, message: e.message, hint: e.hint }, canvas);
      throw error;
    }
  }
  if (!record) assertNativeApi(env, canvas, source);
  const runtime = new HostRuntime(env, deps, canvas, source, record, { ...options, maxDpr: options.maxDpr ?? env.options.maxDpr });
  try {
    await runtime.start();
  } catch (error) {
    runtime.destroy();
    const e = /** @type {any} */ (error);
    if (e && e.feature) env.reporter.unsupported({ feature: e.feature, message: e.message, hint: e.hint }, canvas);
    throw error;
  }
  return runtime.publicApi();
}

/**
 * @param {HTMLCanvasElement} canvas
 * @param {Element} source
 * @param {import('../contracts/types.js').CanvasRecord|null} record
 */
function assertEligible(canvas, source, record) {
  const eligible = record
    ? !!record.layer?.isMounted() && record.layer.drawableElements().includes(source)
    : source !== canvas && canvas.contains(source);
  if (!eligible) throw invalidState('createHost: `source` is not an eligible drawable of this canvas (it must be a drawable child, or a descendant marked drawable)');
}

/**
 * `under`: another eligible drawable of the same canvas, neither the source, nor inside it, nor around it.
 * @param {HicEnv} env
 * @param {HTMLCanvasElement} canvas
 * @param {Element} source
 * @param {unknown} under
 * @param {import('../contracts/types.js').CanvasRecord|null} record
 */
function assertUnder(env, canvas, source, under, record) {
  if (!(under instanceof /** @type {any} */ (env.window).Element)) throw typeError('createHost: `under` must be an Element when present');
  const el = /** @type {Element} */ (under);
  if (el === source || source.contains(el) || el.contains(source)) throw invalidState('createHost: `under` must be another drawable of the canvas, neither the source, nor inside it, nor around it');
  // Native mode: the browser draws both elements and orders their hit testing (measured, Chrome Canary 159), but the native interposer aims the
  // hit-test geometry of one element only; a point on the under page would need a second one, parked and aimed per pointer event. Refused until then.
  if (!record) throw new HicUnsupportedError('effects-under', 'createHost: `under` is not available over a native HTML-in-Canvas implementation yet (the pointer cannot be re-targeted to a second page there)', { hint: 'Create the host without `under` where createHost rejects with this feature: the plugin then shows its own background where the page is lifted.' });
  assertEligible(canvas, el, record);
}

/**
 * Native mode needs the standard GPU upload and the hit-test geometry of the browser; an earlier draft without them is refused loudly.
 * @param {HicEnv} env
 * @param {HTMLCanvasElement} canvas
 * @param {Element} source
 */
function assertNativeApi(env, canvas, source) {
  const win = /** @type {any} */ (env.window);
  const c = /** @type {any} */ (canvas);
  const missing = [
    typeof win.GPUQueue?.prototype?.drawElementImageToTexture !== 'function' && 'GPUQueue.drawElementImageToTexture',
    typeof c.updateElementGeometry !== 'function' && 'updateElementGeometry',
    typeof c.clearElementGeometry !== 'function' && 'clearElementGeometry',
    typeof c.getElementImageDefaultSize !== 'function' && 'getElementImageDefaultSize',
  ].filter(Boolean);
  if (missing.length) {
    throw new HicUnsupportedError('effect-plugins', `createHost: this browser's own HTML-in-Canvas implementation lacks ${missing.join(', ')}, which the effects host needs on top of it`, { hint: 'Keep the 2D drawElementImage path (draw the source on a 2D canvas) when createHost rejects.' });
  }
  // the standard eligibility check of the browser: InvalidStateError unless `source` is a drawable descendant of a content="drawable" canvas
  try { c.getElementTransform?.(source); } catch {
    throw invalidState('createHost: `source` is not an eligible drawable of this canvas (it must be a drawable child, or a descendant marked drawable)');
  }
}

class HostRuntime {
  /**
   * @param {HicEnv} env
   * @param {{store: SnapshotStore, scheduler: Scheduler, geometry: GeometryApi, tracker: InteractionTracker}} deps
   * @param {HTMLCanvasElement} canvas
   * @param {Element} source
   * @param {import('../contracts/types.js').CanvasRecord|null} record
   * @param {EffectHostOptions} opts
   */
  constructor(env, deps, canvas, source, record, opts) {
    this.env = env;
    this.deps = deps;
    this.canvas = canvas;
    this.source = source;
    this.record = record;
    this.opts = opts;
    this.destroyed = false;
    this.recovering = false;
    this.renderRequested = true;
    /** @type {number|null} source version id in the source texture */
    this.uploaded = null;
    /** the under page (EffectHostOptions.under), or null @type {Element|null} */
    this.under = opts.under ?? null;
    /** @type {number|null} version id in the under texture */
    this.underUploaded = null;
    this.lastUnderFill = { x: NaN, y: NaN };
    /** the newest presented frame shows some of the under page (null before the host decided) @type {boolean|null} */
    this.underShown = null;
    /** the author made the under page inert: the host never touches the attribute then */
    this.underAuthorInert = !!this.under?.hasAttribute('inert');
    this.frameIndex = 0;
    this.lastNow = 0;
    /** @type {EffectViewport|null} */ this.lastViewport = null;
    this.lastFill = { x: NaN, y: NaN };
    this.fillApplied = false;
    this.sizeChecked = false;
    /** @type {number[]} */ this.lossTimes = [];
    /** @type {Float64Array} */ this.frameTimes = new Float64Array(FPS_WINDOW);
    this.counters = { frames: 0, uploads: 0, underUploads: 0, pluginErrors: 0, deviceLosses: 0, pauses: 0, offscreenFrames: 0 };
    /** @type {import('../util/visibility.js').VisibilityWatch|null} */ this.visibility = null;
    /** @type {any} */ this.settleTimer = 0;
    /** a paused host may render one frame to advance an unsettled action */
    this.settleDue = false;
    /** @type {Array<() => void>} */ this.cleanups = [];
    this.chain = createMapperChain({ under: !!this.under });
    /** the plugins of the newest presented frame, in chain order @type {Slot[]} */ this.presentedOrder = [];
    /** @type {{stats: () => {remapped: number, passedThrough: number}}|null} */ this.interposer = null;
    /** @type {Presenter} */ this.presenter = /** @type {any} */ (null);
    this.provider = record ? createStoreSourceProvider(env, record, source) : createNativeSourceProvider(env, canvas, source);
    /** the provider of the under page: none without one @type {import('../contracts/types.js').SourceProvider|null} */
    this.underProvider = this.under && record ? createStoreSourceProvider(env, record, this.under) : null;
    /** native mode: the content box of the canvas from a ResizeObserver (css px), null before its first report */
    /** @type {{width: number, height: number}|null} */ this.nativeCss = null;
    /** native mode: the hit-test geometry of the source (the stretch, and the interposer's shift under the pointer) */
    this.nativeGeometry = record ? null : createNativeGeometry(canvas, source);
    this.plugins = createPluginSet(env, canvas, source, {
      gpu: () => this.presenter,
      viewport: () => this.presenter.viewport(),
      requestRender: () => this.requestRender(),
      reducedMotion: () => !!(/** @type {any} */ (env.window)).matchMedia?.('(prefers-reduced-motion: reduce)').matches,
      reportError: (error, slot, phase) => this.reportPluginError(error, slot, phase),
      onWait: () => { if (!this.isVisible()) this.armSettle(); },
      localPoint: (slot, point) => this.localPoint(slot, point),
      under: !!this.under,
    });
    const hook = (/** @type {number} */ now, /** @type {{frameCap: number, due: boolean, repeat?: boolean}} */ info) => this.onFrame(now, info);
    this.frames = record ? schedulerFrameSource(deps.scheduler, record, hook) : nativeFrameSource(env, canvas, hook);
  }

  async start() {
    this.presenter = await this.openPresenter();
    const { bus } = this.env;
    const invalidate = () => { this.renderRequested = true; this.frames.wake(); };
    this.cleanups.push(
      bus.on(BUS.RESIZE, (/** @type {{record: unknown}} */ e) => { if (e.record === this.record) invalidate(); }),
      bus.on(BUS.DPR, invalidate),
    );
    const visibility = watchVisibility(this.env, this.canvas, (visible) => this.onVisibility(visible));
    this.visibility = visibility;
    this.cleanups.push(() => visibility.dispose(), () => this.clearSettle());
    if (this.opts.interposer !== false && (this.record?.layer || this.nativeGeometry)) {
      const interposer = this.record?.layer
        ? createInterposer(this.env, this.record, this.chain, this.deps.tracker, this.under)
        : createNativeInterposer(this.env, this.canvas, this.source, this.chain, /** @type {import('./native-geometry.js').NativeGeometry} */ (this.nativeGeometry));
      this.interposer = interposer;
      this.cleanups.push(() => interposer.dispose());
    }
    if (!this.record) this.cleanups.push(this.watchNativeSize());
    // nothing of the under page is shown before the first frame that a plugin says reveals it
    if (this.under) this.setUnderShown(false);
    this.frames.wake();
  }

  /**
   * Native mode: no scheduler reports a resize or a DPR change of the canvas; a ResizeObserver does (the device-pixel box changes with both).
   * @returns {() => void}
   */
  watchNativeSize() {
    const win = /** @type {any} */ (this.env.window);
    if (typeof win.ResizeObserver !== 'function') return () => {};
    let first = true;
    const ro = new win.ResizeObserver((/** @type {any[]} */ entries) => {
      // the content box for the presenter, without a layout read per frame
      const box = entries[entries.length - 1]?.contentBoxSize?.[0];
      if (box) this.nativeCss = { width: box.inlineSize, height: box.blockSize };
      if (first) { first = false; return; }
      this.requestRender();
    });
    try { ro.observe(this.canvas, { box: 'device-pixel-content-box' }); } catch { ro.observe(this.canvas); }
    return () => ro.disconnect();
  }

  openPresenter() {
    const { canvas, record, env } = this;
    return createPresenter(canvas, this.opts, {
      cssSize: () => {
        const box = record?.contentBox;
        if (box && box.width > 0 && box.height > 0) return box;
        return record ? { width: canvas.clientWidth, height: canvas.clientHeight } : this.nativeCss ?? contentBoxOf(canvas);
      },
      devicePixelRatio: () => env.window.devicePixelRatio || 1,
      onLost: (info) => { void this.onDeviceLost(info); },
      onError: (error) => env.reporter.caught(error, 'effects:gpu-error'),
      under: !!this.under,
    });
  }

  requestRender() {
    if (this.destroyed) return;
    this.renderRequested = true;
    this.frames.wake();
  }

  isVisible() { return this.visibility?.visible ?? true; }

  /** @param {boolean} visible */
  onVisibility(visible) {
    if (this.destroyed) return;
    if (visible) {
      // render on the next frame: the canvas is still inside the margin, so this fresh frame is presented before it scrolls in
      this.clearSettle();
      this.requestRender();
    } else {
      this.counters.pauses += 1;
      this.armSettle();
    }
  }

  /** While paused: schedule the next settle frame when some action is unsettled. */
  armSettle() {
    if (this.settleTimer || this.destroyed || !this.plugins.unsettled()) return;
    this.settleTimer = this.env.window.setTimeout(() => {
      this.settleTimer = 0;
      // re-checked here: an action that ended on the last settle frame resolves its promise a few microtasks after that frame
      if (this.destroyed || this.isVisible() || !this.plugins.unsettled()) return;
      this.settleDue = true;
      this.frames.wake();
    }, SETTLE_MS);
  }

  clearSettle() {
    if (this.settleTimer) this.env.window.clearTimeout(this.settleTimer);
    this.settleTimer = 0;
    this.settleDue = false;
  }

  /**
   * @param {number} now
   * @param {{frameCap: number, due: boolean, repeat?: boolean}} info
   * @returns {boolean}
   */
  onFrame(now, info) {
    // the hook is registered by the constructor but the presenter only exists once start() has awaited the GPU: until then there is nothing to render (start() wakes the loop when it is ready)
    if (this.destroyed || this.recovering || !this.presenter) return false;
    try {
      const v = this.provider.version();
      const uv = this.underProvider ? this.underProvider.version() : null;
      const sourceChanged = (v !== null && v !== this.uploaded) || (uv !== null && uv !== this.underUploaded);
      if (info.repeat && this.counters.frames > 0 && this.lastNow === now) {
        // native: the paint event after this frame's rAF render. The frame stays as rendered (one render per frame: what is presented is what the
        // frame's input mappers describe); the source is uploaded now, while the element image is fresh, and the next frame shows it.
        if (sourceChanged && this.isVisible()) {
          const uploaded = this.presenter.uploadSource(this.provider);
          if (uploaded) { this.uploaded = uploaded; this.counters.uploads += 1; }
          this.renderRequested = true;
        }
        return this.renderRequested || this.plugins.hasContinuous();
      }
      if (!(sourceChanged || this.renderRequested || this.plugins.hasContinuous() || this.settleDue)) return false;
      const paused = !this.isVisible();
      // paused: the work waits for the resume (the source is uploaded and the clock read then), except a settle frame
      if (paused && !this.settleDue) { this.armSettle(); return false; }
      if (!info.due) return true;
      this.renderFrame(now, info.frameCap);
      if (paused) {
        this.counters.offscreenFrames += 1;
        this.settleDue = false;
        this.armSettle();
        return false;
      }
      return this.renderRequested || this.plugins.hasContinuous();
    } catch (error) {
      this.env.reporter.caught(error, 'effects:frame');
      return false;
    }
  }

  /** @param {number} now @param {number} frameCap */
  renderFrame(now, frameCap) {
    this.renderRequested = false;
    const p = this.presenter;
    p.syncSize();
    const vp = p.viewport();
    const v = this.provider.version();
    if (v !== null && v !== this.uploaded) {
      const uploaded = p.uploadSource(this.provider);
      if (uploaded) { this.uploaded = uploaded; this.counters.uploads += 1; }
    }
    const under = this.underProvider;
    const uv = under ? under.version() : null;
    if (under && uv !== null && uv !== this.underUploaded) {
      const uploaded = p.uploadUnder(under);
      if (uploaded) { this.underUploaded = uploaded; this.counters.underUploads += 1; }
    }
    this.notifyResize(vp);
    this.syncGeometry(vp);
    /** @type {EffectPresentationFrame} */
    const frame = { now, delta: this.lastNow ? now - this.lastNow : 0, frameIndex: this.frameIndex, frameCap, sourceVersion: this.uploaded };
    if (under) frame.underVersion = this.underUploaded;
    const presented = this.present(frame);
    if (!presented) return;
    this.lastNow = now;
    this.frameIndex += 1;
    this.counters.frames += 1;
    this.frameTimes[this.counters.frames % FPS_WINDOW] = now;
    const captured = this.captureMappers(presented, frame);
    this.presentedOrder = presented.map((s) => s.slot);
    if (this.under) this.setUnderShown(presented.some((s) => s.instance.revealsUnder === true));
    this.chain.push(frame.frameIndex, captured.mappers, captured.places);
    this.canvas.dispatchEvent(new CustomEvent(EVENTS.EFFECT_FRAME, { detail: Object.freeze({ ...frame }) }));
  }

  /**
   * Submit the chain; a throwing plugin is disabled and reported. When it had already taken this frame's canvas texture the frame is
   * redrawn without it (the canvas would present an empty texture otherwise); before that the canvas simply keeps its last frame.
   * @param {EffectPresentationFrame} frame
   * @returns {import('./effect-plugins.js').Stage[]|null} the stages that were presented, null when nothing was
   */
  present(frame) {
    for (;;) {
      const stages = this.plugins.stages();
      const failure = this.presenter.renderChain(stages, frame);
      if (!failure) return stages;
      if (!failure.plugin.slot) throw failure.error;
      this.counters.pluginErrors += 1;
      this.plugins.fail(failure.plugin.slot, failure.error);
      if (!failure.acquired) return null;
    }
  }

  /**
   * @param {import('./effect-plugins.js').Stage[]} stages
   * @param {EffectPresentationFrame} frame
   * @returns {{mappers: InputMapper[], places: number[]}}  `places[i]`: the place in `stages` of the plugin of `mappers[i]`
   */
  captureMappers(stages, frame) {
    /** @type {InputMapper[]} */
    const mappers = [];
    /** @type {number[]} */
    const places = [];
    for (let i = 0; i < stages.length; i += 1) {
      const s = stages[i];
      if (!s.instance.spatial) continue;
      try { mappers.push(captureMapper(s.instance, s.def, frame)); places.push(i); } catch (error) { this.plugins.fail(s.slot, error); }
    }
    return { mappers, places };
  }

  /**
   * EffectPluginContext.localPoint: where a point of the canvas is in the picture this plugin rendered, in the newest presented frame: the point through the
   * mappers of the plugins after it. The same point for the last plugin, and for a plugin that was not in that frame (just added: it runs last).
   * EffectHost.mapPoint is the same from before the first plugin (`slot` null): the point in the source.
   * @param {Slot|null} slot @param {{x: number, y: number}} point  canvas-relative css px of the content box
   * @returns {{x: number, y: number, under?: true}|null}  null where a later plugin shows nothing of this plugin's picture; `under: true` on the under page
   */
  localPoint(slot, point) {
    const x = Number(point?.x), y = Number(point?.y);
    if (!Number.isFinite(x) || !Number.isFinite(y)) throw typeError('the point must have finite x and y (canvas-relative CSS pixels)');
    const place = slot ? this.presentedOrder.indexOf(slot) : -1;
    if (slot && (place < 0 || place === this.presentedOrder.length - 1)) return { x, y };
    const vp = this.presenter.viewport();
    const q = this.chain.mapAfter(place, { x, y, width: vp.cssWidth, height: vp.cssHeight });
    return isNoTarget(q) ? null : q;
  }

  /**
   * The under page leaves the tab order and the accessibility tree while nothing of it is shown, and comes back while some of it is (`inert`).
   * @param {boolean} shown
   */
  setUnderShown(shown) {
    const el = this.under;
    if (!el || shown === this.underShown) return;
    this.underShown = shown;
    if (this.underAuthorInert) return;
    if (shown) { el.removeAttribute('inert'); return; }
    // blurred first: a field that stays focused while its page turns inert would keep the keyboard of a page nobody sees
    const active = el.ownerDocument.activeElement;
    if (active && el.contains(active)) /** @type {HTMLElement} */ (active).blur();
    el.setAttribute('inert', '');
  }

  /** @param {EffectViewport} vp */
  notifyResize(vp) {
    const last = this.lastViewport;
    if (last && last.width === vp.width && last.height === vp.height && last.dpr === vp.dpr) return;
    this.lastViewport = vp;
    this.plugins.resize(vp);
  }

  /**
   * The effect shows the source stretched over the whole canvas; the live element must sit under those pixels (API-CONTRACT 7.3).
   * @param {EffectViewport} vp
   */
  syncGeometry(vp) {
    const { record, source } = this;
    const size = this.provider.size();
    if (!size || size.cssWidth <= 0 || size.cssHeight <= 0) return;
    if (!this.sizeChecked) this.warnSizeMismatch(vp, size);
    const x = vp.cssWidth / size.cssWidth;
    const y = vp.cssHeight / size.cssHeight;
    const underFill = this.syncUnderFill(vp);
    if (!underFill && Math.abs(x - this.lastFill.x) < 1e-6 && Math.abs(y - this.lastFill.y) < 1e-6) return;
    this.lastFill = { x, y };
    // the under page first: the element updated last is the top of the hit-test order, and the source must stay above the under page
    if (record && this.under && Number.isFinite(this.lastUnderFill.x)) {
      this.deps.geometry.update(record, this.under, { canvasTransform: { a: this.lastUnderFill.x, d: this.lastUnderFill.y } });
    }
    // Always applied, also for an identity fill: an element is hit-testable only while it is in the canvas's drawn list (a source that exactly fills the canvas still has to be there).
    if (record) this.deps.geometry.update(record, source, { canvasTransform: { a: x, d: y } });
    else this.nativeGeometry?.setFill(x, y);
    this.fillApplied = true;
  }

  /**
   * The fill of the under page (its own size over the canvas), kept in lastUnderFill. @param {EffectViewport} vp
   * @returns {boolean}  it changed (both elements are then placed again, in order)
   */
  syncUnderFill(vp) {
    const size = this.underProvider?.size();
    if (!size || size.cssWidth <= 0 || size.cssHeight <= 0) return false;
    const x = vp.cssWidth / size.cssWidth;
    const y = vp.cssHeight / size.cssHeight;
    if (Math.abs(x - this.lastUnderFill.x) < 1e-6 && Math.abs(y - this.lastUnderFill.y) < 1e-6) return false;
    this.lastUnderFill = { x, y };
    return true;
  }

  /**
   * The stretch maps drawn pixels to live pixels; a source of another size than the canvas is stretched, so input (and the picture) are off. One console.warn per host, at its first frame.
   * @param {EffectViewport} vp
   * @param {{cssWidth: number, cssHeight: number}} size
   */
  warnSizeMismatch(vp, size) {
    this.sizeChecked = true;
    if (Math.abs(vp.cssWidth - size.cssWidth) <= 1 && Math.abs(vp.cssHeight - size.cssHeight) <= 1) return;
    const r = (/** @type {number} */ n) => Math.round(n * 100) / 100;
    /** @type {Window & typeof globalThis} */ (this.env.window).console.warn(`[hic-live-polyfill] createHost: the source is ${r(size.cssWidth)}x${r(size.cssHeight)} CSS px but the canvas is ${r(vp.cssWidth)}x${r(vp.cssHeight)}; it is stretched to fit, so the picture is distorted and clicks land off target. Size the source like the canvas (docs/guides/EFFECTS-PLUGINS.md).`);
  }

  /** @param {unknown} error @param {Slot} slot @param {string} phase */
  reportPluginError(error, slot, phase) {
    if (phase !== 'render') this.counters.pluginErrors += 1;
    try {
      this.canvas.dispatchEvent(new CustomEvent(EVENTS.EFFECT_ERROR, { detail: { error, type: slot.def.type, id: slot.id, phase } }));
    } catch { /* a throwing listener must not stop the report */ }
    this.env.reporter.caught(error, `effects:${slot.def.type}:${phase}`);
  }

  /** @param {{reason: string, message: string}} info */
  async onDeviceLost(info) {
    if (this.destroyed || this.recovering) return;
    this.recovering = true;
    this.counters.deviceLosses += 1;
    const t = this.env.now();
    const lost = this.presenter?.device;
    this.lossTimes = this.lossTimes.filter((x) => t - x < LOSS_WINDOW_MS);
    this.lossTimes.push(t);
    this.env.reporter.caught(new Error(`GPUDevice lost (${info.reason}): ${info.message}`), 'effects:device-lost');
    if (this.lossTimes.length > MAX_LOSSES) {
      this.giveUp(new Error(`GPUDevice lost ${this.lossTimes.length} times within ${LOSS_WINDOW_MS} ms; the effect stays on its last frame`));
      return;
    }
    // a device the page gave is the page's to make again: a GPUDevice cannot come back, a function is asked for the current one
    if (this.opts.device !== undefined && typeof this.opts.device !== 'function') {
      this.giveUp(new Error(`the GPUDevice of options.device was lost (${info.reason}); the effect stays on its last frame. Create the host again with a new device, or pass options.device as a function that returns the current one`));
      return;
    }
    try {
      const next = await this.openPresenter();
      if (this.destroyed) { next.dispose(); return; }
      if (next.device === lost) {
        next.dispose();
        throw new Error('options.device returned the GPUDevice that was lost; it must return a new one');
      }
      const old = this.presenter;
      this.presenter = next;
      old.dispose(true);
      this.uploaded = null;
      this.underUploaded = null;
      this.lastViewport = null;
      await this.plugins.recreate();
    } catch (error) {
      this.giveUp(error);
      return;
    }
    this.recovering = false;
    this.requestRender();
  }

  /** @param {unknown} error */
  giveUp(error) {
    this.env.reporter.caught(error, 'effects:recover');
    try { this.canvas.dispatchEvent(new CustomEvent(EVENTS.EFFECT_ERROR, { detail: { error, type: 'host', id: 'host', phase: 'recover' } })); } catch { /* listener threw */ }
  }

  stats() {
    const n = Math.min(this.counters.frames, FPS_WINDOW);
    let fps = 0;
    if (n >= 2) {
      const newest = this.frameTimes[this.counters.frames % FPS_WINDOW];
      const oldest = this.frameTimes[(this.counters.frames - n + 1) % FPS_WINDOW];
      fps = newest > oldest ? ((n - 1) * 1000) / (newest - oldest) : 0;
    }
    return { ...this.counters, fps, paused: !this.isVisible(), hdr: this.presenter?.hdr === true, sourceVersion: this.uploaded, underVersion: this.underUploaded, ...(this.interposer?.stats() ?? { remapped: 0, passedThrough: 0 }) };
  }

  /** @returns {EffectHost} */
  publicApi() {
    const rt = this;
    return {
      get pluginCount() { return rt.plugins.count; },
      addPlugin: (def, options) => rt.plugins.add(def, options),
      stats: () => rt.stats(),
      mapPoint: (point) => rt.localPoint(null, point),
      destroy: () => rt.destroy(),
    };
  }

  destroy() {
    if (this.destroyed) return;
    this.destroyed = true;
    for (const c of this.cleanups.splice(0)) c();
    this.frames.remove();
    this.plugins.destroy();
    this.provider.dispose();
    this.underProvider?.dispose();
    if (this.under && !this.underAuthorInert && this.underShown === false) this.under.removeAttribute('inert');
    if (this.fillApplied && this.record) this.deps.geometry.clear(this.record, this.source);
    if (this.under && this.record && Number.isFinite(this.lastUnderFill.x)) this.deps.geometry.clear(this.record, this.under);
    this.nativeGeometry?.dispose();
    this.presenter?.dispose();
  }
}
