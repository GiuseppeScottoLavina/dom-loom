/**
 * WebGPU device, canvas context, source/ping-pong textures, one submit per frame.
 * Module: gpu-effects (src/effects/**).
 */

import { HicUnsupportedError, invalidState } from '../contracts/errors.js';

/** @typedef {import('../contracts/types.js').EffectHostOptions} EffectHostOptions */
/** @typedef {import('../contracts/types.js').EffectPluginDefinition} EffectPluginDefinition */
/** @typedef {import('../contracts/types.js').EffectPluginInstance} EffectPluginInstance */
/** @typedef {import('../contracts/types.js').EffectPresentationFrame} EffectPresentationFrame */
/** @typedef {import('../contracts/types.js').EffectViewport} EffectViewport */
/** @typedef {import('../contracts/types.js').SourceProvider} SourceProvider */

/** @typedef {{instance: EffectPluginInstance, def: EffectPluginDefinition, slot?: any}} ChainStage */

/**
 * @typedef {Object} PresenterHooks
 * @property {() => {width: number, height: number}} [cssSize]  canvas content box, css px (default: clientWidth/clientHeight)
 * @property {() => number} [devicePixelRatio]
 * @property {(info: {reason: string, message: string}) => void} [onLost]  the device was lost (not called after dispose())
 * @property {(error: unknown) => void} [onError]  uncaptured GPU error
 * @property {number} [extraCanvasUsage]  GPUTextureUsage bits added to the canvas configuration (tests add COPY_SRC for readback)
 * @property {boolean} [under]  the host has an under page (EffectHostOptions.under): a second source texture, handed to every stage as `frame.under`
 */

/**
 * @typedef {Object} Presenter
 * @property {any} adapter @property {any} device @property {string} format  the canvas format: every target of the chain has it (`rgba16float` with `hdr`)
 * @property {boolean} hdr  extended range is in use (EffectHostOptions.hdr, where the browser takes the configuration)
 * @property {'opaque'|'premultiplied'} alphaMode  EffectHostOptions.alphaMode: the canvas configuration and the alpha of every uploaded source
 * @property {boolean} ownDevice  the host requested the device (false: options.device, which dispose() does not destroy)
 * @property {any} context  the GPUCanvasContext
 * @property {() => EffectViewport} viewport
 * @property {() => boolean} syncSize  apply css size * min(dpr, maxDpr) to the canvas backing store; true when it changed (the bitmap was cleared: render now)
 * @property {(provider: SourceProvider) => number} uploadSource  returns the version uploaded (0 = nothing to upload yet)
 * @property {(provider: SourceProvider) => number} uploadUnder  the same for the under page (0 also on a presenter without `hooks.under`)
 * @property {(plugins: ChainStage[], frame: EffectPresentationFrame) => ({plugin: ChainStage, error: unknown, acquired: boolean}|null)} renderChain  null = submitted; otherwise the plugin whose render() threw and NOTHING was submitted. `acquired`: the canvas texture of this frame was already taken (then the canvas would present an empty frame unless something is drawn again)
 * @property {(keepContext?: boolean) => void} dispose  keepContext: do not unconfigure the canvas (a replacement presenter already configured it)
 */

/** Same dark blue as the water pass clear, so a plugin-less passthrough looks like the water without ripples. */
const CLEAR = { r: 0.004, g: 0.018, b: 0.034, a: 1 };

const PASSTHROUGH_WGSL = /* wgsl */ `
@group(0) @binding(0) var s : sampler;
@group(0) @binding(1) var tx : texture_2d<f32>;
struct V { @builtin(position) pos : vec4<f32>, @location(0) uv : vec2<f32> }
@vertex fn vs(@builtin(vertex_index) i : u32) -> V {
  var p = array<vec2<f32>, 3>(vec2<f32>(-1.0, -1.0), vec2<f32>(3.0, -1.0), vec2<f32>(-1.0, 3.0));
  var o : V;
  o.pos = vec4<f32>(p[i], 0.0, 1.0);
  o.uv = vec2<f32>((p[i].x + 1.0) * 0.5, (1.0 - p[i].y) * 0.5);
  return o;
}
@fragment fn fs(v : V) -> @location(0) vec4<f32> {
  let c = textureSample(tx, s, v.uv);
  return vec4<f32>(mix(vec3<f32>(${CLEAR.r}, ${CLEAR.g}, ${CLEAR.b}), c.rgb, c.a), 1.0);
}
// alphaMode 'premultiplied': the source is already premultiplied and its transparent parts stay transparent (no dark background)
@fragment fn fsp(v : V) -> @location(0) vec4<f32> {
  return textureSample(tx, s, v.uv);
}`;

/**
 * @param {string} message
 * @returns {HicUnsupportedError}
 */
function noWebGpu(message) {
  return new HicUnsupportedError('effect-plugins', message, { hint: 'Keep the 2D drawElementImage path (draw the source on a 2D canvas) when createHost rejects.' });
}

/**
 * The device of `options.device`: a GPUDevice, or what a function returns (called at creation and again after a device loss). TypeError for anything else.
 * @param {EffectHostOptions} options @returns {Promise<any>}
 */
async function givenDevice(options) {
  const given = options.device;
  const device = typeof given === 'function' ? await given() : given;
  if (!device || typeof device !== 'object' || typeof device.createTexture !== 'function' || !device.queue || !device.lost) {
    throw new TypeError(`createHost: options.device ${typeof given === 'function' ? 'returned something that is not a GPUDevice' : 'must be a GPUDevice, or a function that returns one'}`);
  }
  return device;
}

/**
 * Acquire adapter/device (options.powerPreference), or take the page's (options.device: the host never destroys it), then claim and configure canvas.getContext("webgpu") (never before: without an adapter or a device the canvas stays free for a 2D context) (InvalidStateError on a conflicting context), size the canvas to css*min(dpr,maxDpr). Rejects HicUnsupportedError("effect-plugins") without WebGPU.
 * options.alphaMode 'premultiplied': the canvas is configured premultiplied and the source is uploaded premultiplied, so every texture of the chain holds premultiplied
 * colours and what the plugins leave transparent shows the page behind the canvas; 'opaque' (the default) shows black there.
 * @param {HTMLCanvasElement} canvas
 * @param {EffectHostOptions} options
 * @param {PresenterHooks} [hooks]
 * @returns {Promise<Presenter>}
 */
export async function createPresenter(canvas, options, hooks = {}) {
  const win = /** @type {any} */ (canvas.ownerDocument.defaultView ?? globalThis);
  const gpu = win.navigator?.gpu;
  if (!gpu) throw noWebGpu('WebGPU is not available in this browser, so effect plugins cannot run');
  // The canvas is claimed LAST: a canvas keeps its first context type for life, so claiming 'webgpu' before the adapter and the device exist
  // would leave a canvas that can no longer give the documented 2D fallback a context when either of them is missing.
  // a device the page gave (options.device) stays the page's: the host destroys only what it created on it
  const own = options.device === undefined;
  /** @type {any} */
  let adapter = null;
  /** @type {any} */
  let device;
  if (own) {
    adapter = await gpu.requestAdapter(options.powerPreference ? { powerPreference: options.powerPreference } : undefined);
    if (!adapter) throw noWebGpu('WebGPU is present but no adapter was returned');
    device = await adapter.requestDevice();
  } else device = await givenDevice(options);
  const release = () => { if (own) device.destroy(); };
  const context = /** @type {any} */ (canvas.getContext('webgpu'));
  if (!context) {
    release();
    throw invalidState('canvas-context-conflict: the canvas already has another context type; effects need a canvas without a 2D/WebGL context');
  }
  const USAGE = win.GPUTextureUsage;
  const alphaMode = options.alphaMode === 'premultiplied' ? 'premultiplied' : 'opaque';
  const config = { device, alphaMode, usage: USAGE.RENDER_ATTACHMENT | USAGE.COPY_DST | (hooks.extraCanvasUsage ?? 0) };
  let format = gpu.getPreferredCanvasFormat();
  // Extended range (options.hdr): a float canvas with the `extended` tone mapping, where a value above 1 is shown brighter than white as far as the display can
  // (on a display without the headroom it is white, as in an 8-bit canvas). Used only where the browser reports the configuration back: one that does not know
  // the member takes the float format and would tone-map it as before, for twice the memory.
  let hdr = false;
  if (options.hdr) {
    try {
      context.configure({ ...config, format: 'rgba16float', toneMapping: { mode: 'extended' } });
      hdr = context.getConfiguration?.()?.toneMapping?.mode === 'extended';
    } catch { /* the format or the member is not accepted here */ }
    if (hdr) format = 'rgba16float';
  }
  if (!hdr) context.configure({ ...config, format });
  // the passthrough (the frame without a plugin) is compiled now, off the main thread where the browser can: Safari compiles a pipeline it has not
  // seen in about half a second, and one made with the synchronous call is compiled at its first use, on the main thread, freezing the page
  const passModule = device.createShaderModule({ label: 'hic-passthrough', code: PASSTHROUGH_WGSL });
  const passDesc = { label: 'hic-passthrough', layout: 'auto', vertex: { module: passModule, entryPoint: 'vs' }, fragment: { module: passModule, entryPoint: alphaMode === 'premultiplied' ? 'fsp' : 'fs', targets: [{ format }] }, primitive: { topology: 'triangle-list' } };
  const passPipeline = await Promise.resolve(device.createRenderPipelineAsync ? device.createRenderPipelineAsync(passDesc) : device.createRenderPipeline(passDesc))
    .catch((/** @type {any} */ error) => { context.unconfigure?.(); release(); throw error; });

  let disposed = false;
  /** @type {EffectViewport} */
  let vp = { width: 1, height: 1, cssWidth: 1, cssHeight: 1, dpr: 1 };
  let ready = false;
  const mid = /** @type {{texture: any, view: any}[]} */ ([]);
  let src = makeSource(1, 1);
  // the under page: a texture of its own, only on a host that has one (without it nothing is allocated and frame.under is null)
  /** @type {{texture: any, view: any}|null} */
  let under = hooks.under ? makeSource(1, 1, 'hic-under') : null;
  let underReady = false;
  /** @type {{stage: ChainStage, pipeline: any, sampler: any, groups: WeakMap<object, any>}|null} */
  let pass = null;

  device.lost.then((/** @type {{reason: string, message: string}} */ info) => { if (!disposed) hooks.onLost?.(info); });
  // removed at dispose: a device the page gave outlives the host (and may serve other hosts)
  const onUncaptured = (/** @type {any} */ e) => { if (!disposed) hooks.onError?.(e.error); };
  device.addEventListener('uncapturederror', onUncaptured);
  const premultiplied = alphaMode === 'premultiplied';

  /** @param {number} w @param {number} h @param {string} [label] */
  function makeSource(w, h, label = 'hic-source') {
    const texture = device.createTexture({ label, size: [w, h], format: 'rgba8unorm', usage: USAGE.TEXTURE_BINDING | USAGE.COPY_DST | USAGE.RENDER_ATTACHMENT });
    return { texture, view: texture.createView() };
  }

  /**
   * Same-format targets, one per stage that writes before the canvas, at most two (stages alternate between them): 0 for a single stage that renders into the canvas,
   * 1 for one stage that cannot or for two whose last one can, 2 otherwise. Kept while the chain needs as many; 0 drops them all (resize, dispose).
   * @param {number} n
   */
  function fitMid(n) {
    while (mid.length > n) mid.pop()?.texture.destroy();
    for (let i = mid.length; i < n; i += 1) {
      const texture = device.createTexture({ label: `hic-mid-${i}`, size: [vp.width, vp.height], format, usage: USAGE.RENDER_ATTACHMENT | USAGE.TEXTURE_BINDING | USAGE.COPY_SRC });
      mid.push({ texture, view: texture.createView() });
    }
  }

  function passthroughStage() {
    if (pass) return pass.stage;
    const sampler = device.createSampler({ magFilter: 'linear', minFilter: 'linear', addressModeU: 'clamp-to-edge', addressModeV: 'clamp-to-edge' });
    const groups = new WeakMap();
    /** @type {EffectPluginInstance} */
    const instance = {
      render(frame) {
        let group = groups.get(frame.sourceView);
        if (!group) {
          group = device.createBindGroup({ layout: passPipeline.getBindGroupLayout(0), entries: [{ binding: 0, resource: sampler }, { binding: 1, resource: frame.sourceView }] });
          groups.set(frame.sourceView, group);
        }
        const p = frame.encoder.beginRenderPass({ colorAttachments: [{ view: frame.destinationView, loadOp: 'clear', storeOp: 'store', clearValue: CLEAR }] });
        p.setPipeline(passPipeline); p.setBindGroup(0, group); p.draw(3); p.end();
      },
    };
    const def = /** @type {EffectPluginDefinition} */ ({ type: 'passthrough', apiVersion: 2, version: 1, outputCapabilities: { directCanvasRenderAttachment: true }, create: () => instance });
    pass = { stage: { instance, def }, pipeline: passPipeline, sampler, groups };
    return pass.stage;
  }

  /** @type {Presenter} */
  const presenter = {
    adapter, device, format, hdr, alphaMode, ownDevice: own, context,
    viewport: () => vp,
    syncSize() {
      const css = hooks.cssSize?.() ?? { width: canvas.clientWidth, height: canvas.clientHeight };
      const dpr = hooks.devicePixelRatio?.() ?? (win.devicePixelRatio || 1);
      let scale = Math.max(0.25, Math.min(dpr, options.maxDpr ?? 2.5));
      const maxDim = device.limits.maxTextureDimension2D;
      scale = Math.min(scale, maxDim / Math.max(1, css.width, css.height));
      const w = Math.max(1, Math.round(css.width * scale));
      const h = Math.max(1, Math.round(css.height * scale));
      const changed = canvas.width !== w || canvas.height !== h;
      if (changed) { canvas.width = w; canvas.height = h; fitMid(0); }
      vp = { width: w, height: h, cssWidth: css.width, cssHeight: css.height, dpr: css.width > 0 ? w / css.width : scale };
      return changed;
    },
    uploadSource(provider) {
      const size = provider.size();
      if (!size) return 0;
      if (src.texture.width !== size.width || src.texture.height !== size.height) {
        src.texture.destroy();
        src = makeSource(size.width, size.height);
      }
      const version = provider.upload(device, src.texture, true, premultiplied);
      ready = version !== 0;
      return version;
    },
    uploadUnder(provider) {
      const size = under && provider.size();
      if (!under || !size) return 0;
      if (under.texture.width !== size.width || under.texture.height !== size.height) {
        under.texture.destroy();
        under = makeSource(size.width, size.height, 'hic-under');
      }
      const version = provider.upload(device, under.texture, true, premultiplied);
      underReady = version !== 0;
      return version;
    },
    renderChain(plugins, frame) {
      const stages = plugins.length > 0 ? plugins : [passthroughStage()];
      const last = stages[stages.length - 1];
      const lastDirect = last.def.outputCapabilities?.directCanvasRenderAttachment === true;
      fitMid(Math.min(2, stages.length - (lastDirect ? 1 : 0)));
      const encoder = device.createCommandEncoder();
      let input = src;
      let inputReady = ready;
      // the same under page for every stage: it is not part of the picture the earlier plugins render
      const underFrame = under ? { texture: under.texture, view: under.view, ready: underReady } : null;
      /** @type {any} */ let canvasTexture = null;
      for (let i = 0; i < stages.length; i += 1) {
        const stage = stages[i];
        let out = mid[i % 2];
        if (i === stages.length - 1 && lastDirect) {
          canvasTexture = context.getCurrentTexture();
          out = { texture: canvasTexture, view: canvasTexture.createView() };
        }
        const renderFrame = {
          ...vp, ...frame, sourceReady: inputReady, encoder,
          sourceTexture: input.texture, sourceView: input.view, destinationTexture: out.texture, destinationView: out.view, under: underFrame,
        };
        try {
          stage.instance.render(renderFrame);
        } catch (error) {
          return { plugin: stage, error, acquired: canvasTexture !== null };
        }
        input = out;
        inputReady = true;
      }
      if (!canvasTexture) {
        canvasTexture = context.getCurrentTexture();
        encoder.copyTextureToTexture({ texture: input.texture }, { texture: canvasTexture }, [vp.width, vp.height]);
      }
      device.queue.submit([encoder.finish()]);
      return null;
    },
    dispose(keepContext = false) {
      if (disposed) return;
      disposed = true;
      fitMid(0);
      src.texture.destroy();
      under?.texture.destroy();
      if (!keepContext) { try { context.unconfigure(); } catch { /* context already gone */ } }
      device.removeEventListener?.('uncapturederror', onUncaptured);
      release();
    },
  };
  presenter.syncSize();
  return presenter;
}
