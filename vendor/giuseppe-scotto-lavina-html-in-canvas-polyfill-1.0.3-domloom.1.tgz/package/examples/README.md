# Examples

Seven self-contained pages and the field test, each with its own `index.html` and a short README. They load the built files from `../../dist/` and nothing from the network, except the playground's optional syntax colours (Prism, from cdnjs). The seven pages and the field test also load the engines bundle (`hic-live-engines`), which draws form controls on Firefox and Safari; the table lists what else each page needs.

```sh
npm ci             # once (build tooling only; the polyfill has no runtime dependencies)
npm run build      # writes dist/
npm run demo       # serves /examples and /dist on http://127.0.0.1:8765 (zero-dependency server, examples/serve.mjs)
```

Open `http://127.0.0.1:8765/examples/` in desktop Chrome, Firefox 155+ or Safari 27+.

The server answers only under `/examples` and `/dist` (403 elsewhere). To try your own page, put it in a folder next to these (`examples/mine/index.html`, scripts from `../../dist/`) or open it from disk with `file://`.

| example | shows | needs |
|---|---|---|
| [basic](basic/) | the WICG explainer "Basic Example", unchanged | core |
| [form](form/) | a contact form (inputs, textarea, checkbox, validation) drawn from `onpaint` | core |
| [plugins](plugins/) | the effect gallery: pick a plugin of `plugins/` and apply it to one live form, its controls and actions (`handle.trigger`); picking an effect plays its `demo` (`?demo=0` turns that off); `?opt.<plugin>.<option>=<value>` sets an option of that plugin over its defaults (for example `&opt.water.intensity=1`), to compare variants by link; frame cap slider (default: the display rate) and a readout of effect frames per second and frame interval, "effect off", 2D fallback | core, effects, the plugin bundles, WebGPU for the effects |
| [effect-plugin](effect-plugin/) | the smallest page with effects (about 30 lines of script): create the host, add the water plugin, set the frame cap, run a disintegrate transition with `handle.trigger` from the page's submit handler; 2D fallback | core, effects, `plugins/water`, `plugins/disintegrate`, WebGPU for the effects |
| [scroll-and-resize](scroll-and-resize/) | a scrolling list (sticky header, hover) and a responsive layout in one canvas | core |
| [playground](playground/) | edit the explainer example and run it in a sandboxed preview frame (opaque origin); status line, console panel, Run, Reset and Share (the code in the link) | core |
| [webgl-texture](webgl-texture/) | a spinning cube textured with a live form via `gl.texElementSubImage2D` | core, the GPU bundle (`hic-live-gpu`), WebGL2 |
| [frameworks](frameworks/) | not self-contained: the same small app in React 19, Vue 3, Svelte 5 and Lit 3, its whole UI inside one canvas ([docs/guides/FRAMEWORKS.md](../docs/guides/FRAMEWORKS.md)); each folder's README says how to build it | core, the framework packages (test dependencies, installed separately) |
| [field-test](field-test/) | not an example: a guided check of about six minutes for testers on other machines; compares the canvas with the plain page through a capture of the tab and downloads one JSON report ([docs/guides/FIELD-TEST.md](../docs/guides/FIELD-TEST.md)) | core; effects and `plugins/water` loaded in its effect step |

`npm run test:examples` opens each page in headless Chrome and asserts: no console error or page error, the canvas is not blank, and the key interaction works (typing, the frame cap slider, choosing and removing effects in the gallery, the submit that runs the disintegrate actions, wheel scrolling plus a viewport resize, typing into the texture source; in the playground, the sandbox, typing in the preview, the console panel, Share links and recovery from an endless loop). It also runs a control with a broken `dist/` path that must fail every example. It also runs smoke pages that exercise the code printed in the guides (`test/examples-smoke/`: the ESM quick start, the HTML blocks of the README and of GETTING-STARTED extracted from the Markdown, and the complete plugin of `docs/guides/EFFECTS-PLUGINS.md`, whose input mapper is compared with GPU pixels). Results are written to `.scratch/results/` (git-ignored).
