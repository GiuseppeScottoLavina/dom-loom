# playground

Edit the WICG explainer example and run it in the browser. [Try it](https://giuseppescottolavina.github.io/html-in-canvas-polyfill/examples/playground/).

Needs: core and engines (`dist/hic-live-polyfill.iife.min.js`, `dist/hic-live-engines.iife.min.js`). The effects and the plugins are not loaded; the [plugin gallery](../plugins/) shows them. The editor's colours come from Prism on cdnjs, and are optional (see [Syntax highlighting](#syntax-highlighting)).

Run locally: `npm run build && npm run demo`, then open `http://127.0.0.1:8765/examples/playground/` in desktop Chrome, Firefox 155+ or Safari 27+.

## What it does

- Left, the code: a `<textarea>` with the explainer's "Basic Example" (the same markup and script as [basic](../basic/)). It becomes the body of the preview page. Tab indents by two spaces; Esc then Tab, or Shift+Tab, moves the focus on; Ctrl+Enter or Cmd+Enter runs.
- Right, the preview: a new frame for each run. "Show canvas bounds" (on by default; the choice is kept in this browser, not in shared links) adds `canvas { outline: 1px dashed }` to the preview page before the code, so the canvas is visible on the white page and an author style still overrides it. The frame loads the core and engines bundles of this site, then the code. The status line above it says what ran: `polyfill <version> installed (mode polyfill)`, `native API, the polyfill stepped aside (mode native)`, the polyfill's refusal, or a bundle that did not load. The console panel below it shows the preview's uncaught errors, unhandled rejections and `console.error`, `console.warn` and `console.log`.
- Run builds the preview again; Reset restores the explainer example and runs it; Share puts the code in the link (`#code=` followed by the base64url of its UTF-8 bytes), copies the link and says so. Opening such a link fills the editor with that code and runs it. A link is limited to 16,000 encoded characters (about 12 KB of code); a longer code, or a damaged link, is refused with a message and the original example is shown.

## Syntax highlighting

The editor colours HTML, and the CSS and JavaScript inside `<style>` and `<script>`, with [Prism](https://prismjs.com/) 1.29.0: its core and the `markup`, `css`, `clike` (needed by `javascript`) and `javascript` components, about 17 KB minified. They load from cdnjs with a pinned version and Subresource Integrity (`integrity` and `crossorigin="anonymous"`), so the browser runs them only if their bytes match. They load on the playground page only; the preview frame never loads them.

The `<textarea>` stays the editor. Once Prism has loaded, its text is transparent and its caret visible, over a `<pre>` that holds a highlighted copy of its value: same font, size, line height, padding and tab size, no wrapping, the same scroll range, and scrolled with it. The copy is rebuilt at most once per frame, after typing or a value set by script (Reset, a shared link). Prism's tokens become elements and text nodes, so the code is never parsed as HTML. A code over 50,000 characters is copied without colours. The caret, selection, input methods, undo and the keys are the textarea's own.

If Prism does not load (cdnjs blocked or unreachable, or a file that does not match its hash), the editor is a plain textarea with visible text, and everything else works the same.

## The sandbox

The preview is `<iframe sandbox="allow-scripts">` without `allow-same-origin`, its document loaded as a `data:` URL with a `<base>` of the playground's folder (relative URLs in the code resolve as in a page next to it). Not `srcdoc`: Safari 27 reports every error of a sandboxed `srcdoc` (or `blob:`) document as "Script error." without its message, and reports them in full for a `data:` document; Chrome and Firefox report them in all three. Its origin is opaque, so code from a shared link never runs in the site's origin: it cannot read the site's cookies or storage or reach the page, and it cannot open windows, show dialogs (`alert()` is reported in the console instead) or submit forms. The bundles are loaded by absolute URL from the page's own location, with `crossorigin="anonymous"`: to the opaque-origin preview they are scripts of another origin, and the browser would report an exception they throw (a refused `drawElementImage`, for example) only as "Script error.". Fetched with CORS (GitHub Pages and `npm run demo` answer `Access-Control-Allow-Origin: *`), the console shows its message. A server without that header would not run them, so a self-hosted copy of the playground needs it too.

The polyfill needs nothing more from the origin: it makes no request of its own, uses no worker and no storage, and installs, paints and takes typing in the opaque origin as on a page. One difference: images, fonts and style sheets that the drawn HTML references are read with a CORS request (their origin differs from the opaque one), so their server must allow cross-origin reads. GitHub Pages does.

The frame reports to the page with `postMessage`. The page accepts a message only from the current preview frame and with that run's token, and shows its strings as text, never as HTML.

## A preview that stops responding

The page sends the frame a ping every second; a frame that leaves one unanswered for 3 seconds is reported as not responding. What happens then depends on the browser:

- Chrome runs the sandboxed frame in a process of its own: the editor keeps working and the status line says the preview is not responding. A new frame of the page would land in that busy process, which Chrome ends about 10.5 seconds after its last frame is gone (measured on Chrome 156). So Run and Reset remove the stuck frame, say so, and run the editor's code 11.5 seconds later in a new process.
- Firefox (157) and Safari (27) run the frame in the page's process: a loop of 4.5 s in the preview stopped the page's own timers for 4.6 s in both. An endless loop freezes the page too, until the browser offers to stop the script; then edit the code and run it again. The page does not report such a pause as a preview that stopped responding.

## Checked by `npm run test:examples`

Headless Chrome: the status line reports the install; an element screenshot of the frame, cropped to the canvas, is not blank; Show canvas bounds is on by default and outlines the canvas, unticked it does not, and the canvas pixels are the same both ways; the default code is examples/basic's explainer block character for character and runs with no console message; the frame is sandboxed with `allow-scripts` only, has an opaque origin and cannot reach the page's document; a trusted click on the drawn field focuses the live input and typing changes `input.value` and the preview pixels; a message from another window that carries the run's token is ignored; an error, an unhandled rejection and an HTML string passed to `console.error` reach the console panel as text (Ctrl+Enter runs); Tab and Esc then Tab; the highlighting (HTML, CSS and JS tokens, the copy's metrics, a value set by script, trusted typing, the scroll) and, with the cdnjs scripts blocked, a plain editor with visible text; a code too long for a link and three damaged links; Share then reload restores code with non-ASCII text; Reset; five runs leave one frame; an endless loop is reported while the page keeps answering, and Reset removes the stuck frame and runs the example again in a new process. Its controls: with a broken `dist/` path the page fails, and seven variants of the page (a sandbox with `allow-same-origin`, console text set as HTML, messages heard from any window, the previous frame kept, canvas bounds that never switch off, a highlighted copy not updated on typing, editor text transparent without Prism) each turn their check red. `npm run test:pages` checks it on the assembled site.
