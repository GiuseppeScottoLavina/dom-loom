# Using it with React, Vue, Svelte and Lit

This page separates what was **run** from what was only **designed**. Verified means: a real app built with that framework, loaded after `dist/hic-live-polyfill.iife.js`, driven with trusted input in headless Chrome at DPR 1 by `npm run test:frameworks` (`test/frameworks/run.mjs`), with positive controls that turn red. Versions of the last recorded run (the macOS CI job "headless apps" of 0.1.0-preview.26, headless Chrome 157.0.8103.39): React 19.3.1, Vue 3.5.44, Svelte 5.57.3, Lit 3.3.3, all as development builds. Every scenario and control now also runs against a production build of the same four apps (section 1.1); that run was recorded locally on 2026-11-06 with headless Chrome 156.0.8078.76 and React 19.3.0, Vue 3.5.44, Svelte 5.57.2, Lit 3.3.3. The last recorded runs are named in section 7.

The four apps are in `examples/frameworks/{react,vue,svelte,lit}/`, each with a README. They draw the same picture: a controlled input, a keyed list with Add / Remove first / Reverse buttons and clickable rows, a conditional second drawable (a badge drawn at (340, 300) while it is laid out at the origin), and a component that re-renders every 500 ms.

## 1. What was verified

Every row ran twice, against a development build and a production build of the same app, with the same results unless a cell says otherwise.

| scenario (what the check asserts) | React 19 | Vue 3 | Svelte 5 | Lit 3 (shadow DOM) |
|---|---|---|---|---|
| **oracle**: canvas readback vs a plain-DOM twin of the same app, delta > 16 on <= 3 % of pixels, non-blank (measured: 0.027 %, 0 %, 0 %, 0.027 %) | pass | pass | pass | pass |
| **typing**: a click on the drawn input focuses it; trusted keys update the framework state AND the input and echo pixels | pass | pass | pass | pass |
| **list**: a click on a drawn row runs its handler; Reverse / Add / Remove (drawn buttons) update the state, the live DOM order and the row colours in the canvas; a click on a row then hits the item drawn there | pass | pass | pass | pass |
| **conditional**: the badge is clickable where it is DRAWN, not where it is laid out; unmount removes its pixels and its hit area; remount draws a new element that is clickable; 12 fast toggles end drawn | pass | pass | pass | pass |
| **timer**: a child re-renders every 500 ms; the drawn region changes (8 changes in 3.5 s) | pass | pass | pass | pass |
| **reconcile**: 40 random add / remove / reverse / toggle, 20 ms apart: no error; DOM order equals state order; the children really sit in `<hic-layer>` while `canvas.firstElementChild`, `children` and `child.parentNode` answer the logical tree; the canvas shows the final state | pass | pass | pass | pass |
| **remount**: a sibling rendered after the canvas lands after the layer; the WHOLE canvas unmounted (route-change style) takes its layer with it; a remounted NEW canvas is wired, painted, clickable and typeable; 11 fast unmount / remount cycles leave one canvas and one layer | pass | pass | pass | pass |
| **uninstall** while the timer runs: children return to the canvas, no layer is left, the app keeps re-rendering without errors; `install()` again: the canvas shows the CURRENT state and a drawn row is clickable | pass | pass | pass | pass |
| **hydration**: `hydrateRoot` over `react-dom/server` markup keeps the server node, oracle and typing pass, no hydration error | pass, with `suppressHydrationWarning` on the canvas (section 4) | not run | not run | not applicable |
| **doc-snippets**: the code blocks of section 5, extracted from this file and run as written: non-blank canvas, a click focuses the drawn input, typing changes the canvas | pass | pass | pass | pass |
| **no error**: every scenario fails on any console error, exception or failed request (where a `removeChild` / `insertBefore` `NotFoundError`, a Vue patch error, a Svelte anchor error or a Lit part error would appear) | none | none | none | none (only Lit's own "dev mode" warning, in the development build) |
| **build-mode**: the build is the mode it claims, read from the page at run time (section 1.1) | pass | pass | pass | pass |

Positive controls, all red as required, in both builds: without the polyfill (its URL answers 404) the oracle, the typing, the list hit-test and the doc snippet fail for every framework (C1); a click at the badge's layout position does not reach it (C2); a twin with the list reversed fails the oracle at 8.3 % (C3); the error collector sees a `NotFoundError` thrown by `removeChild` (C4); React markup that does not match the client produces a hydration error (C5; the production build reports it as the minified React error #418). Once: the production build-mode check, run against the development build, fails for every framework (C6).

### 1.1 Development and production builds

`test/frameworks/build.mjs` builds each app twice from the same sources, with esbuild:

- **development** (`<fw>/dist/app.js`): `process.env.NODE_ENV = "development"`, the `development` export condition, Svelte compiled with `dev: true`, not minified.
- **production** (`<fw>/dist/prod/app.js`): `process.env.NODE_ENV = "production"`, minified, the `production` export condition (React's `*.production.js` files, Lit's files outside `development/`, Svelte's `esm-env` DEV flag false), Svelte compiled with `dev: false`, Vue's `esm-bundler` build with `__VUE_PROD_DEVTOOLS__` and `__VUE_PROD_HYDRATION_MISMATCH_DETAILS__` false. React's server-rendered page is rendered by the production `react-dom/server` too.

The test server answers the development URLs with the production files, so the pages and the oracles are the same. The build-mode scenario reads markers that only a development build has: for React, the `bundleType` that `react-dom` reports to a stand-in devtools hook (1 in development, 0 in production) and the `_debugOwner` field of a fiber; for Vue, `__vnode` on an element and the devtools hook replay queue; for Svelte, `__svelte_meta` on an element; for Lit, `litIssuedWarnings`. The receipt of the local run of 2026-11-06:

| app | development build | production build | the page reports |
|---|---|---|---|
| React | 3,745,439 bytes, `bundleType` 1 | 229,008 bytes, `bundleType` 0 | `react-dom` 19.3.0 |
| Vue | 2,045,286 bytes, `__vnode` present | 190,628 bytes, absent | `app.version` 3.5.44 |
| Svelte | 949,433 bytes, `__svelte_meta` present | 66,212 bytes, absent | major version 5 (package 5.57.2) |
| Lit | 473,187 bytes, dev-mode warning | 26,608 bytes, no warning | `lit-element` 4.2.2, `lit-html` 3.3.3, `@lit/reactive-element` 2.1.2 |

The two KNOWN hydration probes of section 4 record warnings that only development React prints; they run in the development build only, and the results file says so.

Framework mechanics these runs exercised: React's keyed reconciliation (`insertBefore` / `removeChild` on the canvas and on the relocated panel) under StrictMode; Vue's `<!--v-if-->` comment anchor as a direct child of the canvas; Svelte 5 comment anchors, snippets and `bind:this`; Lit's ChildPart marker comments and `repeat()` inside a canvas that lives in an open shadow root.

## 2. What a framework sees

The browser does not lay out the children of a `<canvas>`, so the polyfill moves them into a live layer, an element `<hic-layer>` that is the next sibling of the canvas, at `opacity:0` (ARCHITECTURE ADR-A, `docs/API-CONTRACT.md` section 3). Facades keep the DOM looking unchanged (removed again on unmount or uninstall):

- On the canvas: `childNodes`, `children`, `firstChild`, `lastChild`, `firstElementChild`, `lastElementChild`, `childElementCount`, `hasChildNodes`, `append`, `prepend`, `appendChild`, `insertBefore`, `removeChild`, `replaceChild`, `replaceChildren`, `insertAdjacentElement` / `Text` / `HTML` (inside positions), `contains`, `innerHTML`, `textContent`, `querySelector`, `querySelectorAll` and `getElementsBy*` operate on the LOGICAL child list; writes go into the layer. Verified indirectly: all four frameworks inserted, moved and removed children and anchors of the canvas without an error, and the reconcile scenario reads `firstElementChild`, `children` and `parentNode`.
- On the relocated top-level children: `parentNode`, `parentElement`, `previousSibling`, `nextSibling`, `previousElementSibling`, `nextElementSibling` answer as if the child were still inside the canvas.
- On the canvas: `nextSibling`, `nextElementSibling`, `previousSibling` and `previousElementSibling` skip the layer. On the PARENT of the canvas (`options.parentFacade`, default true): `children`, `childNodes`, `childElementCount`, `firstChild`, `lastChild`, `firstElementChild`, `lastElementChild` hide the layer. Verified indirectly: a framework-rendered sibling after the canvas, and a framework-removed and re-inserted canvas, in the same parent.
- `canvas.addEventListener(...)` and `canvas.onclick`-style handlers receive events from the children (with `currentTarget` set to the canvas). Not exercised by the apps: their handlers sit on the children.

The polyfill also WRITES on author elements: `data-hic-canvas` on the canvas at mount, and (after the document's `load` when it mounts during page load) a merged `aria-owns` on the canvas and a generated `id` (`hic-o-<n>-<m>`) on a top-level drawable that has none (`docs/ARCHITECTURE.md` ADR-M). Client-side rendering in all four frameworks ignored them; hydration does not (section 4).

Not hidden (row `tree-identity`, limited; not re-tested here): CSS `:last-child`, `:nth-child`, the `+` combinator, native live collections, `parent.innerHTML` and author `MutationObserver`s on the canvas still see the layer. A query that names the canvas as an ancestor (`document.querySelector('canvas form')`) is rewritten for the layer by `options.selectorBridge` (default `'both'`, row `selector-bridge`); framework refs, as the apps use, need no rewriting.

## 3. Rules that worked

1. **Load the polyfill first**, as a classic script before the app bundle (or `install()` before the framework's first render). Every run did this.
2. **Attributes as plain strings**: `content="drawable"` on the canvas and `drawable=""` on each drawn element. All four frameworks rendered them; React 19 server rendering prints `drawable=""`.
3. **Wire the canvas for the lifetime of THAT canvas element**, not of the component that happens to render it: a React 19 callback ref with a cleanup function, a Vue `watch` on the template ref, a Svelte `$effect` that reads the `bind:this` variable, a Lit `ref()` callback. The remount scenario replaces the canvas element and passes with these. A React `useEffect(..., [])` in the parent, as the previous version of this page showed, keeps listening to the removed canvas; that variant was not run.
4. **Listen with `addEventListener('paint', ...)`**, not `canvas.onpaint =`: the listener survives `uninstall()` / `install()` (uninstall scenario); an `onpaint` property is forgotten (GETTING-STARTED section 2).
5. **Read the drawables from refs inside the paint handler**, and skip one that is `null` / `undefined`. A conditional drawable (mounted, unmounted, re-created, 12 toggles 30 ms apart) never made `drawElementImage` throw in the handler: the paint gate holds `paint` until the new element has a snapshot (API-CONTRACT 4.2). A conditional around a drawable is therefore fine; keys still matter, because a re-created element loses its focus, caret and scroll offset.
6. **Draw in bitmap pixels**: `const s = canvas.width / canvas.clientWidth; ctx.drawElementImage(el, x * s, y * s)`. Only DPR 1 was run, where `s` is 1.
7. **Clicks follow the drawing**: a drawable drawn somewhere else than its layout position is hit where it is drawn (the badge). A top-level drawable is laid out at the canvas content-box origin, so one drawn at (0, 0) is hit where it is laid out.
8. **Give each top-level drawable an `id`** if the page is server-rendered (section 4).
9. **Let the framework remove the canvas**: its layer goes with it (11 fast cycles). Do not hide, remove or adopt `<hic-layer>`.

## 4. Hydration and server rendering

React 19 `hydrateRoot` over `react-dom/server` markup works: the server-rendered panel node is kept (not re-created by the client), the oracle and the typing scenario pass, handlers are attached. Two KNOWN probes of `npm run test:frameworks` watch the caveats (development build only: production React does not compare attributes during hydration); the first is still reproduced on every run:

- The dev build logs `A tree hydrated but some attributes of the server rendered HTML didn't match the client properties` for the canvas, because the polyfill added `data-hic-canvas` before hydration (`aria-owns` is now written after `load`). `suppressHydrationWarning` on the `<canvas>` silences it (verified). React leaves the attributes in place, which is what the polyfill needs.
- Fixed: a top-level drawable WITHOUT an `id` used to get a generated one before hydration (reported on the child); the id is now generated after `load` (probe `react-hydration-generated-child-id` reports it as no longer reproduced).

Vue `createSSRApp` hydration, SvelteKit hydration and Lit SSR were NOT run. Expect the same attribute differences; whether those frameworks report them is unverified.

## 5. Copy-paste patterns

The four blocks below are extracted from this file by `test/frameworks/build.mjs`, wrapped in the smallest page that mounts them (imports, a mount call, a stylesheet that sizes the canvas and the form to 480 x 320), and run by the `doc-snippets` scenario. The full apps in `examples/frameworks/` are the larger reference.

React 19:

```jsx
function useCanvasPainter(drawables) {              // drawables: [[ref, x, y], ...]
  return useCallback((canvas) => {                  // React 19 callback ref with a cleanup function
    if (!canvas) return undefined;
    const ctx = canvas.getContext('2d');
    const onPaint = () => {
      ctx.reset();
      const s = canvas.width / canvas.clientWidth;
      for (const [ref, x, y] of drawables) if (ref.current) ctx.drawElementImage(ref.current, x * s, y * s);
    };
    canvas.addEventListener('paint', onPaint);
    const ro = new ResizeObserver(([e]) => { const b = e.devicePixelContentBoxSize[0]; canvas.width = b.inlineSize; canvas.height = b.blockSize; });
    ro.observe(canvas, { box: 'device-pixel-content-box' });
    return () => { ro.disconnect(); canvas.removeEventListener('paint', onPaint); };
  }, []);
}

function Form() {
  const formRef = useRef(null);
  const canvasRef = useCanvasPainter([[formRef, 0, 0]]);
  const [name, setName] = useState('');
  return (
    <canvas ref={canvasRef} content="drawable" suppressHydrationWarning>
      <form id="form" ref={formRef} drawable="">
        <input value={name} onChange={(e) => setName(e.target.value)} />
      </form>
    </canvas>
  );
}
```

Vue 3 (the body of `setup()`, or of `<script setup>`; the template is the last line):

```js
const canvas = ref(null), form = ref(null), name = ref('');
watch(canvas, (c, _old, onCleanup) => {
  if (!c) return;                                    // runs again when v-if re-creates the canvas
  const ctx = c.getContext('2d');
  const onPaint = () => { ctx.reset(); if (form.value) ctx.drawElementImage(form.value, 0, 0); };
  c.addEventListener('paint', onPaint);
  const ro = new ResizeObserver(([e]) => { const b = e.devicePixelContentBoxSize[0]; c.width = b.inlineSize; c.height = b.blockSize; });
  ro.observe(c, { box: 'device-pixel-content-box' });
  onCleanup(() => { ro.disconnect(); c.removeEventListener('paint', onPaint); });
}, { flush: 'post' });
// template: <canvas ref="canvas" content="drawable"><form id="form" ref="form" drawable=""><input v-model="name"></form></canvas>
```

Svelte 5:

```svelte
<script>
  let canvas = $state(), form = $state(), name = $state('');
  $effect(() => {
    if (!canvas) return;                             // runs again when {#if} re-creates the canvas
    const c = canvas, ctx = c.getContext('2d');
    const onPaint = () => { ctx.reset(); if (form) ctx.drawElementImage(form, 0, 0); };
    c.addEventListener('paint', onPaint);
    const ro = new ResizeObserver(([e]) => { const b = e.devicePixelContentBoxSize[0]; c.width = b.inlineSize; c.height = b.blockSize; });
    ro.observe(c, { box: 'device-pixel-content-box' });
    return () => { ro.disconnect(); c.removeEventListener('paint', onPaint); };
  });
</script>

<canvas bind:this={canvas} content="drawable"><form id="form" bind:this={form} drawable=""><input bind:value={name}></form></canvas>
```

Lit 3 (members of a `LitElement` subclass with `static properties = { name: { state: true } }`; the canvas is in its open shadow root):

```js
formRef = createRef();
onCanvas = (canvas) => {                             // a stable callback: ref() calls it with the element, then with undefined
  this.unwire?.(); this.unwire = null;
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const onPaint = () => { ctx.reset(); if (this.formRef.value) ctx.drawElementImage(this.formRef.value, 0, 0); };
  canvas.addEventListener('paint', onPaint);
  const ro = new ResizeObserver(([e]) => { const b = e.devicePixelContentBoxSize[0]; canvas.width = b.inlineSize; canvas.height = b.blockSize; });
  ro.observe(canvas, { box: 'device-pixel-content-box' });
  this.unwire = () => { ro.disconnect(); canvas.removeEventListener('paint', onPaint); };
};
render() {
  return html`<canvas content="drawable" ${ref(this.onCanvas)}>
    <form id="form" drawable="" ${ref(this.formRef)}><input .value=${this.name ?? ''} @input=${(e) => { this.name = e.target.value; }}></form>
  </canvas>`;
}
```

## 6. Not verified

- DPR 2 or fractional DPR, headed Chrome, a real display refresh rate, other Chromium browsers: only headless Chrome at DPR 1 ran (154 until 2026-10-09, 155 until 2026-10-26, 157 in CI since; 156 for the local run of 2026-11-06).
- Performance of any kind, in either build: no timing was measured.
- Vue, Svelte and Lit server rendering and hydration; React Server Components and streaming SSR.
- A framework that MOVES the canvas (a keyed reorder of the list that contains the canvas), portals into a canvas, a framework-rendered drawable nested inside another drawable, text nodes as direct canvas children, toggling `content` from a framework.
- Event delegation on the canvas itself (`canvas.onclick` receiving events of its children).
- Other frameworks (Preact, Solid, Angular, Qwik, htmx).

## 7. Running the tests and reporting

```sh
npm run build
(cd test/frameworks && npm install)          # React, Vue, Svelte, Lit: test-only deps; the root package keeps zero runtime deps
npm run test:frameworks                      # [--only=react,vue] [--mode=dev|prod|both] [--no-control]; headless Chrome; .scratch/results/frameworks-<ts>.json + PNGs
```

Last recorded local run, development and production builds: 2026-11-06, headless Chrome 156.0.8078.76, DPR 1, React 19.3.0, Vue 3.5.44, Svelte 5.57.2, Lit 3.3.3 (an older local install than the pinned versions): 82 scenario runs with 428 checks and 48 controls, all green, 8 min 10 s (development 4 min 5 s, production 4 min 3 s). Each build has 41 scenario runs, 214 checks and 22 controls; C6 adds 4.

Last recorded CI run (development builds only): 2026-11-06, the macOS CI job "headless apps" on the commit of 0.1.0-preview.26 (`npm ci` in `test/frameworks`, then `node test/frameworks/run.mjs`), headless Chrome 157.0.8103.39, DPR 1, with the versions above, development builds: 37 scenario runs with 202 checks and 22 controls, all green, 4 min 33 s, with the same results for the two KNOWN hydration probes of section 4 as the local run of the same day. Earlier local run: 2026-10-26, headless Chrome 155.0.8059.85, DPR 1, with Svelte 5.57.2 and the other versions above: 37 scenario runs with 202 checks and 22 controls, all green, 4 min 5 s (the run of 2026-10-22 gave the same counts). Of the two KNOWN hydration probes of section 4, the canvas attributes are still reported and the generated child id is no longer reproduced. (The run of 2026-10-09 on Chrome 154.0.8037.98 gave the same counts.)

If something breaks in your app, run `__HIC__.installed.report()` and note which facade or selector was involved; a minimal repro in the style of `examples/frameworks/` is the most useful bug report.
