# Effect plugins: using them and writing them

An effect plugin is a small WebGPU pass that runs over the HTML a canvas draws. The optional effects bundle of this library hosts it: the host uploads the polyfill's picture of one drawable element into a texture, runs the plugins in order, presents the result on the canvas, and maps pointer input back through the plugins so that a click reaches the element the user sees. A plugin may also declare **actions** (a transition that plays, a burst, a hint) that page code runs through the plugin's handle.

This guide is the reference for both sides:

- **Using plugins** (sections 1 to 9): load the bundles, create the host, add plugins, set the frame cap, run actions, reduced motion, errors, removal, a complete page.
- **Writing plugins** (sections 10 to 18): the plugin interface (ABI v2), the context, the instance, the input mapper and `NO_TARGET`, actions, a complete plugin, and how to test a plugin with the shared kit.

The example plugins of this repository live in [`plugins/`](../../plugins/), outside the polyfill; the [plugin gallery](../../examples/plugins/) applies each of them to one live form, and [`examples/effect-plugin/`](../../examples/effect-plugin/) is the smallest page that uses them.

## Extensions, not the standard

The effects host (`HTMLInCanvasEffects`, this plugin interface, the input remapping) and the frame cap (`framecap`, `canvas.frameCap`) are **extensions of this library**. They are not part of the HTML-in-Canvas proposal, and browsers' native implementations do not provide them: they are this library's own API. Code that uses them depends on this library, not on the standard. They are **experimental** ([STABILITY.md](../STABILITY.md)): they may change or be removed in any minor release, with a CHANGELOG entry, and they are not expected to enter the specification. The example plugins of `plugins/` are experimental too: their options, actions, states and looks may change in the same way.

They run over the polyfill's drawing (mode `polyfill`) and over a browser's own HTML-in-Canvas implementation that the installed polyfill stepped aside for (modes `native` and `native-bridged`): the page loads the same bundles and calls the same API, and `createHost` picks the path. Over a native implementation the host needs the standard members `GPUQueue.drawElementImageToTexture`, `updateElementGeometry`, `clearElementGeometry` and `getElementImageDefaultSize`; where one is missing (an earlier draft such as the `layoutsubtree` builds) `createHost` rejects with a `NotSupportedError` and the page keeps its 2D path. The extensions still need the core bundle installed: it decides the mode and defines `canvas.frameCap`, also in the native modes (a property of this library, not of the standard; `uninstall()` removes it). So a page that uses them loads the core's own tag (or calls `install()`), not only the loader, which downloads no core on a native implementation.

#### On a native implementation

Measured on Chrome Canary 158.0.8112.1 with `--enable-blink-features=CanvasDrawElement` (macOS, Apple M1 Max, 120 Hz, DPR 2), by `npm run test:native-effects` (`test/native-effects/`). On 2026-11-04 the same suite passed on Chrome 157.0.8103.39 (Chrome for Testing, where the API is enabled by default; `npm run test:native-effects -- --chrome=<path>`) and on Canary 159.0.8137.0, with the same results on both: G-native-effects 14 of 14 checks, G-native-interposer 10 of 10 (45 of 45 clicks under CRT, 41 of 41 under water, `:hover` 12 of 12), the water and disintegrate gallery e2e and `examples/effect-plugin`, each gate with its controls red.

- **Source.** The host draws the browser's own element image of the source into its texture with `GPUQueue.drawElementImageToTexture`, in the canvas's `paint` event: there the image is fresh, while in the animation frame callbacks before it the call still returns the previous paint. A `paint` event whose `changedElements` names the source is a new source version; the browser fires one when the source changed (typing, hover, the caret blink, a resize). With no plugin, the presented frame is the browser's 2D `drawElementImage` of the same form to within 1 level per channel. There is no partial upload: the event says which drawables changed, not where, so every new version is one full draw (about 0.08 ms of main thread per call).
- **Frames.** A continuous plugin renders from an animation frame loop, and a new source is uploaded and rendered in the `paint` event; one render per frame (a `paint` after the frame was already rendered uploads the source, and the next frame shows it). The `framecap` attribute and `canvas.frameCap` bound the effect frames with the rules of the polyfill's cap: 15.0 and 30.0 effect frames per second at caps 15 and 30. The browser's own `paint` events are not throttled by the cap (the polyfill does not drive them in this mode).
- **Input.** The browser hit-tests the source where `updateElementGeometry` puts it. The host applies the stretch of the source over the canvas there, and the interposer shifts that geometry at every pointer event so that the pointer hits the element the effect shows under it; the browser then does the rest natively: hover, `:active`, the cursor, focus, caret placement and text selection. A press whose native target was hit before its shift (a jump of the pointer, a touch, a picture that moved under a still pointer) is re-targeted as in mode `polyfill`, and `NO_TARGET` takes the source out of hit testing and swallows the gesture. Measured with trusted input where the plain DOM position would miss: 45 of 45 clicks under the CRT plugin at curvature 1 and 40 of 40 under the water plugin at intensity 1 (each of 3 runs of G-native-interposer, 2026-11-12) focus the field the user sees; `:hover` follows that field under a pointer at rest in 12 of 12 places. After a jump of the pointer, hover and the cursor follow one frame later (the engine recomputes them after a layout of one invisible, `aria-hidden` element of the effects, `<hic-hover-sync>`: one per document, appended to the root element at the first such move and removed with the last host; details in `docs/API-CONTRACT.md` 7.6). Keyboard input goes to the focused element, as always.
- **Pause, actions, device loss.** The off-screen pause, `handle.trigger` / `settled`, and the recovery of a lost `GPUDevice` work as in mode `polyfill` (0 effect frames per second far out of view, 3 frames within 21 ms back in view; the device recreated and the loss reported once).
- **Cost.** The water plugin over the F1 form at 120 effect frames per second: renderer main thread busy 19 % (polyfill on Chrome 155: 11 %), RunTask p95 1.2 ms, no task over 8.33 ms; while typing 26 characters at 10 per second, 21.5 % busy (polyfill 15 %), p95 1.1 ms, longest 5.4 ms (polyfill 8.6 ms). The host's own script is about 4 % of that time; the rest is the browser's work for the canvas and its drawable.
- **What differs from mode `polyfill`.** The pixels of the source are the browser's own; the interposer does not take over a press the browser already hit right, so the native default actions apply; `report()` has no canvas entries (the polyfill does not manage the canvas). The under page (`createHost` option `under`, section 12.2) is refused there with `HicUnsupportedError('effects-under')`: the hit-test geometry of a second page is not aimed yet.

Safari Technology Preview with its HTML-in-Canvas feature implements the earlier `layoutsubtree` draft without the GPU upload and the geometry methods: there `createHost` rejects and the examples draw the form in 2D.

Sources of truth: `docs/API-CONTRACT.md` section 7, the typedefs `EffectHost`, `EffectHandle`, `EffectPluginDefinition`, `EffectPluginInstance`, `EffectPluginContext`, `EffectRenderFrame`, `InputMapper` and `EffectActionState` in `src/contracts/types.js`, the validation in `src/effects/plugin-abi.js` and the handles in `src/effects/effect-plugins.js`.

## Using plugins

### 1. Load the bundles

Classic scripts, in this order: the core, the effects host, then the plugins (each plugin bundle registers `window.HicLivePlugins.<name>`; the plugins can load in any order among themselves):

```html
<script src="dist/hic-live-polyfill.iife.min.js"></script>      <!-- the polyfill: installs while this tag runs -->
<script src="dist/hic-live-effects.iife.min.js"></script>       <!-- window.HTMLInCanvasEffects -->
<script src="dist/plugins/water.iife.min.js"></script>          <!-- window.HicLivePlugins.water = {meta, plugin, ...} -->
<script src="dist/plugins/disintegrate.iife.min.js"></script>   <!-- window.HicLivePlugins.disintegrate -->
```

With a bundler: `import { installEffects } from '@giuseppe-scotto-lavina/html-in-canvas-polyfill/effects'` (it defines `window.HTMLInCanvasEffects` and returns the same API) and `import { plugin } from '@giuseppe-scotto-lavina/html-in-canvas-polyfill/plugins/water'`. Every bundle and subpath: [docs/BUNDLES.md](../BUNDLES.md). On Firefox and Safari also load `hic-live-engines.iife.min.js` (it draws form controls in those engines' look).

### 2. Create the host

```js
const host = await HTMLInCanvasEffects.createHost(canvas, source, { maxDpr: 2.5, interposer: true });
```

- `canvas` is a `<canvas content="drawable">` (managed by the polyfill, or drawn by the browser's own implementation); `source` is one drawable element of it (a direct child with the `drawable` attribute, or a descendant marked drawable). The host owns the canvas bitmap and its `webgpu` context: **do not call `canvas.getContext()` before or after** on that canvas.
- The host presents `source` stretched over the whole canvas and applies the matching stretch to the live element, so input follows the picture. **Size the source like the canvas** (section 2.1).

| option | default | |
|---|---|---|
| `maxDpr` | the polyfill's `maxDpr` option (2.5; 3 on phones) | the canvas backing store is its CSS size times `min(devicePixelRatio, maxDpr)` |
| `powerPreference` | the browser's | `'low-power'` or `'high-performance'`, passed to `requestAdapter` |
| `interposer` | `true` | remap pointer input through the spatial plugins (section 14); `false` leaves input to the browser |
| `hdr` | `false` | ask for extended range: the canvas and every target of the chain are `rgba16float` with the `extended` tone mapping, so a value above 1 that a plugin writes is shown brighter than white as far as the display can (white on a display without the headroom). In use only where the browser takes that configuration (`host.stats().hdr`); decided when the host is created. What the example plugins do with it: section 12.1 |
| `under` | none | experimental, over the polyfill only: a second live page beneath the source, another drawable of the same canvas (section 12.2) |
| `device` | none | experimental: the page's `GPUDevice`, shared by several hosts and your own WebGPU work instead of one device per host; the host never destroys it. Or a function that returns the current device, which the host calls again after a device loss (with a plain device the host stops on its last frame and fires `effecterror`) |
| `alphaMode` | `'opaque'` | experimental: `'premultiplied'` makes the canvas transparent where the source and the plugins leave it so (every texture holds premultiplied colours; read it as `context.alphaMode`) |

`createHost` rejects with:

| error | when |
|---|---|
| `HicUnsupportedError`, a `DOMException` named `NotSupportedError` (`feature: 'effect-plugins'`) | no WebGPU, no adapter, or the device request failed; or a native implementation without `GPUQueue.drawElementImageToTexture`, `updateElementGeometry`, `clearElementGeometry` or `getElementImageDefaultSize` (the message names it). The canvas is still free for a 2D context: the adapter and the device are acquired before the canvas is claimed |
| `HicUnsupportedError` (`feature: 'effects-under'`) | `under` over a native implementation |
| `InvalidStateError` | `source` is not an eligible drawable of `canvas`; `under` is not one either, or is the source, inside it or around it; the canvas already has another context type; the core is not installed (or was uninstalled) |
| `TypeError` | `canvas` is not an `HTMLCanvasElement`, `source` not an `Element`, `under` (when given) not an `Element`, `options` not an object |

Keep the standard 2D path as the fallback and choose before any `getContext` call, because a canvas keeps its first context type for life. The effects run over the polyfill and over a native implementation with the members the host needs (section "Extensions, not the standard"); where `createHost` rejects, the page keeps the 2D path:

```js
let host = null;
try {
  if (!navigator.gpu) throw new Error('this browser has no WebGPU');
  host = await HTMLInCanvasEffects.createHost(canvas, form);
} catch (error) {
  const ctx = canvas.getContext('2d');                      // the standard path, without effects
  canvas.onpaint = () => { ctx.reset(); ctx.drawElementImage(form, 0, 0); };
}
```

`host` has `pluginCount`, `addPlugin(definition, options)`, `stats()` (`{frames, fps, uploads, underUploads, pluginErrors, deviceLosses, paused, hdr, pauses, offscreenFrames, sourceVersion, underVersion, remapped, passedThrough}`) `mapPoint(point)` and `destroy()`. `mapPoint` answers where a point of the canvas is in the source: the point through every plugin's input mapper in the frame on screen (canvas-relative CSS pixels of the content box, in and out; `null` where the plugins show nothing of the source; `{x, y, under: true}` where they show the under page). It is what the host does with a pointer; a page uses it to show or log what lies under the pointer as the user sees it (the gallery's "input map" does).

The host does no work for a canvas nobody can see. While the canvas is more than half a viewport (or half its scroll container) out of view, or the document is hidden, it renders nothing, `continuous` plugins included, and uploads nothing; `stats().paused` is then `true`. It starts again before the canvas scrolls back in, so the first frame you see is current; a jump straight into view (`scrollTo`, an anchor) is rendered in the frame that shows it. The frame clock does not stop: on resume an effect shows what it shows at that time, nothing is replayed. An action you trigger, or a `settled()` you await, while the canvas is out of view still completes: the host renders about 10 frames per second until it settles (`stats().offscreenFrames`), and in a hidden document, where the browser runs no frames, on the first frame after the document is shown again. There is no option to turn the pause off: a paused canvas is out of sight.

#### 2.1 Size the source like the canvas

The source element must have exactly the size of the canvas content box (the same CSS width and height, with `box-sizing: border-box` if you use padding). The host does not lay the source out for you: it presents the source texture stretched over the WHOLE canvas, and it applies the matching stretch to the live element so that hit testing follows the picture. That is also why the size matters for input: the pointer mapping goes canvas point -> plugin mappers -> source point, and the source point is only the right element when the source and the canvas have the same coordinate system. With a 400x200 canvas and a 37 px high form, the form is drawn 5.4 times too tall and a click on the drawn field lands on blank space (measured).

When the drawn source and the canvas differ by more than 1 CSS pixel at the first frame, `createHost` prints one `console.warn` per host with both sizes. It does not change anything else.

### 3. Add plugins

```js
const water = await host.addPlugin(HicLivePlugins.water.plugin, { intensity: 0.3 });
const dust = await host.addPlugin(HicLivePlugins.disintegrate.plugin, { onSubmit: 'off' });
```

`addPlugin(definition, options)` validates the definition (`TypeError` naming the first problem), creates the plugin on the host's device and resolves with its **handle**. Plugins run in the order they were added: the first reads the drawn source, each next one reads the previous one's output. Each plugin's options are documented in its README (`plugins/<name>/README.md`); `meta.defaults` of a plugin bundle are the options the gallery uses (a link to the gallery can set others: `&opt.<plugin>.<option>=<value>`, [its README](../../examples/plugins/README.md)). `addPlugin` rejects when the plugin's `create` fails (the error of the plugin) or when the host was destroyed (`InvalidStateError`).

The handle:

| member | |
|---|---|
| `id`, `type` | a unique id (`'water-1'`) and the plugin's type |
| `options` | the current options, frozen |
| `enabled` | `false` after `setEnabled(false)` or after the plugin failed |
| `actions` | the names `trigger` accepts (empty when the plugin declares none) |
| `setOptions(patch)` | merges `patch` into the options and hands the result to the plugin |
| `setEnabled(enabled)` | takes the plugin out of the chain (or back in) without destroying it; `true` also clears a failure |
| `mountUI(root)` | lets the plugin add its own controls, as ordinary HTML, to `root` (it can be inside the drawn form); returns a function that removes them |
| `trigger(action, options?)` | runs an action; resolves with the state the plugin rests in afterwards (section 5) |
| `settled()` | resolves once nothing of the plugin moves, with that state (section 5) |
| `remove()` | destroys the plugin (section 8) |

### 4. The frame cap

The frame cap bounds how often the effect renders: at most `F` effect frames per second for that canvas (and `paint` events and snapshot builds), `0` = the display rate.

```js
canvas.frameCap = 30;                       // or <canvas content="drawable" framecap="30">
```

`canvas.frameCap` reflects the `framecap` attribute (0 to 240; larger values clamp). Plugins do not pace themselves: the host calls them at most at the cap, and a plugin whose animation is a function of the frame clock shows the same picture at the same instant whatever the cap. The example plugins are written that way; the pointer springs of `holo-card` and `liquid-glass` integrate `frame.delta` in substeps of 1/240 s, so at different caps they agree closely, not bit for bit. Rules and measurements: [API-CONTRACT 7.1](../API-CONTRACT.md#71-frame-cap).

### 5. Actions: `trigger` and `settled`

A plugin may declare actions: the transition plugins play, the glitch bursts, the page curl peeks. Page code runs them through the plugin's handle:

```js
form.addEventListener('submit', async (event) => {
  event.preventDefault();
  const gone = await dust.trigger('out');     // 'out' once the form has turned to dust (null if superseded)
  showAnswer();                               // change the page while nothing of it is shown
  const back = await dust.trigger('in');      // 'in' once the form has re-formed, showing the answer
});
```

**`handle.trigger(action, options?)`** returns a promise:

- It **resolves with the state** the plugin rests in once the action has ended, after the frame that shows that state was rendered: for example `'in'` / `'out'` (disintegrate), `'intact'` / `'cracked'` / `'gone'` (shatter). Each plugin documents its states (its README, "Actions").
- It **resolves with `null`** when the action did not complete:
  - a **newer action superseded it**: a newer `trigger` on the same handle (the older promise resolves `null` at the moment the newer `trigger` is called), or an action the plugin started itself (its submit handler, its own buttons), or a declarative option that moves it (`setOptions({ state: 'out' })` of the transition plugins);
  - the plugin was **removed** (`handle.remove()`, `host.destroy()`), **disabled** (`setEnabled(false)`) or **failed** (it threw while rendering);
  - the GPU device was **lost**: the host creates the plugin again on a new device, in the state its options describe, and the action that was playing is gone.
- It **rejects** with:

| error | when |
|---|---|
| `TypeError` | `action` is not one of `handle.actions` (the message lists them: `unknown action "spin" of the plugin "disintegrate"; its actions are 'out', 'in', 'play', 'demo'`); the plugin declares no actions; `options` is not an object; the plugin rejects the options (for example a `point` that is not `{x, y}`) |
| `InvalidStateError` | the plugin was removed, is disabled, or failed |
| the plugin's own error | the plugin threw or rejected while running the action; the plugin keeps running |

`trigger` calls the plugin synchronously, so actions run in the order they are triggered. While the host is creating the plugin again after a device loss, a `trigger` waits for the new instance and runs on it.

**`handle.settled()`** resolves once nothing of the plugin moves any more (at once when nothing moves), with the state it rests in; with `null` when the plugin is removed, disabled or failed. Unlike `trigger` it survives a device loss: it then waits for the re-created instance. A plugin without actions rejects `settled()` with a `TypeError`.

**Reduced motion.** The host reads `prefers-reduced-motion` when an action is triggered and passes it to the plugin. The plugin plays its reduced variant (the transitions crossfade instead of moving pieces), or, when an action has no reduced variant, does nothing and resolves at once with the state it rests in (the water's drop and the page curl's peek). The promises behave the same way in both cases. Some plugins have their own `reducedMotion` option that overrides the user preference (`true` or `false`).

**The plugin's own triggers.** A plugin that runs an action by itself (the submit handler of the transition plugins, the Burst, Strike and "Turn to dust" buttons of `mountUI`) goes through the same path as `trigger`, so it supersedes a pending `trigger` of the page. Nobody awaits those, so their failures are reported as `effecterror` with `phase: 'action'`.

The actions of the example plugins:

| plugin | actions | options | states |
|---|---|---|---|
| [`disintegrate`](../../plugins/disintegrate/README.md#actions) | `out` (to dust, stays gone), `in` (re-forms), `play` (both), `demo` | none | `'in'`, `'out'` |
| [`shatter`](../../plugins/shatter/README.md#actions) | `impact` (cracks an intact pane, breaks a cracked one), `crack`, `out`, `in`, `play`, `demo` | `point: {x, y}` (canvas CSS px) | `'intact'`, `'cracked'`, `'gone'` |
| [`glitch`](../../plugins/glitch/README.md#actions) | `burst`, `demo` | none | `'idle'` |
| [`page-curl`](../../plugins/page-curl/README.md#actions) | `peek` (the dog-ear opens and closes once), `demo` | none | `'rest'`, `'open'` |
| [`water`](../../plugins/water/README.md#actions) | `drop` (a pebble; with `swell: true` one broad swell), `demo` | `point: {x, y}` (canvas CSS px), `strength` (0.08 to 2), `swell` | `'calm'` |
| [`holo-card`](../../plugins/holo-card/README.md#actions) | `demo` (a tilt sweep) | none | `'rest'` |
| [`liquid-glass`](../../plugins/liquid-glass/README.md#actions) | `demo` (a tour of the page) | none | `'free'`, `'pinned'` |
| [`cloth`](../../plugins/cloth/README.md#actions) | `gust` (a gust of wind), `drop` (the pins let go), `in` (hung again), `demo` | `gust`: `direction` (degrees), `strength` (0.1 to 2) | `'hanging'`, `'dropped'` |
| [`ink`](../../plugins/ink/README.md#actions) | `stir` (a stroke through the ink), `clear`, `demo` | `stir`: `point: {x, y}` (canvas CSS px), `angle` (degrees), `strength` (0.1 to 2) | `'still'` |

`crt` is there at rest and has no actions. A plugin whose look depends on an input or an event also has the action `demo`, a short showcase that the plugin gallery plays on selection (section 15.1).

### 6. Reduced motion

Every plugin of this repository states in one line what it does under `prefers-reduced-motion: reduce` (`meta.reducedMotion`, also in `dist/plugins/manifest.json`; the gallery shows it): animations stop or become crossfades, and input keeps working through what is shown. The preference is read when the plugin is created and, for actions, at every `trigger` (section 5). Nothing in the host animates on its own.

### 7. Errors and events

Two events on the canvas:

| event | `detail` | |
|---|---|---|
| `effectframe` | the presented frame: `{now, delta, frameIndex, frameCap, sourceVersion}` | after each presented frame |
| `effecterror` | `{error, type, id, phase}` | a plugin failed; `phase` is `create`, `render`, `resize`, `setOptions`, `recreate`, `destroy`, `mountUI-dispose`, `action` (a trigger of the plugin itself failed) or `settled`; `type: 'host', phase: 'recover'` when the host gave up after GPU device losses |

A plugin that throws while rendering, resizing or taking options is marked failed and is no longer called (the canvas keeps its last presented frame); `handle.enabled` turns `false`, its pending `trigger` and `settled` resolve `null`, and `handle.setEnabled(true)` tries it again. Every error is also recorded in `__HIC__.installed.report().errors` (the first 100) and printed once.

**GPU device loss.** The host keeps presenting the last frame, opens a new device and creates every plugin again with its latest options, re-mounting its UI. More than 3 losses within 10 seconds stop the recovery (`effecterror` with `type: 'host'`).

### 8. Removing plugins and destroying the host

- `handle.remove()` destroys the plugin: its `destroy()` runs, the listeners it added through `context.listen` are removed, its mounted UI is disposed, its pending `trigger` and every `settled()` waiter resolve `null`, and later calls of `trigger` reject (`InvalidStateError`); `settled()` resolves `null`.
- `host.destroy()` removes every plugin, stops rendering, unregisters the input interposer and gives the live element its normal geometry back. A WebGPU canvas context cannot be released: the canvas keeps a (cleared) `webgpu` context, and a later `getContext('2d')` on it returns `null`, as in any browser.
- `uninstall()` of the polyfill destroys every host.

### 9. A complete page

[`examples/effect-plugin/`](../../examples/effect-plugin/) is a complete page with the plugins of this repository in about 30 lines of script: the host, the water plugin, the frame cap, and a disintegrate transition run from the page's submit handler, with the 2D fallback.

The page below runs the plugin written in section 16 instead. Save it as `examples/mine/index.html` and the plugin as `examples/mine/wobble.js` (the demo server serves only `/examples` and `/dist`; opening the file from disk works too). Note that `#src` and `#stage` have the same size (`600x320`):

```html
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>wobble plugin</title>
<script src="../../dist/hic-live-polyfill.iife.min.js"></script>   <!-- 1. core: installs while this tag runs -->
<script src="../../dist/hic-live-effects.iife.min.js"></script>    <!-- 2. defines HTMLInCanvasEffects -->
<script src="wobble.js"></script>                                  <!-- 3. the plugin of section 16 (defines window.WobblePlugin) -->
<style>
  body { margin: 0; font: 14px system-ui, sans-serif; }
  #stage { display: block; width: 600px; height: 320px; }                      /* the canvas: 600 x 320 css px */
  #src { box-sizing: border-box; width: 600px; height: 320px; padding: 40px;   /* the source: EXACTLY the same size */
         background: #f4f4f0; }
  #name { width: 180px; padding: 6px; font: inherit; }
</style>
</head>
<body>
<canvas id="stage" content="drawable">
  <div id="src" drawable>
    <label>name <input id="name" value="wobble" autocomplete="off"></label>
    <button id="go">Pulse</button>
  </div>
</canvas>
<div id="state">starting</div>
<script>
  (async () => {
    const state = document.getElementById('state');
    try {
      // do NOT call canvas.getContext() before this: the host owns the canvas bitmap
      const host = await HTMLInCanvasEffects.createHost(document.getElementById('stage'), document.getElementById('src'), { interposer: true });
      const wobble = await host.addPlugin(WobblePlugin, { amplitude: 8 });
      document.getElementById('go').addEventListener('click', async () => {
        state.textContent = 'pulse: ' + await wobble.trigger('pulse', { amplitude: 30 });   // 'calm', or null when superseded
      });
      state.textContent = 'wobble plugin running: click the wobbling field and type, or press Pulse';
    } catch (error) {                                   // no WebGPU, or the source is not a drawable of the canvas
      state.textContent = 'effect not available: ' + (error && error.message || error);
    }
  })();
</script>
</body>
</html>
```

The handle in short:

```js
const host = await HTMLInCanvasEffects.createHost(canvas, formElement, { maxDpr: 2.5, interposer: true });
const handle = await host.addPlugin(WobblePlugin, { amplitude: 8 });

handle.setOptions({ amplitude: 14 });   // calls instance.setOptions with the merged options
handle.setEnabled(false);               // skip the plugin without destroying it
handle.mountUI(document.getElementById('controls'));   // if the instance implements mountUI(root, ui); returns a dispose function
await handle.trigger('pulse');          // an action: resolves with the state at rest ('calm'), or null when superseded
await handle.settled();                 // nothing moves: the state at rest
handle.remove();                        // destroys the instance; pending actions resolve null
host.destroy();                         // stops rendering; the canvas keeps a (cleared) WebGPU context for life
```

## Writing plugins

To add a plugin to this repository, start from [`plugins/_template/`](../../plugins/_template/): the build discovers the folder, inlines its WGSL, writes its bundles and lists it in the gallery; [`plugins/README.md`](../../plugins/README.md) has the folder contract. The plugin of section 16 is the same kind of plugin written as one classic script for your own page.

### 10. How the pieces fit

```
live HTML  --snapshot-->  source texture  --plugin 1-->  --plugin 2-->  canvas (WebGPU)
 (your form)              (host uploads                    ...            presented frame
                           when it changed)
pointer events on the live layer --interposer--> mapped through the mappers of the PRESENTED frame --> the element the user sees
handle.trigger(action) --host: validate, supersede--> instance.runAction --> resolves after the frame that shows the end state
```

Each plugin reads `frame.sourceView` (the source for the first plugin, the previous plugin's output after that) and writes `frame.destinationView`.

### 11. The definition (ABI v2)

`HTMLInCanvasEffects.definePlugin(def)` (also run by `addPlugin`) validates and freezes a definition; a `TypeError` names the first problem:

| field | rule |
|---|---|
| `type` | non-empty string |
| `apiVersion` | `2` (any other value is a `TypeError`) |
| `version` | finite number (your plugin's own version) |
| `create(context, options)` | function, may be async, returns the instance |
| `outputCapabilities` | optional. `{ directCanvasRenderAttachment: true }` promises that the pass only WRITES its destination as a colour attachment of the same format and never samples or reads it; the host may then give the last plugin the canvas texture directly. Any other key, or a value other than `true`, is a `TypeError`. |
| `actions` | optional. A non-empty array of unique action names, each a lowercase word (`/^[a-z][a-z0-9-]{0,31}$/`): the names `handle.trigger` accepts. The instance must then implement `runAction` and `settled` (section 15). |

### 12. The context

`create` receives `context` and the options passed to `addPlugin`:

| member | |
|---|---|
| `apiVersion` | `2` |
| `canvas`, `source` | the canvas and the drawable element the host samples |
| `adapter`, `device`, `format` | the host's WebGPU adapter and device (a new one after a device loss: `create` runs again; `adapter` is `null` when the page gave the device) and the canvas format (`rgba16float` with extended range) |
| `alphaMode` | `'opaque'`, or `'premultiplied'` when the host was created with it: the source texture and every target hold premultiplied colours, and what you write with an alpha below 1 shows the page; clear to `{ r: 0, g: 0, b: 0, a: 0 }` to leave the background transparent |
| `hdr` | `true` when the host uses extended range: every target is a float texture and a value above 1 is shown brighter than white (section 12.1) |
| `under` | `true` when the host has an under page, a second live page beneath the source (section 12.2) |
| `requestRender()` | asks for a frame (the host renders only when the source changed, on request, or every frame for a `continuous` instance) |
| `viewport()` | `{width, height, cssWidth, cssHeight, dpr}` of the canvas now |
| `listen(type, listener, options)` | adds a listener on the canvas AND on its live layer (pointer events land on the layer), with the options as given (a passive listener stays passive on both); an event reaches it once; removed when the plugin is removed |
| `localPoint(point)` | where a point of the canvas is in the picture THIS plugin rendered: `point` (`{x, y}`, canvas-relative CSS pixels of the content box) through the input mappers of the plugins added after this one, in the newest presented frame. Returns `{x, y}` in the same units, `null` where a later plugin shows nothing of this plugin's picture, `{x, y, under: true}` where a later plugin shows the under page (section 12.2), and the point itself for the last plugin. A plugin that reacts to the pointer reads it through this (below) |
| `trigger(action, options?)` | runs one of the plugin's own actions through the host, exactly as `handle.trigger` (section 15) |

**A plugin that reacts to the pointer** (a drop under it, a lens that follows it, a card that tilts towards it) must put its reaction where the user sees the pointer. With another plugin added after it, the user sees this plugin's picture moved by that one (tilted, curved, refracted), so the pointer's place on the canvas is no longer its place in this plugin's picture. Pass the canvas-relative point through `context.localPoint` and use what comes back; on `null` there is nothing of your picture under the pointer (treat it as the pointer having left). The host answers from the mappers of the frame on screen, the same ones it maps clicks with. The example plugins do it with `pointerIn(context, canvas, clientX, clientY)` of `plugins/_lib/pointer.js`; a test of whether the pointer left the canvas keeps the point on the canvas. What a plugin places from the DOM (the rectangle of the focused element, say) is in the source, and is not moved by the plugins before it: with a plugin that moves pixels added BEFORE yours, such a place is off by what that one moved.

#### 12.1 Extended range (`context.hdr`)

A host created with `{ hdr: true }` uses extended range where the browser supports it (`host.stats().hdr` says whether it does). The canvas and every target of the plugin chain are then `rgba16float`, with the `extended` tone mapping of a WebGPU canvas: what a plugin writes is not clamped, and a value above 1 is shown brighter than the page's white, as far as the display can (on a display without the headroom it is white). The values are sRGB-encoded, as on a standard target: an encoded value `v` above 1 has about `v ^ 2.4` times the luminance of white (1.5 is about 2.6 times, 2 about 5 times). `context.hdr` is `true` and `context.format` is `rgba16float`; without extended range nothing changes for a plugin.

A plugin that does nothing about it still runs, but whatever its maths pushes past 1 (a tint, a diffuse light, a highlight over white text) is now shown above white, over whole areas. The rule the example plugins follow:

- **The page stays under white.** The source as the effect shows it (moved, refracted, tinted, shaded, lit diffusely) is the page's own picture: clamp it to 1. A large bright part of the page (a white panel, a button, a headline) never goes above white as a whole.
- **Added light may go above white.** Light that the effect adds as a light source or as a mirror-like reflection (a glint, a glare, the sun on water, the flash of an impact) may take the sum above 1, up to a peak, through a smooth shoulder: no flat clipped area, and the colour scaled as a whole, not clipped channel by channel (that shifts the hue).
- **Keep it small.** At rest, with nothing moving and no pointer over the canvas, write nothing above white. While the effect plays, the pixels above white are a small part of the canvas (the example plugins stay under about 1.5 % of it), most of them just above white, the peak only in the core of a glint. A highlight that a standard target shows as a broad white patch needs a narrower lobe above white.
- **Write finite values of 0 or more.** A float target keeps a negative value and a NaN, which an 8-bit target hid: a dither around 0, `pow` or `sqrt` of a negative number, a division by 0.
- **The source may exceed 1.** With another plugin before yours, `frame.sourceView` holds what that one wrote, glints above white included. Clamp the source where your maths needs it (a `pow`, a threshold, a bicubic filter), and otherwise carry what is above 1 to your output, so the first plugin's glint is still a glint.
- **Standard range does not change.** Branch on the range and keep the code a standard target always ran: its picture must be the same bit for bit.

The helper `plugins/_lib/hdr.js` gives the example plugins one peak and one shoulder. `hdrConstants(context)` returns `{ HDR_PEAK: 2 }` with extended range and `{ HDR_PEAK: 1 }` without; pass it as `fragment.constants` of a pipeline whose fragment shader declares the pipeline-overridable constant (no uniform changes, and the branch costs nothing: the constant is known when the pipeline is compiled):

```wgsl
override HDR_PEAK : f32 = 1.0;   // 1 on a standard target; the peak on a float target

@fragment
fn fs(...) -> @location(0) vec4<f32> {
  ...
  if (HDR_PEAK > 1.0) {
    // page: what the effect shows of the source; glint: the light it adds
    return vec4<f32>(hdr_light(min(page, vec3<f32>(1.0)), glint), 1.0);
  }
  return vec4<f32>(page + glint, 1.0);   // the code of a standard target, unchanged (the 8-bit target clamps it)
}
```

`hdr_light(base, light)` is `SHOULDER_WGSL` of the same module: up to white it returns `base + light` as it is; above, the sum bends towards `HDR_PEAK` on an exponential shoulder that starts with slope 1, scaled as one colour. Where `base` is already above white (the glint of the plugin before), the shoulder starts there, so that glint passes unchanged. A shader that adds light holds a copy of that text (a plugin's `.wgsl` files are self-contained), and the plugin's test compares the copy with the module's. The peak of 2 is about 5 times white: the headroom of a 1000 cd/m2 display that shows white at 200. The README of each example plugin says what it shows above white and how much, measured.

A plugin that adds no light writes at most white: `glitch` and `disintegrate` clamp their output on a float target.

To test it, add a stage after the plugin that turns "above white" into a visible pixel and count (the `extended range` tests of `plugins/*/test/*-gpu.browser.test.mjs`): a glint is above white, a large bright area of the source is not, nothing is at rest, and nothing is on a host without `hdr`.

#### 12.2 The under page (`context.under`)

Experimental, over the polyfill only. A host created with `createHost(canvas, source, { under })`, where `under` is another drawable of the same canvas (not inside the source, not around it), has a second live page beneath the source: the page that a curl, a peel, a shatter that falls away or a dissolve reveals. Over a native implementation `createHost` rejects `under` with `HicUnsupportedError('effects-under')`: create the host without it there.

- **Drawing.** Every render frame carries `frame.under`: `{texture, view, ready}`, an `rgba8unorm` texture of the under element, sRGB-encoded like the source texture, sized like a source texture, and `ready: false` before its first upload (then it is 1 x 1 and blank). It is the same for every plugin of the chain: a plugin before yours does not process it. `frame.under` is `null` on a host without one, so a plugin that can use it binds a 1 x 1 texture of its own there and keeps its own background.
- **Input.** Where your picture shows the under page, your mapper returns `{x, y, under: true}`, with `(x, y)` the point of the under element (it fills the canvas as the source does, so usually the point itself). That ends the chain, and the host hit-tests the point inside the under page: a click there focuses its field, typing shows up in it. On a host without an under page it counts as `NO_TARGET`.
- **Accessibility.** The host keeps the under element `inert` (out of the tab order and of the accessibility tree) while no plugin of the newest presented frame says it shows it: report `revealsUnder: true` on the instance (a getter is fine; it is read after every presented frame) while your picture shows the under page in a way a user can use. A field of the under page that has the focus is blurred before it turns inert.
- **Cost.** A second page is a second snapshot and a second upload whenever it changes, and a frame when only it changed. Without `under` nothing of it exists. Measured on the gallery's live scene, where both pages change once a second (headless Chrome, Apple M1 Max, canvas 1100 x 640 CSS px at DPR 1, three rounds of 8 s): 33 ms of main thread per second, against 22 ms with no second drawable in the canvas, so about 11 ms per change of the under page (its snapshot and its upload; the upload call itself 0.2 to 0.5 ms), and one more frame per change (16 frames in 8 s instead of 8). An under page kept as `display: none` costs about what no under page costs: its changes wait until it has a box again, and nothing runs meanwhile (21 to 27 ms per second on the gallery's Page curl at 120 Hz, 21 with it removed; up to 1.0.0-rc.8 it kept the frame loop running, 68 ms per second in the measurement above).

Page curl (`plugins/page-curl/`) is the example: the page underneath is the under page where the sheet is lifted, and a press there keeps the sheet open while the page is in use.

### 13. The instance

| member | |
|---|---|
| `render(frame)` | required. Encode your pass into `frame.encoder`. `frame` has `now` (ms), `delta`, `frameIndex`, `frameCap`, `sourceVersion`, `sourceReady`, `encoder`, `sourceView`/`sourceTexture`, `destinationView`/`destinationTexture`, and `width`, `height` (backing pixels), `cssWidth`, `cssHeight`, `dpr`; on a host with an under page also `under` and `underVersion` (section 12.2). When `sourceReady` is false no snapshot has been uploaded yet: write something harmless. `now` is the time of the frame and keeps running while the host is idle or paused off-screen, so `delta` (the time since the previous presented frame) can be seconds long: clamp it before you integrate anything with it (`holo-card` and `liquid-glass`, the example plugins that integrate it, clamp it to 0.1 s). |
| `spatial` | `true` when your output moves pixels. Then `captureInputMapper` is REQUIRED: `addPlugin` rejects with a `TypeError` when the created instance is `spatial` without it. |
| `continuous` | `true` to be rendered on every capped frame even when the source did not change (animations). Otherwise the host renders when the source changed or you call `context.requestRender()`. It may change at runtime (a getter, or a property you assign): the host reads it after every frame, so a plugin that animates only now and then is `continuous` only while it animates. A host with nothing to render is idle and reads it again only at its next frame: after switching it to `true`, call `context.requestRender()`. |
| `captureInputMapper(frame)` | see section 14 |
| `revealsUnder` | on a host with an under page: `true` while your picture shows that page where the user can use it. The host reads it after every presented frame and keeps the under page `inert` while no plugin reports it (section 12.2) |
| `runAction(action, options, info)`, `settled()` | required when the definition declares `actions`; forbidden (`runAction`) otherwise. See section 15 |
| `setOptions(options)` | the merged options after `handle.setOptions` |
| `resize(viewport)` | the canvas size changed |
| `mountUI(root, ui)` | add your controls to `root`; `ui` is `{canvas, getOptions(), setOptions(patch), requestRender(), trigger(action, options?)}`; return a dispose function |
| `destroy()` | free your GPU resources; resolve what your `settled()` waiters wait for with `null` |

Frame pacing: the host renders at most at the canvas frame cap (section 4). Plugins do not pace themselves. With the cap at 30 the plugin is called about 30 times a second.

### 14. The input mapper contract

When a plugin moves pixels, the element under the pointer is not the element the user sees. The host calls `captureInputMapper(frame)` each time a frame is PRESENTED and keeps the mappers of the last 3 presented frames. A mapper answers: "the pixel the user sees at output point P shows the source at which point?"

- Signature: `mapper(point) => {x, y}` with `point = {x, y, width, height}`. `x`, `y` are canvas-relative CSS pixels of the content box; `width`, `height` are the presented size in CSS pixels. The result is in the same coordinate system, in the SOURCE; or `{x, y, under: true}` where your picture shows the host's under page, a point of that page (section 12.2).
- PURE: no reads of the DOM, no state that changes afterwards. Freeze what that frame used (time, options) when `captureInputMapper` is called; a later `render` must not change an earlier mapper. The water plugin (`plugins/water/`) copies its uniform block into one of 4 slots per presented frame; the plugin of section 16 stores `{t, a}` at render time.
- Finite: a mapper that returns a non-finite number makes the host throw a `TypeError` (`an input mapper returned a non-finite point`).
- No element: where the presented pixel shows nothing of the source (a monitor bezel, the space beside a tilted card, a fragment in flight), return `NO_TARGET` (below), not a made-up far-away point.
- Optional `mapper.captureGestureSnapshot()` returns a mapper frozen at that moment. The host calls it at `pointerdown` so a drag keeps one mapping while the picture keeps moving.
- Several spatial plugins: the host composes their mappers, last plugin first.
- Not every plugin moves pixels. A plugin that only tints or blurs is not `spatial` and has no mapper.

What the host does with a mapper (the interposer, on by default; over a native implementation it moves the hit-test geometry instead, see the top of this guide): for `pointermove`, `pointerdown` and `pointerup` on the live layer it maps the pointer, finds the element at the mapped point, and when it is not the one the browser hit (compared by control, or by element where there is no control) it re-implements the activation: focus, the click on `pointerup` at the element drawn there (it bubbles, so a button, link, checkbox, radio, label or summary activates) and a `dblclick` after a double click, `input[type=range]` value and `input`/`change` events during the gesture, text caret placement. The browser's own `click` and `dblclick` at the element it hit are swallowed before any listener of the page sees them; the pointer events stay there (your plugin's listeners read them). It does NOT re-target select popups, drag selection or contenteditable (`interposer-retarget` in `docs/SUPPORT-MATRIX.md`). End to end with trusted input, the interposer is checked through the example plugins in the gallery (`npm run test:plugins`); for other plugins only the mapper against the GPU pixels is checked (section 17).

#### `NO_TARGET`: no element here

`NO_TARGET` is the value a mapper returns for "the user sees no element of the source at this point". It is exported by the effects module (`import { NO_TARGET, isNoTarget } from '@giuseppe-scotto-lavina/html-in-canvas-polyfill/effects'`) and by the classic bundle (`HTMLInCanvasEffects.NO_TARGET`, `HTMLInCanvasEffects.isNoTarget(point)`). The plugins of this repository, built inside it, import `src/effects/no-target.js` by relative path; `src/` is internal and not an entry point of the package.

What the host does with it:
- The mapper chain stops at it. The mappers of the plugins before this one never see the point, so none of them can clamp it back onto the canvas, onto an element (a mapper that clamps to the canvas is common: the water plugin and the wobble plugin of section 16 do it).
- The interposer swallows the gesture: at `pointerdown` it prevents the native handling (no `mousedown`, no focus change, no text selection on the element natively under the pointer), activates nothing at `pointerup`, swallows the `click` that follows, and the focused element keeps the focus. Hover and `:active` show no element of the page, and the cursor is the default arrow.
- Keyboard input is not mapped and still reaches the focused element.

`NO_TARGET` is recognised by a registered symbol (`isNoTarget`), not by identity, so the copy that each plugin bundle carries is the same answer for the host. Its `x` and `y` are finite and far outside any viewport, so code that does not know the value hit-tests nothing there; do not rely on them, test with `isNoTarget`. Pointer events themselves still reach plugin listeners and page code with their native target.

### 15. Actions

Declare the names in the definition and implement two methods on the instance. The host does the rest: it validates the action name and the type of `options`, supersedes the pending action of the handle, resolves pending promises with `null` on removal, disable, failure and device loss, and moves `settled()` waiters to a re-created instance.

```js
definePlugin({ type: 'wobble', apiVersion: 2, version: 1, actions: ['pulse'], create(context, options) { /* ... */ } });
```

`runAction(action, options, info)`:
- `action` is one of your declared names (the host has checked it); `options` is a frozen copy of what the page passed (`{}` when nothing); `info.reducedMotion` is `prefers-reduced-motion: reduce` as the host read it for this call.
- Start the action and return the state your plugin will rest in, or a promise of it. Resolve **after the frame that draws the end state was rendered** (resolve in `render`, after you encoded that frame), so that a page that awaits it and then reads the canvas sees the end state.
- Start the animation's clock at the first frame that renders it (as the example plugins do: the length of the action is then the same at every frame cap), and call `context.requestRender()` if your instance is not `continuous`.
- Drive it from `frame.now`, not from a count of frames: while the canvas is out of view the host renders an unsettled action at about 10 frames per second, and after a hidden document is shown again the next frame may already be past the end of the action.
- Resolve with `null` when your plugin supersedes or cancels the action itself (a submit handler that starts another one).
- Throw a `TypeError` for options you cannot use (the host rejects the trigger with it; your plugin keeps running).
- When the action cannot do anything now (reduced motion without a reduced variant, a state where it makes no sense), return what `settled()` returns: the state you rest in next.

`settled()`: return the state at once when nothing moves, otherwise a promise that you resolve with the state after the frame where the motion ended. In `destroy()`, resolve your waiters with `null`.

Your own triggers (a submit listener, a button of `mountUI`) should call `context.trigger(action, options)` or `ui.trigger(action, options)`, not your internals directly: they then supersede a pending trigger of the page like any other action, the host passes the reduced-motion reading, and a failure is reported as `effecterror` (`phase: 'action'`).

States are short lowercase words that describe what the plugin shows at rest, documented in the plugin's README.

#### 15.1 Touch, `demo` and zero work at rest

Three rules every interactive plugin of this repository follows, and that the plugin gallery checks (`scripts/check-gallery.mjs`). They are about the page around the effect: a finger must still scroll it, a visitor must see what the effect does without guessing, and a page at rest must cost nothing.

**1. Touch: claim a gesture only when it starts on your own handle.** On a phone or a tablet a finger that moves scrolls the page; the browser decides that at `touchstart`, before any `pointermove`. A plugin with something to grab (a lens, a page corner, a shard) claims the gesture only when the touch starts on it, and everywhere else leaves the page its scrolling and the form its interaction:

```js
// in create(): the handle is where the current frame draws it, in canvas CSS px (the coordinates of the input mapper)
let mine = false;   // the current touch started on the handle
const offStart = context.listen('touchstart', (event) => {
  const touch = event.touches[0];
  const box = context.canvas.getBoundingClientRect();
  mine = event.touches.length === 1 && onHandle(touch.clientX - box.left, touch.clientY - box.top);
}, { passive: true });
const offMove = context.listen('touchmove', (event) => {
  if (mine && event.cancelable) event.preventDefault();   // the first move decides: this gesture is the plugin's, not a scroll
}, { passive: false });
```

- `context.listen` adds the listeners on the canvas and on its live layer, where touches land. `preventDefault()` in the first `touchmove` of a touch that started on the handle keeps the browser from scrolling (and from sending `pointercancel`); the pointer events of that gesture then follow, and the plugin's pointer listeners do the rest, as for a mouse.
- Claim at the first `touchmove`, not at `touchstart`: a prevented `touchstart` also cancels the tap, so a tap on a field seen through the handle (a lens) would no longer focus it. A handle that has nothing to tap through, such as a page corner, may claim at `touchstart`.
- The effects host focuses and activates a control for a finger only on a tap (a touch that lifts within 10 css px of where it landed), as a page without effects does: dragging a handle across a field does not focus it. A finger moves no `:hover` through the effect either: a press or a drag hovers nothing, and a tap leaves the element drawn where it landed hovered until the next tap.
- `preventDefault()` in `pointerdown` does not stop a scroll, and `touch-action: none` on the canvas would block scrolling over the whole canvas: use neither.
- A whole-surface effect (ripples, a tilt that follows the finger) does not block scrolling at all: it listens passively (`{ passive: true }`), reacts to taps and to the pointer events the browser delivers, and accepts the `pointercancel` that comes when the page scrolls.
- Mouse and pen keep their own behaviour.
- `meta.touch` (optional, one line) is the hint the gallery shows on a touch screen: "Drag the lens with a finger."

**2. Demo: an action named `demo`.** A plugin whose look depends on an input or an event (a pointer, a submit, an error) declares an action `demo` (in `actions`, so it is also in `meta.actions` of the manifest) that shows the effect without that input:

- `handle.trigger('demo')` plays a short showcase, at most about 4 s, and resolves with the state the plugin rests in; it ends at rest.
- The plugin never starts it by itself: the page does (the gallery triggers it when the effect is selected, and not under reduced motion; `demo=0` in its URL, as in `?effect=water&demo=0`, opens it without the demo).
- User input during the demo takes over at once: a press or a drag on the canvas, a submit, `setOptions`. A newer `trigger` supersedes it like any action.
- With reduced motion (`info.reducedMotion`) it resolves at once with the state at rest, or shows a still that explains the effect.
- The template plugin (`plugins/_template/`) has the smallest complete `demo`: its clock starts at the first frame that renders it, it requests frames only while it moves, a passive `pointerdown` or `setOptions` ends it, and its Node tests check all of that through the real handle.

**3. Zero work at rest.** Once the plugin has settled and nothing changes, the host presents no frame: no `effectframe` event, no animation frame loop for the canvas.

- Be `continuous` only while something moves (a getter, or a property you set), or not at all and call `context.requestRender()` for each frame you need. The host is idle when nothing asks for a frame and the source did not change.
- Measure it, on your own page:

  ```js
  let frames = 0;
  canvas.addEventListener('effectframe', () => { frames += 1; });
  await handle.settled();          // a plugin with actions; otherwise wait until its motion ends
  frames = 0;
  await new Promise((resolve) => setTimeout(resolve, 3000));
  console.log(frames);             // 0
  ```

- A plugin that renders at rest by design (the CRT's flicker, a holographic card's idle sway, an ambient glitch) declares it in `meta.continuous`, one line that says what keeps running (`'The flicker and the rolling bar run at rest; with reduced motion they stop.'`), and keeps that work cheap. The gallery check accepts frames at rest only from such a plugin.
- The host already renders nothing for a canvas out of view or a hidden document (section 2), continuous plugins included.

### 16. A complete plugin: horizontal wobble

A complete ABI v2 plugin as one classic script, with an input mapper and one action. It is the file that the smoke test of `npm run test:examples` runs (`test/examples-smoke/wobble-plugin/wobble-plugin.js`; the test checks that this block and the file are the same). Load order in the page: core, effects bundle, this file (section 9).

```js
// A complete ABI v2 effect plugin: a horizontal wobble. Classic script; load it after hic-live-effects.iife.min.js.
// The shader displaces each output pixel sideways; captureInputMapper is the exact inverse-direction twin of that
// displacement (output point -> the SOURCE point the presented pixel shows), so clicks land on what the user sees.
// One action, 'pulse': handle.trigger('pulse', { amplitude, ms }) swells the wobble and back, then resolves 'calm'.
(() => {
  const FREQUENCY = 0.05;   // radians per css px, vertically
  const SPEED = 2.0;        // radians per second

  const WGSL = /* wgsl */ `
    struct Uniforms { time : f32, amplitude : f32, css : vec2<f32>, resolution : vec2<f32> };
    @group(0) @binding(0) var<uniform> u : Uniforms;
    @group(0) @binding(1) var samp : sampler;
    @group(0) @binding(2) var source : texture_2d<f32>;

    @vertex fn vs(@builtin(vertex_index) i : u32) -> @builtin(position) vec4<f32> {
      var p = array<vec2<f32>, 3>(vec2<f32>(-1.0, -1.0), vec2<f32>(3.0, -1.0), vec2<f32>(-1.0, 3.0));
      return vec4<f32>(p[i], 0.0, 1.0);
    }

    @fragment fn fs(@builtin(position) pos : vec4<f32>) -> @location(0) vec4<f32> {
      var uv = pos.xy / u.resolution;                       // 0..1 over the presented frame
      let cssY = uv.y * u.css.y;                            // css px down the canvas
      uv.x = uv.x + (u.amplitude * sin(cssY * ${FREQUENCY} + u.time * ${SPEED})) / u.css.x;
      return textureSample(source, samp, uv);
    }`;

  /** Source point shown at the presented point p, for a frame rendered at time t (seconds) with amplitude a (css px). PURE. */
  function wobbleSource(t, a, p) {
    const x = p.x + a * Math.sin(p.y * FREQUENCY + t * SPEED);
    return { x: Math.min(p.width, Math.max(0, x)), y: p.y };
  }

  window.WobblePlugin = HTMLInCanvasEffects.definePlugin({
    type: 'wobble',
    apiVersion: 2,
    version: 1,
    outputCapabilities: { directCanvasRenderAttachment: true }, // this pass only writes the destination as a colour attachment
    actions: ['pulse'],                                         // the names handle.trigger accepts (the host checks them)
    async create(context, options) {
      const { device, format } = context;
      const module = device.createShaderModule({ code: WGSL });
      // compiled now, off the main thread: Safari compiles a pipeline it has not seen in about half a second, and with the
      // synchronous createRenderPipeline it does so at the first frame, on the main thread, freezing the page
      const pipeline = await device.createRenderPipelineAsync({
        layout: 'auto',
        vertex: { module, entryPoint: 'vs' },
        fragment: { module, entryPoint: 'fs', targets: [{ format }] },
        primitive: { topology: 'triangle-list' },
      });
      const uniforms = device.createBuffer({ size: 32, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST });
      const sampler = device.createSampler({ magFilter: 'linear', minFilter: 'linear', addressModeU: 'clamp-to-edge', addressModeV: 'clamp-to-edge' });
      const bindGroups = new WeakMap();                      // one bind group per source texture view
      let amplitude = Number(options.amplitude ?? 6);        // css px
      let presented = { t: 0, a: amplitude };                // what the LAST rendered frame used
      let pulse = null;                                      // the running pulse {from, peak, ms}; from: its first frame
      const waiters = [];                                    // settled() calls waiting for the pulse to end
      const settled = () => (pulse ? new Promise((resolve) => waiters.push(resolve)) : 'calm');

      return {
        spatial: true,       // pixels move, so the host REQUIRES captureInputMapper
        continuous: true,    // the wobble animates: render every capped frame even if the source did not change
        setOptions(next) { if (next.amplitude !== undefined) amplitude = Number(next.amplitude) || 0; },
        // The action 'pulse' (handle.trigger): resolve with the state the plugin rests in once the frame that ends it was rendered.
        runAction(action, actionOptions) {
          pulse = { from: NaN, peak: Number(actionOptions.amplitude ?? 24), ms: Number(actionOptions.ms ?? 600) };
          return settled();
        },
        settled,                                             // resolves once nothing of the action moves: 'calm'
        render(frame) {
          const t = frame.now / 1000;
          let a = amplitude;
          if (pulse) {
            if (Number.isNaN(pulse.from)) pulse.from = frame.now;   // the pulse starts at the first frame that renders it
            const k = (frame.now - pulse.from) / pulse.ms;
            if (k < 1) a += (pulse.peak - amplitude) * Math.sin(Math.PI * k);
            else { pulse = null; for (const resolve of waiters.splice(0)) resolve('calm'); }
          }
          presented = { t, a };
          device.queue.writeBuffer(uniforms, 0, new Float32Array([t, a, frame.cssWidth, frame.cssHeight, frame.width, frame.height]));
          let bindGroup = bindGroups.get(frame.sourceView);
          if (!bindGroup) {
            bindGroup = device.createBindGroup({
              layout: pipeline.getBindGroupLayout(0),
              entries: [{ binding: 0, resource: { buffer: uniforms } }, { binding: 1, resource: sampler }, { binding: 2, resource: frame.sourceView }],
            });
            bindGroups.set(frame.sourceView, bindGroup);
          }
          const pass = frame.encoder.beginRenderPass({
            colorAttachments: [{ view: frame.destinationView, loadOp: 'clear', storeOp: 'store', clearValue: { r: 0, g: 0, b: 0, a: 1 } }],
          });
          if (frame.sourceReady) { pass.setPipeline(pipeline); pass.setBindGroup(0, bindGroup); pass.draw(3); }
          pass.end();
        },
        // Called by the host each time a frame is PRESENTED. Freeze the values that frame used: later renders must not change THIS mapper.
        captureInputMapper() {
          const { t, a } = presented;
          return (point) => wobbleSource(t, a, point);
        },
        destroy() { for (const resolve of waiters.splice(0)) resolve(null); uniforms.destroy(); },
      };
    },
  });
  window.WobblePlugin.wobbleSource = wobbleSource; // exposed only so the smoke test can compare it with the GPU's pixels
})();
```

Notes on the code:
- The shader and `wobbleSource` use the same constants and the same formula. The shader moves the source sideways by `amplitude * sin(y * 0.05 + t * 2)` css px, so the mapper adds exactly that to the output x.
- `render` stores `{t, a}` BEFORE encoding; `captureInputMapper` reads that, so the mapper describes the pixels of the frame that was just rendered.
- Bind groups are cached per `frame.sourceView`, because the host may recreate the source texture when the canvas size changes.
- `uniforms` is 32 bytes: the WGSL struct is `f32, f32, vec2, vec2` = 24 bytes, rounded up.
- The action `pulse` follows section 15: `runAction` starts it, its clock starts at the first frame that renders it, `render` resolves the waiters in the frame where it ends, and `destroy` resolves them with `null`. The host checks the action name, supersedes an older pulse and handles removal.

### 17. Testing a plugin

The shared test kit of `plugins/_shared/` (test tooling, not shipped) covers the three levels the example plugins are tested at; [`plugins/README.md`](../../plugins/README.md#tests) has the commands.

**Node** (`plugins/<name>/test/*.test.mjs`, run by `npm run test:unit`):
- `contractTest(import.meta.url)` (`_shared/contract-test.mjs`): the folder satisfies the plugin contract.
- `nodeHandle(plugin, options, {device, canvas, source, reducedMotion})` (`_shared/node-host.mjs`): the plugin behind the REAL handle of the host (`trigger`, `settled`, `setOptions`, `remove`, `context.trigger`, `ui.trigger`), over a fake device; the test calls `render(frame)` itself, so the timing of an action is exact. Every plugin with actions tests them this way: the states, superseding, removal, reduced motion, bad options.
- `fakeGpu()` (`_shared/fake-gpu.mjs`): a recording fake device for single-pass plugins.

**Browser** (`plugins/<name>/test/*.browser.test.mjs`, headless Chrome, `npm run test:unit:browser`), from `/plugins/_shared/gpu-check.mjs`, through the real host on a real WebGPU canvas:
- `checkMapperAgainstGpu(t, plugin, options)`: presents one frame over a grid of white markers and counts the pixels where the mapper's prediction disagrees with the GPU. It passes only when the mapper is right (at most 5 pixels) AND the identity mapper is wrong (at least 200), so the check could have failed.
- `runActionOnGpu(t, plugin, options, action, actionOptions)`: triggers an action through the handle and presents frames on the frame clock until it resolves; returns the state, the largest change against the first frame and the worst agreement of a frame's mapper with its pixels during the action (input must follow the pixels while an action plays too).
- `presentOnce`, `agreement`, `changedPixels`, `markerScene`, `spyMappers`, `lossSpy`, `until`, and `gpuTest` (skipped, never passed, where Chrome has no WebGPU adapter).

**Gallery end to end** (`plugins/<name>/test/gallery.e2e.mjs`, `npm run test:plugins`): the plugin in `examples/plugins/` with trusted input. `_shared/gallery-e2e.mjs` opens the gallery (with `&demo=0`, so a test starts from the plugin's own state; `openGallery(name, { demo: true })` lets the gallery play the demo), takes shots, drags, records; `actionChecks(page, check, steps, supersede)` clicks the gallery's button of each action and checks the state, that the frame changed and that the host goes idle, then from page script an unknown action, superseding and `settled()`.

**The gallery check** (`scripts/check-gallery.mjs`, `npm run test:gallery`, headless Chrome) runs every plugin of the manifest, and the template plugin, through the rules of section 15.1 in the gallery, at 390 x 844 (a phone, touch emulation) and 1194 x 748 (an iPad in landscape): the stage is entirely in the first viewport and the form fits it without an inner scroll; the `demo` plays on selection, resolves within 6 s and not under reduced motion; once it settled, 2 s without any `effectframe` (unless the plugin declares `meta.continuous`); a vertical touch drag that starts on the stage away from a handle scrolls the page; and, once, that the frame cap defaults to the display rate the page measured. At 375 x 667 (a short phone: the stage has its smallest height there and reaches below the first viewport) it checks that the form still fits the stage without an inner scroll. It also runs the gallery's other scenes (`?scene=daylight`, `?scene=live`: other content beside the form, in the same canvas) with the water plugin: the scene fits the same way, a touch tap on its drawn switch changes the scene through the effect, and the live scene's changing content is presented and stops with the scene. And it runs effects in a chain (the gallery's Stack toggle): a second and a third are picked with a tap and taken out again, a fourth is refused, the form's switch shows either effect's controls, nothing is presented at rest, a drop of water under a curved CRT screen lands under the finger (`context.localPoint`, section 12), and every ordered pair of plugins runs. Its positive controls must turn each of those checks red.

How the plugin of section 16 is verified: `npm run test:examples` serves `test/examples-smoke/wobble-plugin/index.html` (a red bar 14 css px wide at x = 300 in the source) in headless Chrome and checks: the host and plugin start; the presented frame is not blank and the live layer has computed opacity 0; amplitude 24 differs from amplitude 0 in more than 400 pixels; and the mapper against the pixels. For the last check the frame is frozen (`framecap=1`), a compositor screenshot is taken, the left edge of the bar must be found on at least 20 rows and move over at least 20 px, and `mapper(edge)` must give x = 300 within 2 px. The control is the identity mapper (what a plugin without a mapper amounts to), which must be wrong by 8 px or more on the same pixels.

Result of one run on one machine (headless Chrome 154.0.8037.98, macOS, DPR 1, amplitude 24): bar edge moved over a range of 48 px, the plugin's mapper was off by at most 1.18 px, the identity mapper by 24.5 px (`.scratch/results/examples-<timestamp>.json`, `numbers.mapper`). This shows the mapper contract works for this plugin; it is not a statement about every plugin or GPU.

The smoke test also runs its action: `handle.trigger('pulse')` resolves `'calm'` after the pulse, `settled()` then resolves `'calm'`, and an unknown action rejects with a `TypeError` that lists `'pulse'`.

### 18. Checklist

- `spatial: true` has a `captureInputMapper`, and it is pure and frozen per frame.
- Where the presented pixel shows no element of the source, the mapper returns `NO_TARGET`.
- The mapper formula is the shader formula (test it against pixels with `checkMapperAgainstGpu`, also during your actions with `runActionOnGpu`).
- Declared `actions` have `runAction` and `settled`; both resolve after the frame that shows the end state; your own triggers go through `context.trigger` / `ui.trigger`; `destroy` resolves your waiters with `null`.
- `meta.reducedMotion` says what the plugin does under `prefers-reduced-motion: reduce`, and the actions honour `info.reducedMotion`.
- Touch: a gesture is claimed (`preventDefault()` in its first `touchmove`, or in `touchstart` for a handle with nothing to tap through) only for a touch that starts on your handle; a whole-surface effect never blocks scrolling (section 15.1).
- A plugin whose look depends on input has a `demo` action of at most about 4 s that ends at rest and gives way to user input.
- At rest, 3 s after it settled, the canvas presents 0 effect frames, unless `meta.continuous` says what runs by design.
- With extended range (`context.hdr`, section 12.1): the page stays under white and only added light goes above it, through a shoulder; nothing is above white at rest; every value written is finite and 0 or more; a source above 1 does not break the maths; the standard-range picture is unchanged.
- Every pipeline is made in `create` with `createRenderPipelineAsync` (or `createComputePipelineAsync`) and awaited. Safari compiles a pipeline it has not seen in about half a second on an iPad, one after the other; with the synchronous call it does so at the pipeline's first use, on the main thread, and the page freezes for that long. Awaited in `create`, the compilation is part of `addPlugin` and the page keeps running.
- You did not call `getContext` on the canvas.
- A 2D fallback exists for browsers without WebGPU, and for a native implementation without the members the host needs (`createHost` rejects there, see the top of this guide).
- You measured the cost on your own page: `docs/guides/PERFORMANCE.md` says which numbers exist and which do not.
