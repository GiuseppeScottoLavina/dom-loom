// Water over the live HTML. A height field simulated on the CPU (sim.js, the wave equation: the wakes and the pebbles of the taps) is
// evaluated here per device pixel as a cubic B-spline (smooth normals and curvature, no grid pattern), and it lights the page below it:
//   - refraction: the page is sampled where the refracted view ray meets it (displacement = slope x depth), exactly as mapWaterPoint()
//     in index.js computes it for the input mapper;
//   - caustics, computed as light is: a mesh of the water surface (vs_caustics) refracts the sunlight by Snell's law onto the page, which
//     lies `caustic` css px below; each triangle adds the ratio of its area on the surface to its area on the page (fs_caustics), so
//     the light is conserved: it gathers into sharp lines under the ripples and leaves the troughs darker, and still water gives exactly 1;
//     the page is lit by it (and the light scattered in the water along the brightest lines shows over dark content too);
//   - Fresnel reflection (Schlick, water F0 = 0.02) of an environment (a sky, a soft window light, a small sun) seen from a viewer above
//     the middle of the canvas: still water shows a faint reflection, and ripples break it up and make the sun glint;
//   - absorption: a little more blue-green where the water is deeper (in the troughs);
//   - a dither of half a level against banding.
// Everything scales with the intensity: at 0 the output is the source.
//
// Extended range (HDR_PEAK > 1): the page under the water, the sky and the window it mirrors and the light it scatters stay under white, as
// on a standard target. Two lights go above it: the sun's disc mirrored by the slope of a ripple (the glint), and the page under the
// brightest caustic lines, where the focused sunlight makes a bright page brighter than white. Still water shows neither.

struct Globals {
  resolution : vec2<f32>,   // device px
  css : vec2<f32>,          // css px of the canvas
  k : vec2<f32>,            // css px of displacement per unit B-spline gradient (per cell), x and y: refract / cell size
  inv_cell : vec2<f32>,     // 1 / cell size, css px
  grid : vec2<f32>,         // interior cells across and down
  time : f32,               // seconds (the ambient swell)
  intensity : f32,
  light : f32,
  ambient : f32,            // amplitude of the ambient swell, css px (0: none)
  field_active : f32,       // 0: the field is flat (nothing to read)
  form_ready : f32,
  refract : f32,            // css px of displacement per unit slope (the refraction depth x intensity)
  caustic : f32,            // css px: how deep the page lies under the water for the sunlight (the caustics)
  caustics_on : f32,        // 1: the caustic texture of this frame is valid (the surface moves); 0: the light is uniform (1)
  pad0 : f32,
  live_box : vec4<f32>,     // the cells of the height field that may be non-zero (padded grid, x0 y0 x1 y1 inclusive); 0 everywhere else
  light_box : vec4<f32>,    // css px (x0 y0 x1 y1) where the caustic texture holds the light (index.js causticRegion); still water's 1 elsewhere
  mesh_from : vec2<f32>,    // the first column and row of the caustic mesh that the pass draws (whole numbers)
  pad1 : vec2<f32>,
}

@group(0) @binding(0) var<uniform> globals : Globals;
@group(0) @binding(1) var form_sampler : sampler;
@group(0) @binding(2) var form_texture : texture_2d<f32>;
@group(0) @binding(3) var height_field : texture_2d<f32>;
// the light on the page, one texel per css px (fs_caustics; 1 under still water)
@group(0) @binding(4) var caustic_texture : texture_2d<f32>;

const PAD : f32 = 2.0;
// the share of the page's light that comes from the sun (the rest from the sky), and how much of the focused light the water scatters
const SUN_SHARE : f32 = 0.85;
const SCATTER : f32 = 0.11;

// Extended range (plugins/_lib/hdr.js): 1 on a standard target; on a float target the largest value to write (sRGB-encoded, above 1).
override HDR_PEAK : f32 = 1.0;

// `base`: the picture, at most white, or what a plugin before this one lit above it. `light`: what this effect adds as a light source or
// a mirror reflection. Up to white the sum is kept as it is; above, it bends towards HDR_PEAK on an exponential shoulder (slope 1 where it
// starts, no plateau), and the colour is scaled as a whole (no channel clips before another: no hue shift). Called only if HDR_PEAK > 1.
fn hdr_light(base : vec3<f32>, light : vec3<f32>) -> vec3<f32> {
  let b = max(base, vec3<f32>(0.0));
  let c = b + max(light, vec3<f32>(0.0));
  let k = clamp(max(b.r, max(b.g, b.b)), 1.0, HDR_PEAK);   // where the shoulder starts: white, or the light that is there already
  let h = max(HDR_PEAK - k, 1e-4);
  let m = max(max(c.r, max(c.g, c.b)), k);
  return c * ((k + h * (1.0 - exp((k - m) / h))) / m);
}
// the sun's disc over the sky (the radiance a standard target shows of it is 12): what its mirror image on a ripple adds above white
const HOT_SUN : f32 = 250.0;
// the caustic light (1 under still water) from which, and at which in full, the page under a caustic line goes above white
const HOT_CAUSTIC : vec2<f32> = vec2<f32>(4.0, 10.0);
// the slope of the surface (after the intensity) from which, and at which in full, it glints: still water and a faint swell do not
const HOT_SLOPE : vec2<f32> = vec2<f32>(0.02, 0.08);

struct VertexOut {
  @builtin(position) position : vec4<f32>,
}

@vertex
fn vs(@builtin(vertex_index) index : u32) -> VertexOut {
  var positions = array<vec2<f32>, 3>(vec2<f32>(-1.0, -1.0), vec2<f32>(3.0, -1.0), vec2<f32>(-1.0, 3.0));
  var out : VertexOut;
  out.position = vec4<f32>(positions[index], 0.0, 1.0);
  return out;
}

// cubic B-spline weights, first and second derivatives (the same polynomials as weights() in sim.js)
fn bs_w(t : f32) -> vec4<f32> {
  let t2 = t * t; let t3 = t2 * t; let o = 1.0 - t;
  return vec4<f32>(o * o * o, 3.0 * t3 - 6.0 * t2 + 4.0, -3.0 * t3 + 3.0 * t2 + 3.0 * t + 1.0, t3) / 6.0;
}
fn bs_d(t : f32) -> vec4<f32> {
  let o = 1.0 - t;
  return vec4<f32>(-0.5 * o * o, 1.5 * t * t - 2.0 * t, -1.5 * t * t + t + 0.5, 0.5 * t * t);
}
fn bs_dd(t : f32) -> vec4<f32> {
  return vec4<f32>(1.0 - t, 3.0 * t - 2.0, 1.0 - 3.0 * t, t);
}

struct Surface {
  h : f32,
  grad : vec2<f32>,   // per cell
  hess : vec3<f32>,   // xx, yy, xy, per cell^2
}

// the B-spline surface over 4 x 4 cells (sim.js surfaceAt: the same cells, the same clamp at the border of the padded grid)
fn surface_at(uv : vec2<f32>) -> Surface {
  var s : Surface;
  s.h = 0.0; s.grad = vec2<f32>(0.0); s.hess = vec3<f32>(0.0);
  let g = uv * globals.grid - vec2<f32>(0.5) + vec2<f32>(PAD);
  let base = floor(g);
  let size = vec2<i32>(textureDimensions(height_field));
  let b = vec2<i32>(base) - vec2<i32>(1);
  // the 4 x 4 cells (clamped as the loads below) all lie where the field is exactly 0: the surface is flat here, the loops would add zeros
  let lo = clamp(b, vec2<i32>(0), size - vec2<i32>(1));
  let hi = clamp(b + vec2<i32>(3), vec2<i32>(0), size - vec2<i32>(1));
  let live = vec4<i32>(globals.live_box);
  if (any(hi < live.xy) || any(lo > live.zw)) { return s; }
  let f = g - base;
  let wx = bs_w(f.x); let wy = bs_w(f.y);
  let dx = bs_d(f.x); let dy = bs_d(f.y);
  let ddx = bs_dd(f.x); let ddy = bs_dd(f.y);
  for (var j = 0; j < 4; j = j + 1) {
    let yy = clamp(b.y + j, 0, size.y - 1);
    var row = vec4<f32>(0.0);
    for (var i = 0; i < 4; i = i + 1) {
      row[i] = textureLoad(height_field, vec2<i32>(clamp(b.x + i, 0, size.x - 1), yy), 0).r;
    }
    let rw = dot(wx, row); let rd = dot(dx, row); let rdd = dot(ddx, row);
    s.h = s.h + wy[j] * rw;
    s.grad = s.grad + vec2<f32>(wy[j] * rd, dy[j] * rw);
    s.hess = s.hess + vec3<f32>(wy[j] * rdd, ddy[j] * rw, dy[j] * rd);
  }
  return s;
}

// the ambient swell (sim.js AMBIENT_WAVES): slope and Hessian (xx, yy, xy) of three plane waves, per css px
fn ambient(p : vec2<f32>, t : f32, amp : f32, slope : ptr<function, vec2<f32>>, hess : ptr<function, vec3<f32>>) {
  var waves = array<vec4<f32>, 3>(
    vec4<f32>(0.019622, 0.007141, 0.76, 1.0),
    vec4<f32>(-0.020143, 0.025003, 0.96, 0.55),
    vec4<f32>(0.019610, -0.042028, 1.25, 0.32));
  var phases = array<f32, 3>(0.0, 1.9, 4.1);
  for (var i = 0; i < 3; i = i + 1) {
    let w = waves[i];
    let phase = w.x * p.x + w.y * p.y - w.z * t + phases[i];
    let c = cos(phase) * w.w * amp;
    let s = sin(phase) * w.w * amp;
    *slope = *slope + c * w.xy;
    *hess = *hess - s * vec3<f32>(w.x * w.x, w.y * w.y, w.x * w.y);
  }
}

// the grid of the caustic texture: one texel per css px (index.js lightGrid)
fn light_grid(css : vec2<f32>) -> vec2<f32> {
  return max(ceil(css - vec2<f32>(0.01)), vec2<f32>(1.0));
}

// ---- the caustics --------------------------------------------------------------------------------------------------------------------
// the mesh: a vertex every MESH_PX css px, over the canvas and a margin around it (the refracted light leans with the slope: rays that
// meet the water beyond an edge can land inside), one triangle strip per row (index.js causticMesh draws the same counts)
const MESH_PX : f32 = 2.0;
const IOR : f32 = 1.333;
// the light that draws the caustics comes from straight above, as the viewer looks: a drop's caustic rings are centred on the drop (an
// oblique light shifts them along its direction, by about 0.2 x the depth: seen from above, a wave whose light lands beside it)
const LIGHT_DIR : vec3<f32> = vec3<f32>(0.0, 0.0, 1.0);

// the light that meets the water beyond an edge can land inside: by at most the depth x the light's tilt by the steepest slope (about
// 1/4 of it), well within this
fn caustic_margin() -> f32 {
  return ceil(0.1 * globals.caustic + 16.0);
}

// the slope of the whole surface (the field, the swell) at p css px, flat beyond the edges of the canvas; tilted by the intensity as the
// picture's normals are
fn surface_slope(p : vec2<f32>) -> vec2<f32> {
  let css = max(globals.css, vec2<f32>(1.0));
  var slope = vec2<f32>(0.0);
  let inside = all(p >= vec2<f32>(0.0)) && all(p <= css);
  if (inside) {
    let uv = p / css;
    if (globals.field_active > 0.5) { slope = slope + surface_at(uv).grad * globals.inv_cell; }
  }
  if (globals.ambient > 0.0) {
    var aslope = vec2<f32>(0.0);
    var ahess = vec3<f32>(0.0);
    ambient(p, globals.time, globals.ambient, &aslope, &ahess);
    slope = slope + aslope;
  }
  return slope * clamp(globals.intensity, 0.0, 1.0);
}

struct CausticOut {
  @builtin(position) position : vec4<f32>,
  @location(0) surface : vec2<f32>,   // where the ray met the water, css px
}

@vertex
fn vs_caustics(@builtin(vertex_index) index : u32, @builtin(instance_index) row : u32) -> CausticOut {
  let css = max(globals.css, vec2<f32>(1.0));
  let m = caustic_margin();
  // the column and row of the whole mesh (the pass draws a part of it from mesh_from): the very vertex the whole pass draws there
  let origin = vec2<u32>(globals.mesh_from);
  let p = vec2<f32>(-m + f32(origin.x + index / 2u) * MESH_PX, -m + f32(origin.y + row + (index & 1u)) * MESH_PX);
  let s = surface_slope(p);
  let n = normalize(vec3<f32>(-s.x, -s.y, 1.0));
  let r = refract(-normalize(LIGHT_DIR), n, 1.0 / IOR);
  let q = p + globals.caustic * r.xy / max(-r.z, 0.05);
  var out : CausticOut;
  out.position = vec4<f32>(q.x / css.x * 2.0 - 1.0, 1.0 - q.y / css.y * 2.0, 0.0, 1.0);
  out.surface = p;
  return out;
}

// each fragment of a triangle receives the light that fell on its area of the surface: (surface area) / (page area), per texel
@fragment
fn fs_caustics(in : CausticOut) -> @location(0) vec4<f32> {
  let css = max(globals.css, vec2<f32>(1.0));
  let texel = css / light_grid(css);
  let a = dpdx(in.surface);
  let b = dpdy(in.surface);
  let ratio = abs(a.x * b.y - a.y * b.x) / (texel.x * texel.y);
  return vec4<f32>(min(ratio, 64.0), 0.0, 0.0, 1.0);
}

// a rounded rectangle of directions around `centre` (half sizes in radians, roughly), with a soft edge
fn soft_box(r : vec3<f32>, centre : vec3<f32>, half_size : vec2<f32>, round : f32) -> f32 {
  let e1 = normalize(cross(vec3<f32>(0.0, 1.0, 0.0), centre));
  let e2 = cross(centre, e1);
  let q = vec2<f32>(dot(r, e1), dot(r, e2));
  let d = abs(q) - half_size + vec2<f32>(round);
  let dist = length(max(d, vec2<f32>(0.0))) + min(max(d.x, d.y), 0.0) - round;
  return (1.0 - smoothstep(-0.05, 0.05, dist)) * step(0.0, dot(r, centre));
}

// radiance seen in direction r (z towards the viewer; x right, y down the canvas)
fn environment(r : vec3<f32>) -> vec3<f32> {
  let up = clamp(r.z, 0.0, 1.0);
  var c = mix(vec3<f32>(0.30, 0.36, 0.44), vec3<f32>(0.85, 0.93, 1.0), up * up);
  // a soft window light up and to the left: still water mirrors it over the top-left of the canvas
  let window_dir = normalize(vec3<f32>(-0.20, -0.19, 0.96));
  let wnd = soft_box(r, window_dir, vec2<f32>(0.17, 0.10), 0.05);
  c = c + vec3<f32>(5.6, 6.0, 6.5) * wnd * (0.75 + 0.25 * max(dot(r, window_dir), 0.0));
  // a small, bright sun to the upper right, just outside what still water mirrors: it glints only on the slopes of the ripples
  let sun_dir = normalize(vec3<f32>(0.33, -0.25, 0.91));
  let sun_cos = max(dot(r, sun_dir), 0.0);
  let sun = pow(sun_cos, 1100.0) * 12.0 + pow(sun_cos, 110.0) * 0.9;   // the disc and its halo
  return c + vec3<f32>(1.0, 0.95, 0.86) * sun;
}

// interleaved gradient noise: a dither of +-0.5 level, stable per pixel
fn dither(p : vec2<f32>) -> f32 {
  return fract(52.9829189 * fract(dot(p, vec2<f32>(0.06711056, 0.00583715)))) - 0.5;
}

@fragment
fn fs(@builtin(position) position : vec4<f32>) -> @location(0) vec4<f32> {
  let resolution = max(globals.resolution, vec2<f32>(1.0));
  let css = max(globals.css, vec2<f32>(1.0));
  let uv = position.xy / resolution;
  let intensity = clamp(globals.intensity, 0.0, 1.0);

  var h = 0.0;
  var disp = vec2<f32>(0.0);          // css px
  var slope = vec2<f32>(0.0);         // of the surface, per css px
  if (globals.field_active > 0.5) {
    let s = surface_at(uv);
    h = s.h;
    disp = globals.k * s.grad;
    slope = s.grad * globals.inv_cell;
  }
  if (globals.ambient > 0.0) {
    var aslope = vec2<f32>(0.0);
    var ahess = vec3<f32>(0.0);
    ambient(uv * css, globals.time, globals.ambient, &aslope, &ahess);
    disp = disp + globals.refract * aslope;
    slope = slope + aslope;
  }
  let displaced_uv = clamp(uv + disp / css, vec2<f32>(0.001), vec2<f32>(0.999));

  // the page below: the drawn HTML, or a dark pool floor where it is transparent
  let pool = mix(vec3<f32>(0.006, 0.030, 0.062), vec3<f32>(0.012, 0.085, 0.140), smoothstep(-0.2, 1.2, displaced_uv.y));
  var form_pixel = vec4<f32>(0.0);
  if (globals.form_ready > 0.5) {
    form_pixel = textureSample(form_texture, form_sampler, displaced_uv);
  }
  var below = mix(pool, form_pixel.rgb, form_pixel.a);
  // extended range: the page is at most white here; what a plugin before this one lit above white is carried to the output through the water
  var lit_before = vec3<f32>(0.0);
  if (HDR_PEAK > 1.0) {
    lit_before = max(below - vec3<f32>(1.0), vec3<f32>(0.0));
    below = min(below, vec3<f32>(1.0));
  }

  let light = clamp(globals.light, 0.0, 1.0) * smoothstep(0.0, 0.35, intensity);

  // the sunlight on the page where the view ray meets it (fs_caustics): 1 under still water
  var sunlight = 1.0;
  let light_at = displaced_uv * css;
  if (globals.caustics_on > 0.5 && all(light_at >= globals.light_box.xy) && all(light_at <= globals.light_box.zw)) {
    // four bilinear samples half a texel apart (a 3 x 3 tent): the lines stay sharp, the sparkle of the thinnest triangles goes
    let t = 0.5 / max(vec2<f32>(textureDimensions(caustic_texture)), vec2<f32>(1.0));
    sunlight = 0.25 * (textureSampleLevel(caustic_texture, form_sampler, displaced_uv + vec2<f32>(-t.x, -t.y), 0.0).r
      + textureSampleLevel(caustic_texture, form_sampler, displaced_uv + vec2<f32>(t.x, -t.y), 0.0).r
      + textureSampleLevel(caustic_texture, form_sampler, displaced_uv + vec2<f32>(-t.x, t.y), 0.0).r
      + textureSampleLevel(caustic_texture, form_sampler, displaced_uv + vec2<f32>(t.x, t.y), 0.0).r);
  }
  // the page is lit by the sky (the rest) and the sun (SUN_SHARE): the colours are sRGB-encoded, so the light is applied to their
  // linear values (a power of 1/2.2 of the factor)
  let lit = max(1.0 - SUN_SHARE * light + SUN_SHARE * light * min(sunlight, 24.0), 0.0);

  // absorption: about 9 % of red over the depth of the water at intensity 1, more in a trough (h < 0)
  let depth = 1.0 - clamp(h * 0.05, -0.5, 0.5);
  let transmit = exp(-vec3<f32>(0.090, 0.030, 0.014) * intensity * depth);
  var color = below * transmit * pow(lit, 1.0 / 2.2) * mix(vec3<f32>(1.0), vec3<f32>(1.0, 0.985, 0.95), step(1.0, lit));

  // Fresnel reflection of the environment, seen from above the middle of the canvas
  let eye = vec3<f32>(0.5 * css, 1.45 * max(css.x, css.y));
  let view = normalize(eye - vec3<f32>(uv * css, 0.0));
  let tilt = slope * intensity;
  let n = normalize(vec3<f32>(-tilt.x, -tilt.y, 1.0));
  let fresnel = 0.02 + 0.98 * pow(1.0 - clamp(dot(n, view), 0.0, 1.0), 5.0);
  let reflected = fresnel * environment(reflect(-view, n));
  // the focused sunlight scattered by the water along its brightest lines, so that they show over dark content too
  let scatter = SCATTER * max(min(sunlight, 24.0) - 1.0, 0.0);
  let added = (reflected + vec3<f32>(0.55, 0.82, 1.0) * scatter) * light;
  // light that the water adds, compressed with a soft knee: at most 0.38 of the range per channel, so it never hides what lies below
  color = color + 0.38 * (vec3<f32>(1.0) - exp(-added / 0.38));

  color = color + vec3<f32>(dither(position.xy) / 255.0) * step(0.001, intensity);
  if (HDR_PEAK > 1.0) {
    // the page under the brightest caustic lines: the part of its focused light that a standard target clips at white
    let page = below * transmit * pow(lit, 1.0 / 2.2) * mix(vec3<f32>(1.0), vec3<f32>(1.0, 0.985, 0.95), step(1.0, lit));
    let caustic = max(page - vec3<f32>(1.0), vec3<f32>(0.0)) * smoothstep(HOT_CAUSTIC.x, HOT_CAUSTIC.y, sunlight);
    // the glint: the sun's disc (narrower than the one a standard target shows: its square) mirrored by a slope, with the water's Fresnel factor
    let disc = pow(max(dot(reflect(-view, n), normalize(vec3<f32>(0.33, -0.25, 0.91))), 0.0), 1100.0);
    let glint = vec3<f32>(1.0, 0.95, 0.86) * (fresnel * disc * disc * HOT_SUN * light * smoothstep(HOT_SLOPE.x, HOT_SLOPE.y, length(tilt)));
    return vec4<f32>(hdr_light(clamp(color, vec3<f32>(0.0), vec3<f32>(1.0)) + lit_before * transmit, caustic + glint), 1.0);
  }
  return vec4<f32>(clamp(color, vec3<f32>(0.0), vec3<f32>(1.0)), 1.0);
}
