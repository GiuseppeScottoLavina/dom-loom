/**
 * Shatter (effect plugin ABI v2): an EXAMPLE of the effects extension of html-in-canvas-polyfill, not part of the polyfill.
 * Two impacts. The first cracks the pane: a spiderweb of cracks runs out from the impact point (the pointer, or the invalid field), each
 * piece shifts a few pixels, the picture bends along the broken edges and the pieces catch the light, and the form stays visible AND usable
 * through the cracked glass. The second impact breaks it: the shards fall out in 3D perspective, turning, lit on their faces, with bright
 * edges, motion blur and small debris, leaving the empty backdrop; then they fly back up into place and the cracks close.
 * Shader: ./shatter.wgsl; geometry, physics and the mapper of the cracked pane: ./shards.js.
 *
 * Input: intact, the mapper is the identity. Cracked (and still), it is the exact inverse of the per-shard offsets and of the bending along
 * the cracks (crackedSource): a click lands on the control drawn under the pointer. While the cracks run or close and while shards fall, are
 * gone or fly back, it BLOCKS pointer input: it returns NO_TARGET (the effects ABI value for "no element here") for every point, so the host
 * swallows the press. Keyboard input is not mapped by the host and still reaches the focused field.
 *
 * Actions (the effect handle: `handle.trigger('impact' | 'crack' | 'out' | 'in' | 'play', { point })`, `handle.settled()`; states
 * 'intact', 'cracked' and 'gone'), also run by the Strike button of mountUI and, with `onSubmit`, by the submit of the form inside the
 * source; `handle.setOptions({ state })` sets the end state declaratively. With prefers-reduced-motion nothing cracks or moves: every
 * impact crossfades to the backdrop and back.
 */

import { wgsl } from './wgsl.js';
import { buildShards, crackedLayout, crackedSource, fallTime, HEAL, MAX_SHARDS, MAX_VERTICES, MAX_WALL_VERTICES, SHARD_FLOATS, SPAN, THICKNESS, VERTEX_FLOATS } from './shards.js';
import { blockedMapper, clampNumber, createTimeline, DEFAULT_INVALID_SELECTOR, findInvalid, identityMapper, parseColor, sourcePointOnCanvas } from '../_lib/transition.js';
import { injectStyle } from '../_lib/ui.js';
import { pointerIn } from '../_lib/pointer.js';
import { actionPoint } from '../_lib/action.js';
import { hdrConstants } from '../_lib/hdr.js';
import { renderPipeline } from '../_lib/gpu.js';

/** @typedef {import('../../src/contracts/types.js').EffectPluginDefinition} EffectPluginDefinition */
/** @typedef {import('../../src/contracts/types.js').EffectRenderFrame} EffectRenderFrame */

export { NO_TARGET, blockedMapper, createTimeline, identityMapper } from '../_lib/transition.js';
export { actionPoint } from '../_lib/action.js';

/**
 * What the plugin gallery and the build read (plugins/README.md).
 * @experimental an example plugin of the effects, an extension of this library, not part of the HTML-in-Canvas standard (docs/STABILITY.md)
 */
export const meta = Object.freeze({
  name: 'shatter',
  title: 'Shatter',
  description: 'An invalid submit cracks the glass over the form (still usable through it); a second one shatters it into falling 3D shards that fly back.',
  defaults: Object.freeze({ duration: 1200, onSubmit: 'invalid', intro: true }),
  reducedMotion: 'With reduced motion nothing cracks or falls: every impact crossfades the form to the backdrop and back.',
});

/** floats of the per-frame part of the uniform block (shatter.wgsl `Uniforms` up to `shards`) */
export const HEADER_FLOATS = 28;
/** css px/s^2 at gravity 1 */
export const GRAVITY = 2400;
/** ms the cracks take to run out from the impact (and to close again when the form heals without falling) */
export const CRACK_MS = 450;
const HOLD_MS = 300;
/** a pointer press younger than this is the impact point of a submit */
const POINTER_MS = 1500;
/** chips of glass that burst out at the first impact, and when the pane breaks */
export const CHIPS_CRACK = 40;
export const CHIPS_FALL = 260;
/** the depth buffer of the fall (2 bytes per sample: the shards span a few hundred css px of depth) */
const DEPTH_FORMAT = 'depth16unorm';
/** the clear colour of the host's passthrough: an assembled frame is then identical to the frame without the plugin */
export const HOST_BACKDROP = Object.freeze([0.004, 0.018, 0.034]);
const DEFAULT_EDGE = Object.freeze([0.85, 0.96, 1]);
/** the picture inside an open crack: dimmed to this share */
export const CRACK_DIM = 0.5;

const lostOn = new WeakSet();
/**
 * The actions of `handle.trigger`. impact: crack an intact pane, or break a cracked one (as 'play'); crack: crack and stay cracked; out:
 * break and stay gone; in: fly back and close the cracks (also heals a cracked pane); play: out, a short pause, in. Option `point`: the
 * impact point in canvas CSS px (default: the last pointer press, else the `impact` option, else the centre).
 */
export const ACTIONS = Object.freeze(/** @type {const} */ (['impact', 'crack', 'out', 'in', 'play', 'demo']));
/** @typedef {'impact'|'crack'|'out'|'in'|'play'|'demo'} Action */
/** the demo: ms one way of its fall takes, and the physics seconds it shows: the shards burst out at about real speed, stop in the air
 *  for the hold of 'play' (still drawn, not faded) and are rewound into place */
export const DEMO_FALL_MS = 700;
export const DEMO_SPAN = 0.66;
/** ms the demo lets the cracked pane rest before it breaks */
export const DEMO_PAUSE_MS = 500;
/** MSAA samples of the fall (the walls and faces of the shards are real geometry, their silhouettes need it) */
export const FALL_SAMPLES = 4;


/** @param {Readonly<Record<string, unknown>>} o */
export function readOptions(o) {
  const submit = o.onSubmit;
  const at = /** @type {any} */ (o.impact);
  return {
    cracks: Math.round(clampNumber(o.cracks, 6, 24, 13)),
    gravity: clampNumber(o.gravity, 0.2, 3, 1),
    duration: clampNumber(o.duration, 300, 8000, 1200),
    edge: parseColor(o.edgeColor, DEFAULT_EDGE),
    edgeAmount: clampNumber(o.edgeAmount, 0, 1, 0.85),
    glint: clampNumber(o.glint, 0, 1, 0.8),
    refraction: clampNumber(o.refraction, 0, 4, 1.6),
    backdrop: parseColor(o.backdrop, HOST_BACKDROP),
    onSubmit: submit === 'invalid' || submit === 'valid' || submit === 'always' ? submit : 'off',
    invalidSelector: typeof o.invalidSelector === 'string' && o.invalidSelector ? o.invalidSelector : DEFAULT_INVALID_SELECTOR,
    intro: o.intro === true,
    reducedMotion: typeof o.reducedMotion === 'boolean' ? o.reducedMotion : null,
    state: /** @type {'out'|'in'|'cracked'} */ (o.state === 'out' || o.state === 'cracked' ? o.state : 'in'),
    impact: at && Number.isFinite(at.x) && Number.isFinite(at.y) ? { x: Number(at.x), y: Number(at.y) } : null,
    seed: clampNumber(o.seed, 0, 1e6, 7),
  };
}

/**
 * How far the cracks have run, css px, for the crack amount c (0 closed, 1 open) on a canvas whose farthest corner is `far` from the impact.
 * @param {number} c @param {number} far
 */
export function crackFront(c, far) {
  const k = Math.min(1, Math.max(0, c));
  return (1 - (1 - k) ** 2.5) * (far + 200);
}

/**
 * The per-frame part of the uniform block. Writes into `data`, allocates nothing.
 * @param {Float32Array} data
 * @param {{width: number, height: number, cssWidth: number, cssHeight: number}} frame
 * @param {ReturnType<typeof readOptions>} s
 * @param {{time: number, crack: number, far: number, fade: number, flash: number, debrisT: number, debrisN: number, alpha: number}} f
 * @param {{x: number, y: number}} impact
 */
export function fillHeader(data, frame, s, f, impact) {
  data[0] = frame.width; data[1] = frame.height; data[2] = frame.cssWidth; data[3] = frame.cssHeight;
  data[4] = f.time; data[5] = GRAVITY * s.gravity; data[6] = f.alpha; data[7] = crackFront(f.crack, f.far);
  data[8] = impact.x; data[9] = impact.y; data[10] = s.edgeAmount; data[11] = f.fade;
  data[12] = f.flash; data[13] = f.crack; data[14] = s.glint; data[15] = 1.6 * Math.max(frame.cssWidth, frame.cssHeight);
  data[16] = f.debrisT; data[17] = f.debrisN; data[18] = THICKNESS; data[19] = s.refraction;
  data[20] = s.backdrop[0]; data[21] = s.backdrop[1]; data[22] = s.backdrop[2]; data[23] = 1;
  data[24] = s.edge[0]; data[25] = s.edge[1]; data[26] = s.edge[2]; data[27] = 1;
}

/** @param {number} a @param {number} b @param {number} x */
function smoothstep(a, b, x) {
  const t = Math.min(1, Math.max(0, (x - a) / (b - a)));
  return t * t * (3 - 2 * t);
}

/** CSS of the plugin UI (mountUI) */
// (each colour is light-dark(on a light page, on a dark page): the controls follow the page's color-scheme)
const UI_CSS = `.hic-shatter-ui{display:grid;grid-template-columns:auto 1fr;gap:4px 12px;align-items:end;font-size:11px;font-weight:700}`
    + `.hic-shatter-ui label{display:grid}.hic-shatter-ui input{width:100%;margin:0;accent-color:light-dark(#0b5f85, #bfe9ff)}.hic-shatter-ui button{padding:7px 14px;font:inherit;border:0;border-radius:10px;cursor:pointer;color:light-dark(#eaf7fd, #06202c);background:light-dark(#0b5f85, #bfe9ff)}`;

/**
 * The plugin's definition (effect plugin ABI v2).
 * @experimental an example plugin of the effects, an extension of this library, not part of the HTML-in-Canvas standard (docs/STABILITY.md)
 * @type {EffectPluginDefinition}
 */
export const plugin = Object.freeze({
  type: 'shatter',
  apiVersion: /** @type {const} */ (2),
  version: 4,
  actions: ACTIONS,
  // every pass only writes its destination as a same-format colour attachment (the shard and debris blending never samples it)
  outputCapabilities: Object.freeze({ directCanvasRenderAttachment: /** @type {const} */ (true) }),
  async create(context, initialOptions) {
    const { device, format, canvas, source } = context;
    const module = device.createShaderModule({ code: await wgsl('shatter.wgsl') });
    const g = /** @type {any} */ (globalThis);
    const layout = device.createBindGroupLayout({
      entries: [
        { binding: 0, visibility: g.GPUShaderStage.VERTEX | g.GPUShaderStage.FRAGMENT, buffer: { type: 'uniform' } },
        { binding: 1, visibility: g.GPUShaderStage.FRAGMENT, sampler: { type: 'filtering' } },
        { binding: 2, visibility: g.GPUShaderStage.FRAGMENT, texture: { sampleType: 'float' } },
      ],
    });
    const pipelineLayout = device.createPipelineLayout({ bindGroupLayouts: [layout] });
    const blend = { color: { srcFactor: 'src-alpha', dstFactor: 'one-minus-src-alpha', operation: 'add' }, alpha: { srcFactor: 'one', dstFactor: 'one-minus-src-alpha', operation: 'add' } };
    // extended range (context.hdr): the fragment shaders that add light read HDR_PEAK (shatter.wgsl); 1 on a standard target
    const constants = hdrConstants(context);
    /** @param {string} vs @param {string} fs @param {string} target @param {any} [extra]  `lit`: the fragment shader reads HDR_PEAK */
    const pipeline = (vs, fs, target, extra = {}) => renderPipeline(device, {
      layout: pipelineLayout,
      vertex: { module, entryPoint: vs, buffers: extra.buffers ?? [] },
      fragment: { module, entryPoint: fs, targets: [{ format: target, ...(extra.blend ? { blend: extra.blend } : {}) }], ...(extra.lit ? { constants } : {}) },
      primitive: { topology: 'triangle-list' },
      // the fall: 4x MSAA and a depth buffer (nearer is smaller); `depth` is [write, compare]
      ...(extra.depth ? { multisample: { count: FALL_SAMPLES }, depthStencil: { format: DEPTH_FORMAT, depthWriteEnabled: extra.depth[0], depthCompare: extra.depth[1] } } : {}),
    });
    const vertexLayout = [{ arrayStride: VERTEX_FLOATS * 4, attributes: [
      { shaderLocation: 0, offset: 0, format: 'float32x2' }, { shaderLocation: 1, offset: 8, format: 'float32x2' }, { shaderLocation: 2, offset: 16, format: 'float32x4' },
    ] }];
    // compiled before the first frame (renderPipeline says why)
    const [full, glass, chips, copy, backdrop3d, shadow3d, glass3d, walls3d, chips3d] = await Promise.all([
      pipeline('vs_full', 'fs_full', format),
      // the pane (cracks running, cracked and still): one sample, no depth, exactly what the input mapper inverts
      pipeline('vs_shard', 'fs_shard', format, { buffers: vertexLayout, blend, lit: true }),
      pipeline('vs_debris', 'fs_debris', format, { blend, lit: true }),
      pipeline('vs_full', 'fs_copy', 'rgba8unorm'),
      // the fall: the backdrop and the shadows on it first (no depth), then the faces and the walls of the slabs (depth), then the chips (tested, not written)
      pipeline('vs_full', 'fs_backdrop', format, { depth: [false, 'always'], lit: true }),
      pipeline('vs_shadow', 'fs_shadow', format, { buffers: vertexLayout, blend, depth: [false, 'always'] }),
      pipeline('vs_shard', 'fs_shard', format, { buffers: vertexLayout, blend, depth: [true, 'less-equal'], lit: true }),
      pipeline('vs_wall', 'fs_wall', format, { buffers: vertexLayout, blend, depth: [true, 'less-equal'], lit: true }),
      pipeline('vs_debris', 'fs_debris', format, { blend, depth: [false, 'less-equal'], lit: true }),
    ]);
    const B = g.GPUBufferUsage;
    const uniforms = device.createBuffer({ size: (HEADER_FLOATS + MAX_SHARDS * SHARD_FLOATS) * 4, usage: B.UNIFORM | B.COPY_DST });
    const vertexBuffer = device.createBuffer({ size: MAX_VERTICES * VERTEX_FLOATS * 4, usage: B.VERTEX | B.COPY_DST });
    const wallBuffer = device.createBuffer({ size: MAX_WALL_VERTICES * VERTEX_FLOATS * 4, usage: B.VERTEX | B.COPY_DST });
    const sampler = device.createSampler({ magFilter: 'linear', minFilter: 'linear', addressModeU: 'clamp-to-edge', addressModeV: 'clamp-to-edge' });
    const header = new Float32Array(HEADER_FLOATS);
    const vertices = new Float32Array(MAX_VERTICES * VERTEX_FLOATS);
    const wallVertices = new Float32Array(MAX_WALL_VERTICES * VERTEX_FLOATS);
    const shardData = new Float32Array(MAX_SHARDS * SHARD_FLOATS);
    const attachment = { view: /** @type {any} */ (null), loadOp: 'clear', storeOp: 'store', clearValue: { r: 0, g: 0, b: 0, a: 1 } };
    /** @type {{colorAttachments: any[], timestampWrites?: any}} */
    const passDescriptor = { colorAttachments: [attachment], timestampWrites: undefined };
    // the fall: drawn into a multisampled target resolved into the destination, with a depth buffer; both made when a fall starts and
    // released once it ends (they hold about 6 bytes per sample per backing pixel, only while shards fly)
    const msaaAttachment = { view: /** @type {any} */ (null), resolveTarget: /** @type {any} */ (null), loadOp: 'clear', storeOp: 'discard', clearValue: attachment.clearValue };
    const depthAttachment = { view: /** @type {any} */ (null), depthClearValue: 1, depthLoadOp: 'clear', depthStoreOp: 'discard' };
    /** @type {{colorAttachments: any[], depthStencilAttachment: any, timestampWrites?: any}} */
    const fallDescriptor = { colorAttachments: [msaaAttachment], depthStencilAttachment: depthAttachment, timestampWrites: undefined };
    /** @type {{colour: any, depth: any, width: number, height: number}|null} */ let fallTargets = null;
    /** @param {number} w @param {number} h */
    const ensureFallTargets = (w, h) => {
      if (fallTargets && fallTargets.width === w && fallTargets.height === h) return;
      releaseFallTargets();
      const usage = g.GPUTextureUsage.RENDER_ATTACHMENT;
      const colour = device.createTexture({ size: [w, h], format, sampleCount: FALL_SAMPLES, usage });
      const depth = device.createTexture({ size: [w, h], format: DEPTH_FORMAT, sampleCount: FALL_SAMPLES, usage });
      fallTargets = { colour, depth, width: w, height: h };
      msaaAttachment.view = colour.createView();
      depthAttachment.view = depth.createView();
    };
    const releaseFallTargets = () => {
      fallTargets?.colour.destroy?.(); fallTargets?.depth.destroy?.();
      fallTargets = null; msaaAttachment.view = null; depthAttachment.view = null;
    };
    /** the frame values of fillHeader, reused */
    const look = { time: 0, crack: 0, far: 0, fade: 1, flash: 0, debrisT: -1, debrisN: 0, alpha: 1 };
    const groups = new WeakMap();
    /** @param {any} view */
    const groupFor = (view) => {
      let group = groups.get(view);
      if (!group) {
        group = device.createBindGroup({ layout, entries: [{ binding: 0, resource: { buffer: uniforms } }, { binding: 1, resource: sampler }, { binding: 2, resource: view }] });
        groups.set(view, group);
      }
      return group;
    };

    const win = /** @type {any} */ (canvas.ownerDocument.defaultView);
    const media = win?.matchMedia?.('(prefers-reduced-motion: reduce)') ?? null;
    /** @param {boolean} [host]  prefers-reduced-motion as the host read it for an action */
    const reduced = (host) => s.reducedMotion ?? host ?? !!media?.matches;
    let s = readOptions(initialOptions ?? {});
    const recovering = lostOn.has(canvas);
    lostOn.delete(canvas);
    // two clocks: the cracks (0 intact, 1 cracked) and the fall (0 in the pane, 1 gone)
    const cracks = createTimeline({ duration: CRACK_MS, gone: !recovering && s.state === 'cracked' && !reduced() });
    const fall = createTimeline({ duration: s.duration, hold: HOLD_MS, gone: s.state === 'out' || (s.intro && !recovering) });
    let stateOption = s.state;
    let crossfade = false;
    let destroyed = false;
    /** the fall started from a cracked pane: the cracks stay open until the way back closes them */
    let precracked = false;
    let wasFalling = !fall.assembled;
    /** what the LAST rendered frame showed: 'intact' | 'cracked' | 'moving' (its mapper is fixed by it) */
    let shown = 'intact';
    let vertexCount = 0;
    let wallCount = 0;
    /** the physics clock of the fall (fallTime): the run in progress starts from the amount and the time of the frame before it */
    const run = { dir: 0, g0: 0, t0: 0 };
    let lastG = fall.g, lastTime = fall.g * SPAN;
    /** physics s at the end of the way out: SPAN, or the shorter DEMO_SPAN of the demo (the part of the fall on screen) */
    let spanEnd = SPAN;
    /** the serial of the demo in progress (0: none), and of the last one */
    let demoRun = 0, demoSerial = 0;
    let strikes = 0, seed = 0;
    /** the pattern the pane last came together along (a fall that ended in place): a strike at its impact cracks it along the same lines */
    /** @type {{x: number, y: number, seed: number}|null} */ let healedFrom = null;
    const impact = { x: 0, y: 0 };
    let far = 1;
    /** the impact of the next crack pattern, built by the next frame (it needs the frame's css size); null: the default point */
    /** @type {{x: number, y: number}|null} */ let pendingImpact = null;
    let layoutPending = !fall.assembled || cracks.phase === 'gone';
    /** the crack pattern on the pane now (null: intact) and the mapper of its still, cracked state: both made once per crack */
    /** @type {ReturnType<typeof crackedLayout>|null} */ let pattern = null;
    /** @type {((p: {x: number, y: number}) => {x: number, y: number})|null} */ let crackedMapper = null;
    /** @type {{x: number, y: number, t: number}} */ const pointer = { x: 0, y: 0, t: -Infinity };
    /** @type {any} */ let lastTexture = null;
    /** @type {any} */ let lastView = null;
    /** @type {any} */ let frozen = null;
    /** @type {any} */ let frozenView = null;
    let useFrozen = false;

    function freeze() {
      if (!lastTexture || !lastView) return false;
      const w = lastTexture.width, h = lastTexture.height;
      if (!frozen || frozen.width !== w || frozen.height !== h) {
        frozen?.destroy?.();
        frozen = device.createTexture({ size: [w, h], format: 'rgba8unorm', usage: g.GPUTextureUsage.TEXTURE_BINDING | g.GPUTextureUsage.RENDER_ATTACHMENT });
        frozenView = frozen.createView();
      }
      const encoder = device.createCommandEncoder();
      const pass = encoder.beginRenderPass({ colorAttachments: [{ view: frozenView, loadOp: 'clear', storeOp: 'store', clearValue: { r: 0, g: 0, b: 0, a: 0 } }] });
      pass.setPipeline(copy); pass.setBindGroup(0, groupFor(lastView)); pass.draw(3); pass.end();
      device.queue.submit([encoder.finish()]);
      return true;
    }

    const intact = () => fall.assembled && cracks.assembled;
    const cracked = () => fall.assembled && cracks.phase === 'gone';
    /** @param {{x: number, y: number}|null} point */
    const newPattern = (point) => {
      const recent = performance.now() - pointer.t < POINTER_MS;
      pendingImpact = point ? { x: point.x, y: point.y } : recent ? { x: pointer.x, y: pointer.y } : s.impact;
      layoutPending = true;
    };

    /** the demo is over (done, superseded, or the user took over): the fall plays at its own speed again */
    const endDemo = () => {
      if (!demoRun) return;
      demoRun = 0;
      fall.setDuration(s.duration);
    };
    /**
     * @param {Action} action @param {{x: number, y: number}|null} [point] @param {boolean} [hostReduced]
     * @returns {Promise<boolean>|null}  true when the end state is reached, false when superseded; null: nothing started (a crack with reduced motion or while shards fall)
     */
    function request(action, point = null, hostReduced = undefined) {
      if (destroyed) return Promise.resolve(false);
      if (action === 'demo') return demo(point, reduced(hostReduced));
      endDemo();
      if (action !== 'in') spanEnd = SPAN;   // a way back keeps the end of the way out it reverses (a stopped demo fall is not faded)
      return start(action, point, reduced(hostReduced));
    }
    /** @param {Exclude<Action, 'demo'>} action @param {{x: number, y: number}|null} point @param {boolean} calm */
    function start(action, point, calm) {
      let done;
      if (action === 'impact') action = calm || !fall.assembled || cracked() || cracks.animating ? 'play' : 'crack';
      if (action === 'crack') {
        if (calm || !fall.assembled) return null;                              // nothing cracks with reduced motion, nor while shards fall
        if (intact()) newPattern(point);
        done = cracks.request('out');
      } else if (action === 'in') {
        done = fall.assembled ? cracks.request('in') : fall.request('in');
      } else {
        if (fall.assembled) {
          useFrozen = freeze();
          crossfade = calm;
          precracked = !cracks.assembled && !calm;
          if (precracked) cracks.jump('out');
          else newPattern(point);
        }
        done = fall.request(action);
      }
      context.requestRender();
      return done;
    }
    /** where the demo strikes a pane that did not just come together, and where the intro joins it: the `impact` option, else the first submit control of the source, else a point right of and below the centre */
    const demoPoint = () => {
      if (s.impact) return s.impact;
      const cw = canvas.clientWidth, ch = canvas.clientHeight;
      try {
        const el = source.querySelector('button[type="submit"], input[type="submit"], button:not([type])');
        const r = el?.getBoundingClientRect();
        if (r && r.width > 0 && r.height > 0) {
          const p = sourcePointOnCanvas(source.getBoundingClientRect(), r, { width: cw, height: ch });
          if (p.x >= 0 && p.y >= 0 && p.x <= cw && p.y <= ch) return p;
        }
      } catch { /* no such control */ }
      return { x: cw * 0.62, y: ch * 0.6 };
    };
    /**
     * The showcase (handle.trigger('demo')): the pane lands if it is not in place, a strike cracks it, it rests a moment, a second strike
     * breaks it, the shards fall (the part of the fall that is on screen, at real speed) and fly back; it ends intact. Any other action, a
     * submit, or the user's pointer or keyboard on the canvas ends it at once. With reduced motion it does nothing (null).
     * @param {{x: number, y: number}|null} point @param {boolean} calm @returns {Promise<boolean>|null}
     */
    function demo(point, calm) {
      if (calm) return null;
      endDemo();
      const mine = ++demoSerial;
      demoRun = mine;
      fall.setDuration(DEMO_FALL_MS);
      const live = () => demoRun === mine && !destroyed;
      return (async () => {
        if (!fall.assembled && !(await start('in', null, false))) return false;
        // the strike: where the pane last came together, along those cracks (read once it is in place), unless the `impact` option says
        // where; else the submit control
        const at = point ?? (!s.impact && healedFrom ? { x: healedFrom.x, y: healedFrom.y } : demoPoint());
        if (live() && !cracked()) {
          if (!(await start('crack', at, false))) return false;
          await new Promise((resolve) => { setTimeout(resolve, DEMO_PAUSE_MS); });
        }
        if (!live()) return false;
        spanEnd = DEMO_SPAN;
        const done = (await start('play', null, false)) === true;
        if (live()) endDemo();
        return done;
      })();
    }
    /** @type {((state: 'intact'|'cracked'|'gone'|null) => void)[]} */ const waiters = [];
    const restingState = () => (!fall.assembled ? 'gone' : cracks.phase === 'gone' ? 'cracked' : 'intact');
    const moving = () => cracks.animating || fall.animating;
    /** resolves once nothing moves, after the frame that draws the end state was rendered; at once when nothing moves */
    const wait = () => (moving() ? new Promise((resolve) => { waiters.push(resolve); }) : Promise.resolve(restingState()));
    // the intro: the shards fly into place, joining where the demo will strike (so its cracks open from there, along the same lines)
    if (fall.phase === 'gone' && s.state === 'in') { crossfade = reduced(); pendingImpact = demoPoint(); request('in'); }

    // the user takes over from the demo: the pane comes back into place (the press itself is mapped as usual)
    const takeOver = () => { if (demoRun) { endDemo(); context.trigger('in'); } };
    context.listen('keydown', takeOver);
    context.listen('pointerdown', (event) => {
      takeOver();
      const e = /** @type {PointerEvent} */ (event);
      // through the plugins added after this one: the glass cracks where the user pressed it as seen (where one of them shows none of it: no point, the element decides)
      const p = pointerIn(context, canvas, e.clientX, e.clientY);
      if (!p) return;
      pointer.x = p.x;
      pointer.y = p.y;
      pointer.t = performance.now();
    });
    const onSubmit = (/** @type {Event} */ event) => {
      if (s.onSubmit === 'off' || !fall.assembled) return;                       // a submit while shards fall changes nothing
      const bad = findInvalid(source, s.invalidSelector);
      const match = s.onSubmit === 'always' || (s.onSubmit === 'invalid' ? !!bad : !bad);
      // the form was fixed: the glass heals, also while its cracks are still running (they close from where they are)
      if (!match) { if (!cracks.assembled && cracks.phase !== 'in') context.trigger('in'); return; }
      if (cracks.animating) return;                                                // a second impact while the cracks run changes nothing
      const recent = performance.now() - pointer.t < POINTER_MS;
      const el = bad ?? /** @type {any} */ (event).submitter;
      const at = !recent && el?.getBoundingClientRect ? sourcePointOnCanvas(source.getBoundingClientRect(), el.getBoundingClientRect(), { width: canvas.clientWidth, height: canvas.clientHeight }) : null;
      context.trigger('impact', at ? { point: at } : undefined);   // through the host, like handle.trigger
    };
    source.addEventListener('submit', onSubmit);
    device.lost?.then?.(() => { if (!destroyed) lostOn.add(canvas); });

    return {
      spatial: true,                      // the pieces move: identity intact, the inverse of the offsets cracked, blocking while anything moves
      get continuous() { return cracks.animating || fall.animating; },
      setOptions(next) {
        takeOver();                       // a change of options during the demo is the user's: the demo ends, the pane comes back
        s = readOptions(next ?? {});
        fall.setDuration(s.duration);
        if (s.state !== stateOption) { stateOption = s.state; request(s.state === 'cracked' ? 'crack' : s.state); }
        context.requestRender();
      },
      runAction(action, options, info) {
        const run = request(/** @type {Action} */ (action), actionPoint(options.point, 'shatter'), info.reducedMotion);
        return run ? run.then((done) => (done ? restingState() : null)) : wait();   // nothing started: the state it rests in
      },
      settled: wait,
      render(/** @type {EffectRenderFrame} */ frame) {
        lastTexture = frame.sourceTexture;
        lastView = frame.sourceView;
        const gFall = frame.sourceReady ? fall.advance(frame.now) : fall.g;
        let gCrack = frame.sourceReady ? cracks.advance(frame.now) : cracks.g;
        const falling = !fall.assembled;
        if (wasFalling && !falling) {   // back in place, cracks closed
          if (pattern) healedFrom = { x: impact.x, y: impact.y, seed };
          cracks.jump('in'); gCrack = 0; precracked = false; crossfade = false;
        }
        wasFalling = falling;
        if (!falling && cracks.assembled) { pattern = null; crackedMapper = null; }
        // the copy is left once the pane is fully gone (the way back is live); a demo fall stops in the air and comes back with its copy
        if ((gFall >= 1 && spanEnd >= SPAN) || !falling) useFrozen = false;
        // how open the cracks are: their own clock, or, during a fall that did not start cracked, the first HEAL of the way out / last of the way back
        const c = falling ? (precracked && fall.phase !== 'in' ? 1 : Math.min(1, gFall / HEAL)) : gCrack;
        if (layoutPending && (falling || c > 0) && !crossfade) {
          // once per crack, not per frame: the cells, their fans and their motion, uploaded to the two preallocated buffers
          const at = pendingImpact ?? { x: frame.cssWidth / 2, y: frame.cssHeight / 2 };
          impact.x = Math.min(frame.cssWidth, Math.max(0, at.x));
          impact.y = Math.min(frame.cssHeight, Math.max(0, at.y));
          far = Math.max(Math.hypot(impact.x, impact.y), Math.hypot(frame.cssWidth - impact.x, impact.y), Math.hypot(impact.x, frame.cssHeight - impact.y), Math.hypot(frame.cssWidth - impact.x, frame.cssHeight - impact.y));
          // a strike where the pane last came together breaks it along the cracks it joined at; elsewhere a new pattern
          const again = healedFrom && Math.abs(healedFrom.x - impact.x) < 0.5 && Math.abs(healedFrom.y - impact.y) < 0.5;
          seed = again && healedFrom ? healedFrom.seed : s.seed + strikes++;
          healedFrom = null;
          const built = buildShards(impact, frame.cssWidth, frame.cssHeight, s.cracks, seed, vertices, shardData, wallVertices);
          vertexCount = built.vertexCount;
          wallCount = built.wallCount;
          device.queue.writeBuffer(vertexBuffer, 0, vertices, 0, vertexCount * VERTEX_FLOATS);
          device.queue.writeBuffer(wallBuffer, 0, wallVertices, 0, wallCount * VERTEX_FLOATS);
          device.queue.writeBuffer(uniforms, HEADER_FLOATS * 4, shardData);
          pattern = crackedLayout(vertices, vertexCount, shardData, built.shardCount, s.refraction);
          const frozenPattern = pattern;
          crackedMapper = (p) => crackedSource(frozenPattern, p);
          layoutPending = false;
          pendingImpact = null;
        }
        // the physics time of this frame: real time on the way out, eased into place on the way back (fallTime)
        const dir = fall.phase === 'out' ? 1 : fall.phase === 'in' ? -1 : 0;
        if (dir !== run.dir) { run.dir = dir; run.g0 = lastG; run.t0 = lastTime; }
        const time = !falling ? 0 : dir !== 0 ? fallTime(dir, gFall, run.g0, run.t0, spanEnd) : gFall >= 1 ? spanEnd : lastTime;
        lastG = falling ? gFall : 0;
        lastTime = time;
        const breaking = falling && time >= HEAL * SPAN;
        const pane = !crossfade && c > 0 && vertexCount > 0 && pattern !== null;   // the cracked pane is drawn (still, or with its cracks running)
        shown = falling || cracks.animating ? 'moving' : pane ? 'cracked' : 'intact';
        look.time = time;
        look.crack = c;
        look.far = far;
        look.fade = crossfade ? 1 - gFall : pane && !falling ? CRACK_DIM : 1;
        look.flash = falling ? (precracked && fall.phase !== 'in' ? 1.2 * (1 - smoothstep(0, HEAL * 0.8, gFall)) : 0)
          : cracks.phase === 'out' ? 1.5 * (1 - smoothstep(0, 0.6, gCrack)) : 0;
        look.debrisT = breaking ? time - HEAL * SPAN : cracks.phase === 'out' ? gCrack : -1;
        look.debrisN = breaking ? CHIPS_FALL : CHIPS_CRACK;
            // the shards fade out at the end of a full fall; a demo fall stops with them in the air
        look.alpha = spanEnd < SPAN ? 1 : 1 - smoothstep(0.82, 1, gFall);
        fillHeader(header, frame, s, look, impact);
        device.queue.writeBuffer(uniforms, 0, header);
        attachment.view = frame.destinationView;
        attachment.clearValue.r = s.backdrop[0]; attachment.clearValue.g = s.backdrop[1]; attachment.clearValue.b = s.backdrop[2];
        const timestamps = frame.profiling?.timestampWrites?.('shatter');
        // shards in the air: slabs of glass with depth, drawn with MSAA into a target resolved into the destination
        const flying = frame.sourceReady && falling && !crossfade && (gFall < 1 || look.alpha > 0) && vertexCount > 0;
        if (flying) ensureFallTargets(frame.width, frame.height);
        else if (fallTargets && !(falling && fall.animating)) releaseFallTargets();   // kept through the hold of 'play', released at rest
        let pass;
        if (flying) {
          msaaAttachment.resolveTarget = frame.destinationView;
          fallDescriptor.timestampWrites = timestamps;
          pass = frame.encoder.beginRenderPass(fallDescriptor);
          pass.setBindGroup(0, groupFor(useFrozen && frozenView ? frozenView : frame.sourceView));
          pass.setPipeline(backdrop3d); pass.draw(3);                                      // the lit backdrop behind the pane
          pass.setVertexBuffer(0, vertexBuffer);
          pass.setPipeline(shadow3d); pass.draw(vertexCount, 1);                          // the shadows on it
          pass.setPipeline(glass3d); pass.draw(vertexCount, 2);                           // the front and back faces
          pass.setVertexBuffer(0, wallBuffer);
          pass.setPipeline(walls3d); pass.draw(wallCount, 1);                             // the edges of the slabs
          if (look.debrisT >= 0) { pass.setPipeline(chips3d); pass.draw(3, look.debrisN); }
        } else {
          passDescriptor.timestampWrites = timestamps;
          pass = frame.encoder.beginRenderPass(passDescriptor);
          if (frame.sourceReady) {
            pass.setBindGroup(0, groupFor(useFrozen && frozenView ? frozenView : frame.sourceView));
            if (crossfade || (!falling && !pane)) { pass.setPipeline(full); pass.draw(3); }   // intact (the host's passthrough), or the crossfade
            else if (!falling) {
              pass.setPipeline(full); pass.draw(3);                                         // the picture in place, dimmed: seen inside the open cracks
              pass.setPipeline(glass); pass.setVertexBuffer(0, vertexBuffer); pass.draw(vertexCount, 1);
              if (look.debrisT >= 0) { pass.setPipeline(chips); pass.draw(3, look.debrisN); }
            }
          }
        }
        pass.end();
        if (waiters.length && frame.sourceReady && !moving()) { const state = restingState(); for (const resolve of waiters.splice(0)) resolve(state); }
      },
      // the mapper of the frame just presented: the identity, the mapper of this crack pattern (made once per crack), or blocking
      captureInputMapper() { return shown === 'intact' ? identityMapper : shown === 'cracked' && crackedMapper ? crackedMapper : blockedMapper; },
      mountUI(root, ui) {
        const doc = root.ownerDocument;
        injectStyle(doc, 'shatter', UI_CSS);
        const box = doc.createElement('div');
        box.className = 'hic-shatter-ui';
        box.innerHTML = '<button type="button">Strike</button><label>Cracks<input type="range" min="6" max="24" step="1"></label>';
        const count = /** @type {HTMLInputElement} */ (box.querySelector('input'));
        count.value = String(readOptions(ui.getOptions()).cracks);
        const button = /** @type {HTMLButtonElement} */ (box.querySelector('button'));
        const onStrike = () => { ui.trigger('impact'); };   // the impact: the pointer press on this button; a second strike breaks the pane
        const onCount = () => ui.setOptions({ cracks: Number(count.value) });
        button.addEventListener('click', onStrike);
        count.addEventListener('input', onCount);
        root.append(box);
        return () => { button.removeEventListener('click', onStrike); count.removeEventListener('input', onCount); box.remove(); };
      },
      destroy() {
        destroyed = true;
        fall.cancel();
        cracks.cancel();
        for (const resolve of waiters.splice(0)) resolve(null);
        source.removeEventListener('submit', onSubmit);
        uniforms.destroy?.();
        vertexBuffer.destroy?.();
        wallBuffer.destroy?.();
        releaseFallTargets();
        endDemo();
        frozen?.destroy?.();
      },
    };
  },
});

