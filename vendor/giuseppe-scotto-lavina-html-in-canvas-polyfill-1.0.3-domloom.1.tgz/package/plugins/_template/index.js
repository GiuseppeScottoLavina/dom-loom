/**
 * PLUGIN TEMPLATE (plugins/README.md): the smallest complete spatial effect plugin. It shifts the picture right by `offset` CSS pixels,
 * and has two actions: `handle.trigger('shift', { offset })` moves the picture and resolves 'still' once a frame shows it, and
 * `handle.trigger('demo')` plays a short showcase (the picture swings out and back) and resolves 'still' when it ends at rest.
 * It does no work at rest: it is not `continuous` and asks for frames only while the demo moves (docs/guides/EFFECTS-PLUGINS.md,
 * "Touch, demo and zero work at rest"). It has no handle a finger could grab, so it claims no touch gesture.
 * Copy this folder to plugins/<name>/, rename `meta.name` and `plugin.type` to <name>, and replace the shader, the mapper and the action
 * (or drop `actions`, `runAction` and `settled` when the plugin has nothing to trigger).
 *
 * Contract of a plugin folder: index.js exports `meta` and `plugin`; it imports only files of its own folder, plugins/_lib/ and
 * src/effects/no-target.js (NO_TARGET, the mapper's answer for "no element here"); .wgsl files are loaded
 * through ./wgsl.js (the build inlines them); README.md; test/*.test.mjs. Folders whose name starts with '_' are not built.
 */

import { wgsl } from './wgsl.js';
import { renderPipeline } from '../_lib/gpu.js';

/** @typedef {import('../../src/contracts/types.js').EffectPluginDefinition} EffectPluginDefinition */
/** @typedef {import('../../src/contracts/types.js').InputPoint} InputPoint */

/**
 * Read by the build (manifest) and the plugin gallery. `defaults` are the options the gallery passes to addPlugin.
 * @experimental an example plugin of the effects, an extension of this library, not part of the HTML-in-Canvas standard (docs/STABILITY.md)
 */
export const meta = Object.freeze({
  name: 'template',
  title: 'Offset (template)',
  description: 'Shifts the picture sideways; the smallest complete spatial plugin, with an input mapper.',
  defaults: Object.freeze({ offset: 24 }),
  reducedMotion: 'Nothing moves on its own: the picture is shifted, not animated, and the demo resolves at once.',
});

/** floats in the uniform block: resolution (2), css_width, offset_px */
const UNIFORM_FLOATS = 4;
const MAX_OFFSET = 200;
/** the demo: the picture swings DEMO_SWING CSS px further and back, in DEMO_MS (at most ~4 s, contract 2) */
export const DEMO_MS = 1600;
export const DEMO_SWING = 48;

/**
 * The offset the demo shows `elapsed` ms after its first frame: out and back with zero velocity at both ends (raised cosine). PURE.
 * @param {number} base  the offset at rest @param {number} elapsed
 */
export function demoOffset(base, elapsed) {
  const t = Math.min(1, Math.max(0, elapsed / DEMO_MS));
  return Math.min(MAX_OFFSET, base + DEMO_SWING * (1 - Math.cos(2 * Math.PI * t)) / 2);
}

/** @param {unknown} v */
const clampOffset = (v) => Math.min(MAX_OFFSET, Math.max(0, Number(v) || 0));

/**
 * The input mapper formula, the twin of fs() in offset.wgsl: the presented point `point` shows the source at the returned point. PURE.
 * @param {number} offset  CSS px the frame was shifted by
 * @param {InputPoint} point  canvas CSS px, plus the presented size
 */
export function mapOffsetPoint(offset, point) {
  return { x: Math.max(0, point.x - offset), y: point.y };
}

/**
 * The plugin's definition (effect plugin ABI v2).
 * @experimental an example plugin of the effects, an extension of this library, not part of the HTML-in-Canvas standard (docs/STABILITY.md)
 * @type {EffectPluginDefinition}
 */
export const plugin = Object.freeze({
  type: 'template',
  apiVersion: /** @type {const} */ (2),
  version: 1,
  // the pass only writes its destination as a same-format colour attachment (it never samples or reads it)
  outputCapabilities: Object.freeze({ directCanvasRenderAttachment: /** @type {const} */ (true) }),
  // the names handle.trigger accepts; the host checks them, so runAction only sees these
  actions: Object.freeze(['shift', 'demo']),
  async create(context, options) {
    const { device, format } = context;
    const module = device.createShaderModule({ code: await wgsl('offset.wgsl'), label: 'template-plugin' });
    // compiled before the first frame: Safari would otherwise compile it at its first use, freezing the page (renderPipeline says why)
    const pipeline = await renderPipeline(device, {
      layout: 'auto', label: 'template-plugin',
      vertex: { module, entryPoint: 'vs' },
      fragment: { module, entryPoint: 'fs', targets: [{ format }] },
      primitive: { topology: 'triangle-list' },
    });
    const usage = /** @type {any} */ (globalThis).GPUBufferUsage;
    const uniforms = device.createBuffer({ size: UNIFORM_FLOATS * 4, usage: usage.UNIFORM | usage.COPY_DST });
    const sampler = device.createSampler({ magFilter: 'linear', minFilter: 'linear', addressModeU: 'clamp-to-edge', addressModeV: 'clamp-to-edge' });
    const data = new Float32Array(UNIFORM_FLOATS);
    const bindGroups = new WeakMap();   // one per source view: the host may replace the source texture on resize
    let offset = clampOffset(options?.offset ?? meta.defaults.offset);
    let rendered = offset;              // the offset of the last rendered frame, frozen into its mapper
    /** @type {((state: string|null) => void)[]} */ const waiters = [];   // settled() calls waiting for the next frame
    /** the demo in progress: its clock starts at the first frame that renders it (the same length at every frame cap) */
    let demo = /** @type {{start: number|null, resolve: (state: string|null) => void}|null} */ (null);
    const settled = () => (rendered === offset && !demo ? 'still' : new Promise((resolve) => { waiters.push(resolve); }));
    /** End the demo where it is: user input takes over at once (contract 2); the next frame shows the state at rest. */
    const stopDemo = () => {
      if (!demo) return;
      const { resolve } = demo;
      demo = null;
      context.requestRender();
      Promise.resolve(settled()).then(resolve);
    };
    // a press on the picture takes over from the demo; passive, so it never blocks the page's scrolling (contract 1)
    const offPointer = context.listen('pointerdown', stopDemo, { passive: true });

    return {
      spatial: true,       // pixels move: the host requires captureInputMapper
      setOptions(next) {
        stopDemo();
        if (next?.offset !== undefined) offset = clampOffset(next.offset);
        context.requestRender();   // not `continuous`: the host renders only when the source changed or on request
      },
      // the actions: resolve with the state the plugin rests in once a frame shows it (the host handles validation and superseding: a
      // newer trigger resolves the older one with null, so a demo still running simply ends)
      runAction(action, actionOptions, info) {
        stopDemo();
        if (action === 'demo') {
          if (info?.reducedMotion) return settled();   // nothing moves: it resolves at once with the state at rest
          return new Promise((resolve) => { demo = { start: null, resolve }; context.requestRender(); });
        }
        if (actionOptions.offset !== undefined) offset = clampOffset(actionOptions.offset);
        context.requestRender();
        return settled();
      },
      // resolves once nothing moves: here, once the frame with the current offset was rendered
      settled,
      render(frame) {
        let ended = null;
        if (demo) {
          if (demo.start === null) demo.start = frame.now;
          const elapsed = frame.now - demo.start;
          rendered = demoOffset(offset, elapsed);
          if (elapsed < DEMO_MS) context.requestRender();   // one more frame while it moves; none once it ends (zero work at rest)
          else { ended = demo.resolve; demo = null; rendered = offset; }
        } else rendered = offset;
        data[0] = frame.width; data[1] = frame.height; data[2] = frame.cssWidth; data[3] = rendered;
        device.queue.writeBuffer(uniforms, 0, data);
        let bindGroup = bindGroups.get(frame.sourceView);
        if (!bindGroup) {
          bindGroup = device.createBindGroup({
            layout: pipeline.getBindGroupLayout(0),
            entries: [{ binding: 0, resource: { buffer: uniforms } }, { binding: 1, resource: sampler }, { binding: 2, resource: frame.sourceView }],
          });
          bindGroups.set(frame.sourceView, bindGroup);
        }
        const pass = frame.encoder.beginRenderPass({
          colorAttachments: [{ view: frame.destinationView, loadOp: 'clear', storeOp: 'store', clearValue: { r: 0, g: 0, b: 0, a: 1 } }],
        });
        if (frame.sourceReady) { pass.setPipeline(pipeline); pass.setBindGroup(0, bindGroup); pass.draw(3); }
        pass.end();
        if (ended) ended('still');
        if (!demo && rendered === offset) for (const resolve of waiters.splice(0)) resolve('still');
      },
      // called each time a frame is PRESENTED: freeze what that frame used, a later render must not change this mapper
      captureInputMapper() {
        const frozen = rendered;
        return (point) => mapOffsetPoint(frozen, point);
      },
      // optional: the plugin's own controls, as ordinary HTML (they can live inside the drawn form)
      mountUI(root, ui) {
        const label = root.ownerDocument.createElement('label');
        label.textContent = 'Offset ';
        const range = root.ownerDocument.createElement('input');
        Object.assign(range, { type: 'range', min: '0', max: String(MAX_OFFSET), step: '1', value: String(ui.getOptions().offset ?? offset) });
        const onInput = () => ui.setOptions({ offset: Number(range.value) });
        range.addEventListener('input', onInput);
        label.append(range);
        root.append(label);
        return () => { range.removeEventListener('input', onInput); label.remove(); };
      },
      destroy() {
        offPointer();
        if (demo) { demo.resolve(null); demo = null; }
        for (const resolve of waiters.splice(0)) resolve(null);   // removed before its frame: null
        uniforms.destroy?.();
      },
    };
  },
});
